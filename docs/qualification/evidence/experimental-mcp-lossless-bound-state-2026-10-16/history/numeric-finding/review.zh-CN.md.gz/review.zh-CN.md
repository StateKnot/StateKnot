Spec 新增 P1：不同 decoded u64 参数可兑换同一 strict state。root 的真实 TCP 反例保持 eedd 八个生产文件完全不变，仅追加测试：9007199254740992→9007199254740993 后仍 HTTP200 complete，业务计数2→3；预期400，实际测试101。依赖 JCS 将整数转 f64 导致 AD 碰撞。Prompt 共用编码路径，尚不声称已实测 Prompt。旧14通过只保留原范围事实，eedd及公开包暂不采用。

最小方案可实施：strict三种 operation AD 升v3，递归排序已解码 Value 后以 serde_json::to_vec 编码，保留数值类型/精度；拒绝全部旧v2 state。cursor v2、envelope1、legacy旧AD不改。须更新接口与Rustdoc，并补数值、嵌套/重排、旧token与真实Tool/Prompt回归后重新验收。此为方案复核，无新产品执行或完成资格。
