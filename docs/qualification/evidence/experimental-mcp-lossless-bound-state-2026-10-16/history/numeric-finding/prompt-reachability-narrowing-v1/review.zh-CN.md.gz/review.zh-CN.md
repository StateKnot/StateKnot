范围收窄：当前 Prompt 的 validate_arguments 在生成 AD 前，仅允许已声明且有界的字符串参数。因此共享 operation_binding 不构成已可达的 Prompt 数值碰撞；根因反例限定 Tool。保留原 sealed 反例及方案回执，不扩张数值影响面。

Prompt 的真实回归应覆盖字符串/重排对象键正控、改字符串和旧 v2 token 拒绝，以及数字参数仍按原 schema 拒绝；不得为了测试放宽 Prompt 类型。Tool 与通用私有编码单测覆盖宽整数、float、嵌套值。三种 strict AD 统一升级 v3 仍是明确的版本切换；cursor v2、envelope1、legacy 不变。
