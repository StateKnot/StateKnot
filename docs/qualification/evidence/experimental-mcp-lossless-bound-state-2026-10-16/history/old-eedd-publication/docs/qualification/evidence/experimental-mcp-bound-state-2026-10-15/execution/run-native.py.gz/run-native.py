from pathlib import Path
import fcntl,hashlib,json,os,re,shutil,subprocess,time
R=Path('/Users/jiawy/Documents/RustAgentFramework'); B=R/'.local-verification/2026-10-15'; S=B/'mcp-bound-state-source-v1'; O=Path(__file__).resolve().parent/'native-serial-default-profile-v3'; O.mkdir(exist_ok=False)
manifest=json.loads((O.parent/'frozen-source-manifest.json').read_text()); expected=manifest['files']; config=json.loads((B/'native-opt1-root-execution-v1/execution-config.json').read_text())
def put(n,v): (O/n).write_text(json.dumps(v,indent=2)+'\n')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def check(label):
 rows=[]
 for p in sorted(S.rglob('*')):
  assert not p.is_symlink()
  if p.is_file(): rows.append({'path':str(p.relative_to(S)),'bytes':p.stat().st_size,'sha256':sha(p)})
 assert rows==expected,'source changed'
 raw=subprocess.check_output(['df','-k',str(R)],text=True); (O/(label+'.df')).write_text(raw); assert int(raw.splitlines()[-1].split()[3])>=50*1024**2
 total=0
 for p in (R/'target').glob('r1-oct15*'):
  if p.is_dir(): total+=int(subprocess.check_output(['du','-sk',str(p)],text=True).split()[0])
 assert total<=20*1024**2
 put('inputs-'+label+'.json',{'source_tree':manifest['source_tree_sha256'],'source_files':len(rows),'exact':True,'task_cache_logical_kib':total,'cleanup_performed':False})
lock=(O.parent/'gate.lock').open('a+'); fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
env={k:v for k,v in os.environ.items() if not k.startswith(('STATEKNOT_','CARGO_PROFILE_')) and k not in ['CARGO_ENCODED_RUSTFLAGS','RUST_MIN_STACK','RUSTC_BOOTSTRAP']}; env.update(CARGO_TARGET_DIR=str(R/'target/r1-oct15-proof-base'),CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUSTFLAGS='-D warnings',RUSTDOCFLAGS='-D warnings')
def run(label,cmd,active=None):
 check(label+'-before'); t=time.time()
 with (O/(label+'.log')).open('wb') as log:
  p=subprocess.Popen(cmd,cwd=S,env=active or env,stdout=log,stderr=subprocess.STDOUT); print(json.dumps({'step':label,'pid':p.pid,'command':cmd}),flush=True); code=p.wait()
 r={'command':cmd,'pid':p.pid,'exit_code':code,'seconds':time.time()-t,'log_sha256':sha(O/(label+'.log')),'source_tree':manifest['source_tree_sha256']}; put(label+'.receipt.json',r); print(json.dumps(r),flush=True); check(label+'-after'); assert code==0,label
 return (O/(label+'.log')).read_text()
check('initial')
body=run('build',['cargo','+1.88.0','test','-p','stateknot','--test','mcp_bound_state','--no-run','--locked','--message-format=json'])
artifacts=[]
for line in body.splitlines():
 try: v=json.loads(line)
 except json.JSONDecodeError: continue
 if v.get('reason')=='compiler-artifact' and v.get('target',{}).get('name')=='mcp_bound_state' and v.get('executable'): artifacts.append(v)
assert len(artifacts)==1
artifact=artifacts[0]; profile=artifact['profile']; assert profile['opt_level']=='0' and profile['debuginfo']==0 and profile['debug_assertions'] and profile['overflow_checks'] and profile['test']; assert artifact['target']['src_path']==str(S/'crates/stateknot/tests/mcp_bound_state.rs')
(O/'artifacts').mkdir(); binary=O/'artifacts/mcp_bound_state'; shutil.copy2(artifact['executable'],binary); binary.chmod(0o755); binary_sha=sha(binary)
listing=run('list',[str(binary),'--list']); names=re.findall(r'^(\S+): test$',listing,re.M); assert len(names)==14 and len(names)==len(set(names)); put('binary.json',{'sha256':binary_sha,'bytes':binary.stat().st_size,'cargo_artifact':artifact,'tests':names,'feature_configuration':'actual per-package default features; no --all-features or workspace union command','source_tree':manifest['source_tree_sha256']})
records=[]
marker='STATEKNOT_MCP_BOUND_STATE_POSTGRES: consumers=3 positive_commits=6 refused_rebinds=12 tenant_ledgers=2 complete_journals=true'
for pg in config['postgres']:
 major=pg['major']; container=pg['container']; inspected=json.loads(subprocess.check_output(['docker','inspect',container]))[0]; assert inspected['State']['Running'] and inspected['Id']==pg['expected_container_id'] and inspected['Image']==pg['expected_image_id'] and inspected['Config']['Labels']['stateknot.task']=='r1-oct15'; assert {'HostIp':'127.0.0.1','HostPort':str(pg['port'])} in inspected['NetworkSettings']['Ports']['5432/tcp']; put('pg'+str(major)+'-container.json',inspected)
 def sql(command,database='postgres'):
  return subprocess.check_output(['docker','exec',container,'psql','-X','-v','ON_ERROR_STOP=1','-U','postgres','-d',database,'-At','-c',command],text=True).strip()
 version=sql('SHOW server_version'); assert version.startswith(str(major)+'.'); database='stateknot_r1_mcp_bound_20261015v3'; assert re.fullmatch('[a-z0-9_]+',database); assert sql("SELECT count(*) FROM pg_database WHERE datname='"+database+"'")=='0','never reuse unknown DB'; sql('CREATE DATABASE '+database); put('pg'+str(major)+'-database.json',{'version':version,'database':database,'new_absent_database_created':True,'no_database_dropped':True,'container_id':inspected['Id'],'container_image':inspected['Image']})
 active=env.copy(); active['STATEKNOT_REQUIRE_POSTGRES_TESTS']='1'; active['STATEKNOT_TEST_DATABASE_URL']='postgres://postgres:stateknot_test_password@127.0.0.1:'+str(pg['port'])+'/'+database
 log=run('pg'+str(major),[str(binary),'--nocapture','--test-threads=1'],active); summary=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',log); assert summary==[('ok','14','0','0','0','0')],summary; assert log.splitlines().count(marker)==1 and 'STATEKNOT_MCP_BOUND_STATE_POSTGRES_SKIPPED' not in log; assert sha(binary)==binary_sha
 records.append({'major':major,'actual_version':version,'suite_passed':14,'failed':0,'ignored':0,'filtered':0,'unique_marker':marker,'binary_sha256':binary_sha,'database_retained':database,'scope':'three protocol consumers, six real fixture commits, twelve refused rebinds; two full fixture Run/Journal ledgers, not all DB tables'})
check('final'); opened=subprocess.run(['lsof','+D',str(O/'artifacts')],capture_output=True,text=True); (O/'final-binary-lsof.stdout').write_text(opened.stdout); (O/'final-binary-lsof.stderr').write_text(opened.stderr); assert opened.returncode==1 and not opened.stdout.strip() and not opened.stderr.strip()
put('summary.json',{'state':'passed','source_tree':manifest['source_tree_sha256'],'source_files':len(expected),'postgres':records,'binary_sha256':binary_sha,'profile':'original opt0; default stack, assertions, overflow checks and fixture resources preserved','cache_reused':'target/r1-oct15-proof-base','new_database_cleanup_performed':False,'complete_CI_or_R1_qualified':False}); print(json.dumps({'state':'passed','postgres':records}),flush=True)
