#!/usr/bin/env python3
"""Read-only checks of sealed adoption text and existing execution evidence."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

R = Path('/Users/jiawy/Documents/RustAgentFramework')
B = R / '.local-verification/2026-10-15'
H = B / 'mcp-bound-state-adoption-docs-v2'
O = Path(__file__).resolve().parent
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def read_json(path):
    return json.loads(path.read_text())


def identity(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}


def git(*args):
    p = subprocess.run(['git', '-C', str(R), *args], capture_output=True)
    assert p.returncode == 0, p.stderr.decode()
    return p.stdout


expected = {
    'manifest.json': 'e024644b713da0b72e64d8aa0b198be8f016c7cdce621d475c975b79bd1cc23b',
    'freeze.json': '6fe1007c860f1128155eb53dfb8947b94dfe4acb97dd3be41f15065a7c6d8bb2',
    'receipt.json': '8a06babefae6d971379225b45586032caae84672cd89c11af57a449c83bdd264',
}
before = {'HEAD': git('rev-parse', 'HEAD').decode().strip(),
          'status': git('status', '--porcelain=v1').decode()}
for name, digest in expected.items():
    assert sha((H / name).read_bytes()) == digest, name
manifest = read_json(H / 'manifest.json')
for row in manifest['files']:
    got = identity(H / row['path'])
    assert (got['bytes'], got['sha256']) == (row['bytes'], row['sha256']), row['path']
basis = read_json(H / 'basis.json')
baseline_checks = []
for row in basis['baseline_documents']:
    raw = (H / 'baseline' / row['path']).read_bytes()
    assert sha(raw) == row['sha256']
    assert raw == git('show', basis['main_HEAD'] + ':' + row['path'])
    assert raw == (R / row['path']).read_bytes()
    candidate = (H / 'candidate' / row['path']).read_bytes()
    assert candidate != raw
    baseline_checks.append({'path': row['path'], 'baseline_sha256': sha(raw),
                            'candidate_sha256': sha(candidate), 'baseline_exact_85f': True})

facts = read_json(H / 'fact-bindings.json')
for row in facts['bindings']:
    got = identity(Path(row['path']))
    assert (got['bytes'], got['sha256']) == (row['bytes'], row['sha256'])
N = B / 'mcp-bound-state-integration-v1/retry-v5'
counts = {}
pattern = r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;'
for name, total, groups in [('retry-workspace.log', [2095, 0, 6, 0, 0], 99),
                            ('retry-doctests.log', [48, 0, 0, 0, 0], 10)]:
    raw = (N / name).read_bytes()
    rows = [list(map(int, m)) for m in re.findall(pattern, raw.decode())]
    actual = [sum(row[i] for row in rows) for i in range(5)]
    assert actual == total and len(rows) == groups
    counts[name] = {'groups': groups, 'totals': actual, 'sha256': sha(raw)}
marker = 'STATEKNOT_MCP_BOUND_STATE_POSTGRES: consumers=3 positive_commits=6 refused_rebinds=12 tenant_ledgers=2 complete_journals=true'
native = []
for major in [16, 17]:
    d = N / 'native-serial-default-profile-v3'
    receipt = read_json(d / f'pg{major}.receipt.json')
    raw = (d / f'pg{major}.log').read_bytes()
    rows = [list(map(int, m)) for m in re.findall(pattern, raw.decode())]
    assert rows == [[14, 0, 0, 0, 0]]
    assert raw.decode().splitlines().count(marker) == 1
    assert 'SKIPPED' not in raw.decode()
    assert receipt['exit_code'] == 0
    native.append({'major': major, 'totals': rows[0], 'standalone_complete_markers': 1,
                   'log_sha256': sha(raw), 'receipt_sha256': sha((d / f'pg{major}.receipt.json').read_bytes())})
source = read_json(N / 'frozen-source-manifest.json')
S = B / 'mcp-bound-state-source-v1'
for row in source['files']:
    got = identity(S / row['path'])
    assert (got['bytes'], got['sha256']) == (row['bytes'], row['sha256'])
assert source['count'] == len(source['files']) == 928
assert source['source_tree_sha256'] == facts['source_tree']
example = (H / 'example.rs.txt').read_text()
for p in ['docs/mcp-server.md', 'docs/mcp-server.zh-CN.md']:
    assert (H / 'candidate' / p).read_text().count(example) == 1
prior_review = B / 'evidence/mcp-bound-state-execution-independent-review-v1'
assert sha((prior_review / 'receipt.json').read_bytes()) == '5b9d88210e08a59cf320f4bfea93aca3dbef8841fea8abcb2f6ecffb395a45e9'
assert sha((prior_review / 'manifest.json').read_bytes()) == 'e71831b26f853199fc836f61451fc93ae5f925eb8ba9b947b27effa394ccbcd9'
p = subprocess.run(['python3', str(H / 'verify.py')], capture_output=True, text=True)
(O / 'offline-verifier.stdout.json').write_text(p.stdout)
(O / 'offline-verifier.stderr.txt').write_text(p.stderr)
assert p.returncode == 0
verify_output = json.loads(p.stdout)
assert verify_output['link_scope']['existing_local_targets'] == 93
assert set(verify_output['link_scope']['reserved_qualification_targets_not_present']) == set(basis['pending_report_paths'])
after = {'HEAD': git('rev-parse', 'HEAD').decode().strip(),
         'status': git('status', '--porcelain=v1').decode()}
assert after == before
inputs = [identity(H / row['path']) for row in manifest['files']]
inputs += [identity(H / 'manifest.json'), identity(H / 'freeze.json')]
inputs += [identity(Path(row['path'])) for row in facts['bindings']]
inputs += [identity(prior_review / 'receipt.json'), identity(prior_review / 'manifest.json')]
for rel in ['CONTRIBUTING.md', 'docs/rfcs/README.md']:
    inputs.append(identity(R / rel))
for name in ['public-interface.rs.txt', 'CONTRACT.md']:
    inputs.append(identity(B / 'mcp-bound-state-interface-v1' / name))
for name in ['lib.rs', 'mcp_server.rs', 'mcp_server_app.rs', 'mcp_server_bound_state.rs']:
    inputs.append(identity(S / 'crates/stateknot-integrations/src' / name))
(O / 'input-identities.json').write_text(json.dumps(inputs, indent=2) + '\n')
result = {
    'kind': 'independent read-only document/fact audit, not new product execution',
    'status': 'passed', 'sealed_directory_files': len(manifest['files']) + 2,
    'fixed_document_manifest_sha256': expected['manifest.json'],
    'baseline_documents': baseline_checks, 'raw_recount': counts, 'native': native,
    'source_actual_928_files_match_frozen': True, 'source_tree': facts['source_tree'],
    'example_identical_both_guides_sha256': sha(example.encode()),
    'example_individually_compiled_by_this_review': False,
    'offline_verifier': {'command': ['python3', str(H / 'verify.py')], 'exit_code': p.returncode,
                         'stdout_sha256': sha(p.stdout.encode()), 'stderr_sha256': sha(p.stderr.encode())},
    'links': verify_output['link_scope'], 'reserved_reports_must_be_supplied_before_publication': True,
    'git_before': before, 'git_after': after,
    'writes_limited_to_ignored_review_directory': True,
    'compile_network_DB_Docker_or_product_test_executed': False,
    'reviewer_tooling_notes': ['Initial rg used two nonexistent nested-module paths and returned exit2; corrected to the actual flat mcp_server_bound_state.rs and mcp_server_app.rs paths. No product command failed.'],
}
(O / 'audit-receipt.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': result['status'], 'sealed_files': result['sealed_directory_files'],
                  'documents': len(baseline_checks), 'source_files': source['count'],
                  'existing_links': 93, 'reserved_reports': 3, 'new_product_execution': False}, indent=2))
