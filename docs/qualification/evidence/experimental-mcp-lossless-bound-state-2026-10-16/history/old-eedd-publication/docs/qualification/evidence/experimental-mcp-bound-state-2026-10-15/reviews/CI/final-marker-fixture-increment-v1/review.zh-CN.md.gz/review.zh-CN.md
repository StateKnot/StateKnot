Standards：0；Spec：0（仅最终 marker fixture 增量）。最终 eeddc9f7 的 928 文件均核验；相对 be3266b4 仅 durable fixture 成功 marker 字符串增加前导换行，其他 927 文件、8 个生产文件和全部断言不变。

P2 MCP-CI-SPEC-1 在新源码中关闭：旧串行单项实际成功但 marker 完整行数为 0；新双 PG 完整 14 项均以 --nocapture --test-threads=1 实际退出 0，marker 完整行各 1，原 6568a9 CI 判据对两份新 raw log 均返回 0。原 Spec1 red 与其 seal 保留。

这是原 opt0/default features 的本地执行证据复核与离线 checker 验证；未执行产品测试，不转授 Ubuntu/test-opt1、完整 CI、六门 gate 或 R1 资格。
