set -euo pipefail
{
  git rev-parse HEAD
  git rev-parse 'HEAD^{tree}'
  sha256sum Cargo.lock
  rustc -Vv
  uname -a
  df -T .
  printf 'configured_postgres_image=%s\n' "$STATEKNOT_QUALIFICATION_POSTGRES_IMAGE"
  printf 'configured_postgres_major=%s\n' "$STATEKNOT_QUALIFICATION_POSTGRES_MAJOR"
  printf 'STATEKNOT_REQUIRE_POSTGRES_TESTS=%s\n' "$STATEKNOT_REQUIRE_POSTGRES_TESTS"
  for setting in CARGO_INCREMENTAL CARGO_PROFILE_DEV_DEBUG CARGO_PROFILE_TEST_DEBUG \
    CARGO_PROFILE_TEST_OPT_LEVEL CARGO_PROFILE_TEST_DEBUG_ASSERTIONS CARGO_PROFILE_TEST_OVERFLOW_CHECKS; do
    printf '%s=%s\n' "$setting" "${!setting}"
  done
} > mcp-bound-state-environment.log
cargo test -p stateknot --test mcp_bound_state --locked -- \
  --nocapture --test-threads=1 2>&1 | tee mcp-bound-state-qualification.log
test "$(grep -c '^running 14 tests$' mcp-bound-state-qualification.log)" = 1
test "$(grep -c '^STATEKNOT_MCP_BOUND_STATE_POSTGRES:' mcp-bound-state-qualification.log)" = 1
test "$(grep -Fxc 'STATEKNOT_MCP_BOUND_STATE_POSTGRES: consumers=3 positive_commits=6 refused_rebinds=12 tenant_ledgers=2 complete_journals=true' mcp-bound-state-qualification.log)" = 1
test "$(grep -Ec '^test result: ok[.] 14 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in [0-9.]+s$' mcp-bound-state-qualification.log)" = 1
if grep -Fq 'STATEKNOT_MCP_BOUND_STATE_POSTGRES_SKIPPED:' mcp-bound-state-qualification.log; then
  exit 1
fi
