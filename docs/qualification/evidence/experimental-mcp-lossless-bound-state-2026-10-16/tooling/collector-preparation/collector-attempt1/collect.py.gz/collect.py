#!/usr/bin/env python3
"""Copy existing terminal evidence only; no build, network, DB or cleanup."""
from pathlib import Path
import argparse
import difflib
import gzip
import hashlib
import io
import json
import subprocess
import tarfile

R = Path('/Users/jiawy/Documents/RustAgentFramework')
B = R / '.local-verification/2026-10-16'
P = Path(__file__).resolve().parent
TITLE = 'experimental-mcp-lossless-bound-state-2026-10-16'
E = P / 'docs/qualification/evidence' / TITLE
Q = B / 'mcp-lossless-qualification-v3'
F = Q / 'network-enabled-retry-v1'
N = F / 'native-serial-default-profile-v4'
S = B / 'mcp-lossless-bound-state-source-v3'
OLD = R / '.local-verification/2026-10-15/mcp-bound-state-main-publication-v1'
TREE = '69af3a0f28d333f4e67d2b2cfcc2afc071938a6ce398527cc098d31ee8db60d8'
BASE = '3a84c68eb9dd9df1804a7e24801516e11c9ee01ca0c6f243a4fdfaf76cbe124c'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
canon = lambda obj: json.dumps(obj, sort_keys=True, separators=(',', ':')).encode()
load = lambda path: json.loads(path.read_text())
index = []
payloads = set()


def put(name, value):
    path = E / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def artifact(name, origin, compress=True):
    assert '/target/' not in origin.as_posix() and origin.name != 'mcp_bound_state', origin
    assert origin.suffixes[-2:] != ['.tar', '.gz'], origin
    raw = origin.read_bytes()
    stored = gzip.compress(raw, mtime=0) if compress else raw
    path = E / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(stored)
    index.append({'path': name, 'kind': 'copied_existing', 'origin': str(origin),
                  'storage_encoding': 'gzip' if compress else 'identity',
                  'stored_bytes': len(stored), 'stored_sha256': sha(stored),
                  'raw_bytes': len(raw), 'raw_sha256': sha(raw)})


def derived(name, raw):
    path = E / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(gzip.compress(raw, mtime=0))
    index.append({'path': name, 'kind': 'derived', 'origin': None,
                  'storage_encoding': 'gzip', 'stored_bytes': path.stat().st_size,
                  'stored_sha256': sha(path.read_bytes()), 'raw_bytes': len(raw), 'raw_sha256': sha(raw)})


def directory(label, root):
    assert root.is_dir(), root
    for path in sorted(root.rglob('*')):
        if path.is_file():
            assert path.suffix not in ['.pyc', '.tar'], path
            artifact(label + '/' + path.relative_to(root).as_posix() + '.gz', path)


def source_files(root, manifest):
    files = {row['path']: (root / row['path']).read_bytes() for row in manifest['files']}
    assert len(files) == manifest['count'] == 928
    assert all(len(files[row['path']]) == row['bytes'] and sha(files[row['path']]) == row['sha256'] for row in manifest['files'])
    return files


def delta(base, files, manifest):
    changes = []
    for row in manifest['files']:
        name = row['path']
        raw = files[name]
        if base.get(name) == raw:
            continue
        payload = 'source/payloads/' + sha(raw) + '.txt.gz'
        path = E / payload
        if payload not in payloads:
            derived(payload, raw)
            payloads.add(payload)
        changes.append({'path': name, 'before_sha256': sha(base[name]) if name in base else None,
                        'bytes': len(raw), 'after_sha256': sha(raw), 'payload': payload})
    assert not set(base) - set(files)
    return changes


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--adoption-docs', type=Path)
    args = parser.parse_args()
    # Do not start collection from partial/live execution files.
    gates = load(F / 'six-gates-summary.json')
    native = load(N / 'summary.json')
    resource = load(F / 'final-resource-observation.json')
    assert gates['state'] == native['state'] == 'passed'
    assert gates['source_tree'] == native['source_tree'] == resource['source_tree'] == TREE
    assert gates['totals']['workspace'] == {'suites': 99, 'passed': 2098, 'failed': 0, 'ignored': 6, 'filtered': 0}
    assert gates['totals']['doctests'] == {'suites': 10, 'passed': 48, 'failed': 0, 'ignored': 0, 'filtered': 0}
    assert len(gates['receipts']) == 6 and all(v['exit_code'] == 0 for v in gates['receipts'])
    assert {v['major'] for v in native['postgres']} == {16, 17}
    assert all((v['suite_passed'], v['failed'], v['ignored'], v['filtered']) == (15, 0, 0, 0) for v in native['postgres'])
    assert resource['source_928_before_after_exact'] and resource['no_cleanup_or_database_lifecycle_action']
    E.mkdir(parents=True, exist_ok=True)

    # The superseded publication is retained verbatim ONLY under history.
    assert sha((OLD / 'publication-manifest.json').read_bytes()) == '698416c2a88df3adc07397d60dd38398710b34ac259dc49d82d30514348699a5'
    old_manifest = load(OLD / 'publication-manifest.json')
    for row in old_manifest['files']:
        path = OLD / row['path']
        assert len(path.read_bytes()) == row['bytes'] and sha(path.read_bytes()) == row['sha256']
        artifact('history/old-eedd-publication/' + row['path'], path, False)
    artifact('history/old-eedd-publication/publication-manifest.json', OLD / 'publication-manifest.json', False)
    put('history/old-eedd-publication/status.json', {
        'source': 'eeddc9f7e9c92023a0b0c1f9a7220cccc1b4c5d846ae4281d4a4aeff9b0f30f4',
        'historical_only': True, 'adoptable': False, 'old14_greens_are_not_numeric_binding_qualification': True,
        'invalidated_by_actual_numeric_counterexample': True,
        'preserved_old_report_or_review_zeroes_do_not_override_new_red': True})
    olde = OLD / 'docs/qualification/evidence/experimental-mcp-bound-state-2026-10-15'
    refs = load(olde / 'source/base-references.json')
    put('source/base-references.json', refs)
    for row in refs['files']:
        raw = (R / row['path']).read_bytes()
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
    with tarfile.open(fileobj=io.BytesIO((R / refs['files'][0]['path']).read_bytes()), mode='r:gz') as archive:
        members = archive.getmembers()
        assert len(members) == len({v.name for v in members}) == 923
        assert all(v.isfile() and v.name.startswith('source/') and '..' not in Path(v.name).parts for v in members)
        base = {v.name[7:]: archive.extractfile(v).read() for v in members}
    parent = json.loads(gzip.decompress((R / refs['files'][1]['path']).read_bytes()))
    base['crates/stateknot-runtime/tests/postgres/child_join_pitr.rs'] = gzip.decompress((R / refs['files'][2]['path']).read_bytes())
    rows = [{'path': v['path'], 'bytes': len(base[v['path']]), 'sha256': sha(base[v['path']])} for v in parent['files']]
    assert sha(canon(rows)) == BASE
    manifest = load(Q / 'frozen-source-manifest.json')
    files = source_files(S, manifest)
    assert manifest['source_tree_sha256'] == sha(canon(manifest['files'])) == TREE
    changes = delta(base, files, manifest)
    assert len(changes) == 12 and sum(v['before_sha256'] is None for v in changes) == 5
    assert sum(v['path'].startswith('crates/stateknot-integrations/src/') for v in changes) == 8
    put('source/final-reconstruction.json', {'tree_sha256': TREE, 'base_tree_sha256': BASE, 'files': 928,
        'production_files': 8, 'test_files': 4, 'new_files': 5, 'changes': changes, 'new_full_source_archive': False})
    artifact('source/final-source-manifest.json.gz', Q / 'frozen-source-manifest.json')
    artifact('source/root-compiled-inputs.json.gz', Q / 'compiled-inputs.json')
    supplied = [v for v in manifest['files'] if v['path'].startswith(('crates/', '.cargo/')) or v['path'] in ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml']]
    digest = sha(canon(sorted(supplied, key=lambda v: v['path'])))
    assert len(supplied) == 536 and digest == 'ded1a866797889ed38df63f59f671c8a2c34a5b7373a688932cc714eae582794'
    put('source/compiled-inputs.json', {'count': 536, 'canonical_sha256': digest, 'files': supplied,
        'compiler_read_closure_claimed': False, 'scope': 'complete conservative supplied crate/config/fixture input superset'})
    patch = ''.join(''.join(difflib.unified_diff(base.get(v['path'], b'').decode().splitlines(True), files[v['path']].decode().splitlines(True),
        fromfile='a/' + v['path'] if v['path'] in base else '/dev/null', tofile='b/' + v['path'])) for v in changes)
    derived('source/candidate.patch.gz', patch.encode())
    parent_supplied = {n: raw for n, raw in base.items() if n.startswith(('crates/', '.cargo/')) or n in ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml']}
    assert len(parent_supplied) == 531 and all((R / n).read_bytes() == raw for n, raw in parent_supplied.items())
    put('source/adoption-files.json', {'baseline_main': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip(),
        'only_source_files_to_adopt': changes, 'compiled_parent531_exact': True, 'new_supplied_inputs': 536,
        'whole_frozen928_equals_actual_main_claimed': False, 'historical_docs_workflow_gitignore_not_to_adopt': True})

    # New actual red and its exact source reconstruction; no old binary SHA invented.
    probe = R / '.local-verification/2026-10-15/mcp-numeric-argument-probe-v1'
    for name in ['receipt.json', 'test.log', 'source-manifest.json']:
        artifact('history/numeric-alias-red/' + name + '.gz', probe / name)
    probe_source = R / '.local-verification/2026-10-15/mcp-numeric-argument-probe-source-v1'
    probe_manifest = load(probe / 'source-manifest.json')
    old_source = R / '.local-verification/2026-10-15/mcp-bound-state-source-v1'
    eedd = source_files(old_source, load(R / '.local-verification/2026-10-15/mcp-bound-state-integration-v1/retry-v5/frozen-source-manifest.json'))
    probe_files = source_files(probe_source, probe_manifest)
    assert [n for n in eedd if eedd[n] != probe_files[n]] == ['crates/stateknot/tests/mcp_bound_state/network.rs']
    put('history/numeric-alias-red/reconstruction.json', {'base': 'historical eedd', 'changes_from3a84': delta(base, probe_files, probe_manifest),
        'production8_exact_eedd': True, 'actual_binary_sha_not_archived': True})
    directory('history/numeric-finding', R / '.local-verification/2026-10-15/evidence/mcp-bound-state-numeric-binding-review-v1')
    q2 = B / 'mcp-lossless-qualification-v2'
    for name in ['clippy.log', 'clippy.receipt.json', 'freeze.json', 'frozen-source-manifest.json', 'format.receipt.json']:
        artifact('history/a87-unit-lifetime-red/' + name + '.gz', q2 / name)
    a87 = source_files(B / 'mcp-lossless-bound-state-source-v2', load(q2 / 'frozen-source-manifest.json'))
    put('history/a87-unit-lifetime-red/reconstruction.json', {'changes_from3a84': delta(base, a87, load(q2 / 'frozen-source-manifest.json')),
        'only_change_to_final69af_is_test_closure_parameter_type': True})
    for name in ['workspace.log', 'workspace.receipt.json', 'freeze.json', 'unit-lifetime-fix.patch']:
        artifact('history/69af-sandbox-loopback-red/' + name + '.gz', Q / name)
    artifact('execution/retry-basis.json.gz', F / 'retry-basis.json')
    for name in ['freeze.json', 'execute-six.py']:
        artifact('execution/parent-' + name + '.gz', Q / name)
    for gate in ['fmt', 'clippy', 'workspace', 'doctests', 'rustdoc', 'nightly']:
        for suffix in ['log', 'receipt.json', 'before.df', 'after.df', 'before-cache-budget.json', 'after-cache-budget.json']:
            artifact('execution/gates/' + gate + '.' + suffix + '.gz', F / (gate + '.' + suffix))
    for name in ['six-gates-summary.json', 'execute-six.py', 'run-native.py', 'final-resource-observation.json']:
        artifact('execution/' + name + '.gz', F / name)
    directory('execution/final-resource-raw', F / 'final-resource-observation')
    for path in sorted(N.iterdir()):
        if not path.is_file() or path.name.endswith('-container.json'):
            continue
        assert path.name != 'mcp_bound_state' and path.suffix != '.lock'
        artifact('execution/native/' + path.name + '.gz', path)
    projection = []
    for major in [16, 17]:
        path = N / f'pg{major}-container.json'
        row = load(path)
        projection.append({'major': major, 'original_inspection_sha256': sha(path.read_bytes()), 'container_id': row['Id'],
            'running': row['State']['Running'], 'image': row['Image'], 'labels': row['Config']['Labels'], 'ports': row['NetworkSettings']['Ports'],
            'kind': 'named derived identity projection, not raw complete Docker inspection'})
    put('execution/native/container-identities.json', {'records': projection})
    for label, directory_path in [
        ('interface-v2', B / 'mcp-lossless-bound-state-interface-v2'),
        ('standards', B / 'evidence/mcp-lossless-standards-review-v2'),
        ('numeric-Spec', B / 'evidence/mcp-lossless-numeric-spec-review-v1'),
        ('test-authoring', B / 'mcp-lossless-external-test-authoring-v2'),
        ('CI15-preparation', B / 'mcp-lossless-ci-candidate-v2'),
        ('CI15-positive', B / 'mcp-lossless-ci15-positive-v1')]:
        directory('reviews/' + label, directory_path)
    if args.adoption_docs:
        for name in ['manifest.json', 'freeze.json', 'receipt.json', 'candidate-documents.json']:
            artifact('adoption-docs/' + name + '.gz', args.adoption_docs / name)
    put('artifact-index.json', {'artifacts': index})
    put('collection-state.json', {'state': 'existing terminal execution/source/history collected; publication not sealed',
        'source_tree': TREE, 'strict_gates': 6, 'dual_PG_full15': True, 'old_eedd_adoptable': False,
        'new_product_execution_by_collector': False, 'no_binary_cache_or_new_complete_source_archive': True,
        'collector_original_external_test_author_not_independent_source_Spec': True,
        'CI_Ubuntu_opt1_complete30m_RFC_R1_qualified': False, 'adoption_docs_collected': bool(args.adoption_docs)})
    print(json.dumps({'source': TREE, 'artifacts': len(index), 'state': 'collected, not sealed'}))


if __name__ == '__main__':
    main()
