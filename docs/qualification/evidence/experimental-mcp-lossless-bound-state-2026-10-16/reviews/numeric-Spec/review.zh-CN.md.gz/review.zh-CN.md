# 数值绑定修复：独立 Spec 源码审核

结论：在固定 source v3 69af3a0f28d333f4e67d2b2cfcc2afc071938a6ce398527cc098d31ee8db60d8 的本次五文件增量中，未发现应阻止该修复的 Spec 问题（0）。这是源码及回归 oracle 审核，不是测试执行通过、实际 PostgreSQL/CI 通过或 R1 完成结论。审核者未写任何生产实现或新测试；审核者撰写了 Interface v2，因此该契约文字本身仍需要另一位审核者，不能称本报告独立审核了自己撰写的文档。

原实际 Tool 反例与影响范围保持：旧 JCS 把 u64/i64 经过 f64，两个不同的实际 parsed Value 大整数复用 AD；旧 token 对第二个参数得 HTTP200 并新增业务调用。公开 Prompt 先验证 bounded string schema，数值不可达；Resource 没有 argument 字段。本报告不把私有 Prompt helper 数值测试扩大成公开 Prompt 漏洞。

## 修复与契约

私有 operation_binding 现在对三个 surface 一致使用 request-state/{surface}/v3。Tool/Prompt clone 实际 Map 为 Value::Object、递归 sort_all_objects、serde_json::to_vec，保留 handler 可观察的解析后数字表示；保持 fingerprint、exact name/URI、u64 长度前缀与 SHA256。排序仅规范对象键，不规范数组顺序或数字表示；明确称 sorted serde_json value encoding，不是 JCS，也不承诺保留 wire spelling。Resource 没有多加参数字段。

cursor v2、envelope integer1、host-key/fingerprint v1、现有 codec/keyring 与所有 unconfigured legacy v1/JCS 路径保持。三个 consumer 的 Context getter Rustdoc 同步 v3。生产函数签名没有改变；profile 不会因 host-bound principal 自动开启。实际 Tool/Prompt/Resource consumer 仍在既有 auth/scope/schema 后使用该共享 AD open_inbound、成功后调用 business，代码没有旧 v2 retry/fallback。原绑定/当前映射策略/全部 guard/Private catalog/Public Resource 边界、64KiB/128KiB/24h、输出封装后置与 effect/retry 语义均通过未变字节保留。

## 新回归的 oracle

两个新私有 unit 函数覆盖：正负 2^53 邻值、u64/i64 极值邻值、1 对 1.0、正负浮点零、嵌套数组/对象；相同值可 seal/open，变值 AD 不同且旧 token 拒绝；递归键重排绑定相同。数字判别用 serde_json 编码字节，避免 Value equality 合并正负零的盲点。Prompt helper 测试明确只验证内部函数。

同 key 旧 v2 测试独立重建三个旧域/长度前缀/JCS 参数 AD，并用完全合法 envelope seal；先证实该 token 可被旧 AD 打开，再证实新 v3 AD 拒绝，避免把坏 token 当兼容性证据。它是私有共享 guard 测试；所有三个实际 consumer 调用共同 AD/guard 的关系由源码核查支持，不宣称另行执行了三个公开旧-v2 HTTP 反例。

新 public TCP family 通过手工发送原 argument JSON bytes，避免客户端 Value 序列化先吞掉键序差异。八对正负 wide/极值/数字表示/嵌套 Tool 参数各先完成同值合法续传，再持原 token 改值，要求 HTTP400/-32602 固定 Invalid MCP request state，且 business count、实际 decoded business_facts 完整编码、completions 都不变；随后变值本身必须能 fresh challenge/complete，并核业务实际收到的参数编码。这排除了 blanket 数值拒绝与仅请求侧 hash 测试。另有嵌套 Tool 键重排正控；Prompt 字符串正常续传与数字保持原 schema HTTP400 拒绝，旧实际改字符串测试保持。

原 network 29780-byte 前缀和原8个私有 unit 函数完整字节保留。原14 facade case 定义加1个 TCP family 得15，原8个 private unit 加2得10；这只是定义清点，实际运行计数与双PG结果需由 root 新执行回执给出。

## 固定输入与限制

独立重新读取928文件并计算与 freeze 完全一致的 source tree；536 compilation-input manifest 同样逐文件验证。相对旧 eedd 只变 five paths：bound_state 编码/2unit、新 TCP family、其余3条 Rustdoc。v2 a87 的 Clippy E0597 真实失败保留；v3 仅为新 unit closure 参数加显式 &Map<String, Value>，生产与 network 字节不变。root 后续 socket sandbox失败与 network-enabled重跑是不同执行事实，本报告没有借这些状态宣称运行绿灯。

旧 eedd/14-case/双PG历史成功及旧审核保留，数值反例使旧候选不满足 exact decoded-argument binding，不能原样采用。此处0仅是本次固定数值增量的静态 Spec 结论，不转授旧6gates、Native、fullCI、外部consumer、backend或生产pilot资格；主分支没有被本审核修改。
