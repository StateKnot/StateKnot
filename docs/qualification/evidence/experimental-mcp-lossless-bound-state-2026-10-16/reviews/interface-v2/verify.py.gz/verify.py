from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((R/'manifest.json').read_text())
assert len({r['path'] for r in m['files']})==len(m['files'])
for r in m['files']:
 p=R/r['path']; assert p.is_file() and not p.is_symlink()
 assert p.stat().st_size==r['bytes'] and sha(p)==r['sha256'],r['path']
assert {str(p.relative_to(R)) for p in R.rglob('*') if p.is_file()}=={r['path'] for r in m['files']}|{'manifest.json','seal.json'}
seal=json.loads((R/'seal.json').read_text())
assert sha(R/'manifest.json')==seal['manifest_sha256']
print('PASS: package bytes only; no compile/runtime/Native qualification')
