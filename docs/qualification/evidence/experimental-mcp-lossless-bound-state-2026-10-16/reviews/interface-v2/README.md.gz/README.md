# Interface v2 package

Read CONTRACT.md and MIGRATION.zh-CN.md. The two .rs.txt files summarize unchanged public/private declarations and the new private encoding responsibility; they are intentionally not Rust compilation units. contract-checklist.json specifies checks and records no executed result.

source-read-receipt.json binds these requirements to the fixed 928-file v3 source and records source comparison only. The first a87 candidate Clippy exit 101 remains preserved; the final candidate adds an explicit unit-test closure parameter type. No compilation or execution result is transferred by this package.

Run python3 verify.py to check this package. Independent Spec review has a separate receipt and scope. Old Interface v1 and old execution artifacts are unchanged.
