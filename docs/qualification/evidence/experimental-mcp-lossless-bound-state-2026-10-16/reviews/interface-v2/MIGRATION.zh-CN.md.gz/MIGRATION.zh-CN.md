# v2 迁移与资格边界

这是 source-only 修复候选的契约包，未采用到 main；声明文件不是可编译示例或 MSRV 验收。旧 Interface v1、数值反例和旧 14 项执行证据均保留，不改写历史绿灯。

1. 强配置 Tool/Prompt 的 AD 改用实际已解析 `serde_json::Value` 递归排序对象后 `serde_json::to_vec` 的字节。称为 sorted serde_json value encoding，不称 JCS。它区分相邻大整数、整数与浮点及正负零；只绑定 handler 实际收到的 parsed Value，不保留原始数字拼写或对象插入顺序。
2. 三种强配置操作 AD 统一从 v2 升为 v3，包括没有参数字段的 Resource。即使同一 key、身份、操作与合法 envelope 不变，旧 v2 token 也拒绝，无 fallback。旧 MRTR 需重新开始授权交互；升级不授权自动重发已经有未知效果的写请求。
3. 其他版本独立保持：Private cursor v2、内部 envelope integer 1、host key/common fingerprint v1。原 codec/keyring 支持与限额不变。未显式配置的服务保留旧 v1 AD/JCS/消费语义，不取得本修复的数值绑定资格。
4. 已复现的公开数值反例限定 Tool。Prompt 原 schema 仅允许声明且有界的字符串，数字在构造 AD 前拒绝；共享私有 helper 的数值单测不表示 Prompt 数值可达，不得为测试放宽 schema。Prompt 仍需实际字符串续传正控、改字符串及数字 schema 拒绝证据。Tool 的嵌套键重排正控与共享私有 helper 覆盖单独记录。
5. 原强身份契约保持：宿主验证精确 issuer/subject 并解析当前 tenant/effective principal/generation，namespace 有界稳定，代次绝不复用（含 ABA/撤销再启用）且溢出拒绝。构造类型不验证凭据；原 decoded policy/admission 在排队后核当前映射，不承诺授权后的零时隙撤销。
6. 显式 immutable profile、composite 最终 build 全 surface 安装、direct/shared 构造、重复配置错误、Clone/completion 保留、Private catalog 要求均保持。独立显式 Public Resource 内容契约不变。legacy subject 文本不能伪造 host binding；Skill 文件继续不支持 MRTR。
7. 原 phase 顺序保持：policy 看 wire opaque token，guard 成功后 business 才看 inner application state；原请求其余字段保持。Some(inputResponses) 含空 map 要求 token；SDK null=None 不增 raw parser。envelope applicationState 必须存在，null 合法、missing 拒绝。
8. 原完整 JSON payload 64 KiB、wire token 128 KiB、正 TTL 至 24 h 均不提高。输出封装发生在业务之后，失败不代表业务未发生；effect/retry/幂等原契约不变。token 不提供加密、single-use 或 durable effect receipt。
9. 根修复只更换私有 strict 操作 AD 编码和域；无新公开 API/依赖、Core/Store/Runtime 生产改动、Root metadata shortcut、SQL 或资源预算改动。三个 request_state_binding Rustdoc 对应更新 v3。
10. 新源码 freeze 后需重新完整验收；旧 suite 数量不得直接沿用。当前无本包编译/执行结论、full CI/Native/Supported/R1 完成声明。测试/审核结果写入独立新回执，不能预写为 0。
