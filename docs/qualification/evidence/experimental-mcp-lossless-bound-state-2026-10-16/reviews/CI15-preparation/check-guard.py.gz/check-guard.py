#!/usr/bin/env python3
"""Replay only the exact workflow log predicates, never Cargo or a database."""
from pathlib import Path
import argparse
import hashlib
import json
import shlex
import subprocess


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--log', required=True, type=Path)
    parser.add_argument('--workflow', type=Path, default=Path(__file__).parent / 'candidate.yml')
    parser.add_argument('--expect', choices=['accept', 'reject'], required=True)
    parser.add_argument('--receipt', required=True, type=Path)
    args = parser.parse_args()
    workflow = args.workflow.read_bytes()
    lines = workflow.decode().splitlines()
    start = lines.index('      - name: Qualify mandatory MCP host-bound state ingress')
    stop = lines.index('      - name: Upload MCP host-bound state ingress evidence', start)
    block = lines[start:stop]
    begin = next(i for i, line in enumerate(block) if line.startswith('          test "$(grep -c \'^running '))
    end = next(i for i in range(begin, len(block)) if block[i] == '          fi')
    predicates = '\n'.join(line[10:] for line in block[begin:end + 1]) + '\n'
    assert 'cargo ' not in predicates and 'mcp-bound-state-qualification.log' in predicates
    raw = args.log.read_bytes()
    shell = 'set -euo pipefail\n' + predicates.replace(
        'mcp-bound-state-qualification.log', shlex.quote(str(args.log.resolve()))
    )
    result = subprocess.run(['bash', '-c', shell], capture_output=True, text=True)
    accepted = result.returncode == 0
    receipt = {
        'scope': 'offline replay of exact workflow grep/test predicates only',
        'workflow': str(args.workflow.resolve()),
        'workflow_sha256': hashlib.sha256(workflow).hexdigest(),
        'log': str(args.log.resolve()),
        'log_bytes': len(raw),
        'log_sha256': hashlib.sha256(raw).hexdigest(),
        'exact_predicates': predicates,
        'bash_predicate_exit_code': result.returncode,
        'accepted': accepted,
        'expected': args.expect,
        'expectation_satisfied': accepted == (args.expect == 'accept'),
        'stdout': result.stdout,
        'stderr': result.stderr,
        'new_Cargo_network_DB_or_product_execution': False,
        'CI_execution_or_full_job_qualified': False,
    }
    args.receipt.parent.mkdir(parents=True, exist_ok=True)
    args.receipt.write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'predicate_exit_code': result.returncode, 'accepted': accepted,
                      'expected': args.expect, 'expectation_satisfied': receipt['expectation_satisfied']}))
    raise SystemExit(0 if receipt['expectation_satisfied'] else 1)


if __name__ == '__main__':
    main()
