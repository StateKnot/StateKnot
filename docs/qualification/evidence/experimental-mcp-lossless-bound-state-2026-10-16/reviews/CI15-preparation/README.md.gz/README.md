# MCP lossless-bound-state CI candidate v2

This is an ignored workflow candidate; actual main/workflow and all Oct15 sealed evidence remain untouched. No Cargo, network, database or GitHub CI is executed by this preparation.

`candidate.yml` SHA256 is `2c69f7e78b0b4c9b703e52864cdfd029b3cfc74d9ecceb31510768195b0e45ad`. Relative to the old MCP14 candidate `6568a90f…`, only the exact `running15` inventory and `15 passed/0 failed/0 ignored/0 filtered` summary predicates change. The mandatory Cargo command remains per-package default features with `--nocapture --test-threads=1`; the one complete PostgreSQL marker and no-skip requirements remain exact.

The original Git85f PostgreSQL job's53 steps/31 run commands, six adopted opt1 environment values,30m total budget, pinned images and all original assertions/leases/quantum/stack/resources are preserved. The separate MCP addition is still two steps/one run, so the candidate totals55/32. No cache, warmup, budget split, extra resources or test omission is added.

The fixture binding is root's final Oct16 source-v3 `69af3a0f28d333f4e67d2b2cfcc2afc071938a6ce398527cc098d31ee8db60d8`/928,536 supplied inputs `ded1a866797889ed38df63f59f671c8a2c34a5b7373a688932cc714eae582794`. Its network file SHA is `13cd1ad067afe81df8e056ac8d59dffc5d3ad0ee80362505c41d7bade6511d87`. The new exact family is `network::lossless_numeric_argument_binding_is_enforced_over_tcp`. The static15 inventory is the original14 functions plus that one family; actual binary inventory and results must come from root's run, not this static count.

`check-guard.py` extracts only the exact grep/test predicates from the specified workflow. It never invokes the Cargo command or runs a server. Existing final Oct15 PG16/17 logs have14 tests and one correct standalone marker: the old14 predicates accept both, while the new15 predicates correctly reject both with Bash exit1. The offline harness exits0 because rejection was expected. Raw log identities and both outcomes are in `offline-old14/`.

The new15 positive replay is pending real mandatory PostgreSQL15-test logs. A workspace conditional pass, modified/synthetic log or an empty filter is not that positive control. Once actual logs exist:

```console
python3 check-guard.py --log /absolute/path/to/actual-pg16.log --expect accept --receipt /new/positive-pg16.json
python3 check-guard.py --log /absolute/path/to/actual-pg17.log --expect accept --receipt /new/positive-pg17.json
```

Even actual macOS opt0/serial15 success and successful predicate replay do not qualify this Ubuntu/test-opt1 composition, the complete30m GitHub job, a production host mapping backend, Supported status or R1. Those remain separate execution/acceptance boundaries.
