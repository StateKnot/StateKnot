#!/usr/bin/env python3
"""Independent read-only artifact/Spec cross-check; predicates run offline only."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

REPO = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
BASE = REPO / ".local-verification/2026-10-16"
DOC = BASE / "mcp-lossless-adoption-docs-v3"
CI = BASE / "mcp-lossless-ci-candidate-v2"
GATES = BASE / "mcp-lossless-qualification-v3/network-enabled-retry-v1"
NATIVE = GATES / "native-serial-default-profile-v4"
SOURCE = BASE / "mcp-lossless-bound-state-source-v3"
SHA = lambda raw: hashlib.sha256(raw).hexdigest()
HEAD = "85f3fd556ff7623ef148da7e335b67e08dd022ad"


def load(path):
    return json.loads(path.read_text())


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def yaml(path):
    return json.loads(subprocess.check_output(["ruby", "-rpsych", "-rjson", "-e",
        "puts JSON.generate(Psych.load_file(ARGV[0]))", str(path)]))


def main():
    inputs = []
    def bind(path):
        raw = path.read_bytes()
        inputs.append({"path": str(path.relative_to(REPO)), "bytes": len(raw), "sha256": SHA(raw)})
        return raw
    assert SHA(bind(DOC / "manifest.json")) == "7f5932336ba7c1bf0cc321c12c072a2e44164bf93cd1ef55fe8cd9ea4ba191e3"
    assert SHA(bind(DOC / "freeze.json")) == "46a48917e0d68a15b680c49e87ed66bb60c1b19d6db0f221f2461b7a254fe9c0"
    for item in load(DOC / "manifest.json")["files"]:
        raw = bind(DOC / item["path"])
        assert len(raw) == item["bytes"] and SHA(raw) == item["sha256"]
    documents = load(DOC / "candidate-documents.json")["files"]
    assert len(documents) == 7
    for item in documents:
        original = subprocess.check_output(["git", "show", HEAD + ":" + item["path"]], cwd=REPO)
        assert original == (DOC / "baseline" / item["path"]).read_bytes()
    assert bind(DOC / "candidate.patch")
    for item in load(DOC / "fact-bindings.json")["refs"]:
        raw = bind(REPO / item["path"])
        assert len(raw) == item["bytes"] and SHA(raw) == item["sha256"]
    summary = load(GATES / "six-gates-summary.json")
    assert summary["gate_count"] == 6 and all(r["exit_code"] == 0 for r in summary["receipts"])
    counts = {}
    for kind, expected in (("workspace", (99, 2098, 0, 6, 0)), ("doctests", (10, 48, 0, 0, 0))):
        raw = bind(GATES / (kind + ".log"))
        receipt = load(GATES / (kind + ".receipt.json"))
        assert SHA(raw) == receipt["log_sha256"]
        rows = re.findall(rb"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; \d+ measured; (\d+) filtered out", raw)
        total = (len(rows), *(sum(int(r[n]) for r in rows) for n in range(4)))
        assert total == expected, total
        counts[kind] = total
    compiled = load(GATES / "compiled-inputs.json")
    rows = compiled["files"]
    assert len(rows) == 536
    old_digest = SHA(json.dumps(rows, sort_keys=True, separators=(",", ":")).encode())
    sorted_digest = SHA(json.dumps(sorted(rows, key=lambda r: r["path"]), sort_keys=True, separators=(",", ":")).encode())
    assert old_digest == compiled["sha256"] == "ded1a866797889ed38df63f59f671c8a2c34a5b7373a688932cc714eae582794"
    assert sorted_digest == "cfd0f2f8b48e062567fb591be2e5c427781cb7db616ee20b942cc2174a775b2d"
    for row in rows:
        raw = (SOURCE / row["path"]).read_bytes()
        assert len(raw) == row["bytes"] and SHA(raw) == row["sha256"]
    binary = load(NATIVE / "binary.json")
    assert binary["cargo_artifact"]["fresh"] is False and binary["cargo_artifact"]["features"] == []
    assert binary["cargo_artifact"]["profile"]["opt_level"] == "0"
    assert SHA(bind(NATIVE / "artifacts/mcp_bound_state")) == binary["sha256"] == "0751e63128bf2fc1a28342f4e05bf62d7fd1416e9ae991032fa4136cf22bc8ed"
    assert len(binary["tests"]) == 15
    workflow_sha = SHA(bind(CI / "candidate.yml"))
    assert workflow_sha == "2c69f7e78b0b4c9b703e52864cdfd029b3cfc74d9ecceb31510768195b0e45ad"
    baseline = yaml(CI / "baseline85f.yml")
    candidate = yaml(CI / "candidate.yml")
    original_job = baseline["jobs"]["postgres"]
    candidate_job = candidate["jobs"]["postgres"]
    assert len(original_job["steps"]) == 53 and sum("run" in s for s in original_job["steps"]) == 31
    assert len(candidate_job["steps"]) == 55 and sum("run" in s for s in candidate_job["steps"]) == 32
    new_steps = [s for s in candidate_job["steps"] if s["name"] in ["Qualify mandatory MCP host-bound state ingress", "Upload MCP host-bound state ingress evidence"]]
    assert len(new_steps) == 2
    candidate_job["steps"] = [s for s in candidate_job["steps"] if s not in new_steps]
    assert candidate == baseline, "old full workflow changed after removing exact two additions"
    assert original_job["timeout-minutes"] == 30 and len(original_job["env"]) == 6
    assert new_steps[0]["env"]["STATEKNOT_REQUIRE_POSTGRES_TESTS"] == "1"
    assert "set -euo pipefail" in new_steps[0]["run"] and "2>&1 | tee" in new_steps[0]["run"]
    assert new_steps[1]["if"] == "always()" and new_steps[1]["with"]["if-no-files-found"] == "error"
    replay = []
    for major in (16, 17):
        rawlog = NATIVE / ("pg" + str(major) + ".log")
        raw = bind(rawlog)
        receipt = load(NATIVE / ("pg" + str(major) + ".receipt.json"))
        assert receipt["exit_code"] == 0 and SHA(raw) == receipt["log_sha256"]
        assert raw.count(b"\nrunning 15 tests\n") == 1
        assert len(re.findall(rb"^STATEKNOT_MCP_BOUND_STATE_POSTGRES:", raw, re.M)) == 1
        assert len(re.findall(rb"^STATEKNOT_MCP_BOUND_STATE_POSTGRES: consumers=3 positive_commits=6 refused_rebinds=12 tenant_ledgers=2 complete_journals=true$", raw, re.M)) == 1
        assert len(re.findall(rb"^test result: ok\. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in [0-9.]+s$", raw, re.M)) == 1
        command = ["python3", str(CI / "check-guard.py"), "--workflow", str(CI / "candidate.yml"), "--log", str(rawlog), "--expect", "accept", "--receipt", str(OUT / ("actual15-pg" + str(major) + ".json"))]
        done = subprocess.run(command, capture_output=True, text=True)
        assert done.returncode == 0, done.stderr
        replay.append({"major": major, "offline_replay_exit": done.returncode, "product_original_exit": receipt["exit_code"], "log_sha256": SHA(raw)})
    negative = []
    old_native = REPO / ".local-verification/2026-10-15/mcp-bound-state-integration-v1/retry-v5/native-serial-default-profile-v3"
    for major in (16, 17):
        old_log = old_native / ("pg" + str(major) + ".log")
        bind(old_log)
        done = subprocess.run(["python3", str(CI / "check-guard.py"), "--workflow", str(CI / "candidate.yml"), "--log", str(old_log), "--expect", "reject", "--receipt", str(OUT / ("old14-pg" + str(major) + ".json"))], capture_output=True, text=True)
        assert done.returncode == 0, done.stderr
        result = load(OUT / ("old14-pg" + str(major) + ".json"))
        assert result["bash_predicate_exit_code"] != 0 and result["accepted"] is False
        negative.append({"major": major, "outer_expectation_exit": 0, "actual_predicate_exit": result["bash_predicate_exit_code"]})
    for item in inputs:
        raw = (REPO / item["path"]).read_bytes()
        assert len(raw) == item["bytes"] and SHA(raw) == item["sha256"], "fixed input changed during review"
    save("input-identities.json", inputs)
    save("audit-receipt.json", {"fixed_baseline": HEAD, "fixed_docs_manifest": "7f5932336ba7c1bf0cc321c12c072a2e44164bf93cd1ef55fe8cd9ea4ba191e3",
        "documents": 7, "all_fixed_inputs_before_after_exact": True,
        "compiled_inputs_bytes_exact": 536, "original_rows_digest": old_digest,
        "relative_path_string_sorted_digest": sorted_digest, "different_orders_same_input_rows": True,
        "raw_test_recounts": counts, "actual15_offline_positive": replay, "old14_negative": negative,
        "old_workflow_exact_after_removing2steps": True, "original_steps_runs": [53,31],
        "new_steps_runs": [55,32], "timeout_minutes": 30, "six_env_unchanged": True,
        "new_Cargo_network_container_DB_CI_executed": False,
        "scope": "Independent document/CI Spec and raw evidence cross-check; not independent full production-source review or new execution"})
    print("PASS: fixed 7docs/CI15 independent Spec input checks and true-log predicates only; no new build/DB/CI")


if __name__ == "__main__":
    main()
