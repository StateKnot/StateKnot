// Copyright 2026 StateKnot contributors
// SPDX-License-Identifier: Apache-2.0

//! Real `PostgreSQL` + loopback protocol-adapter durability tests.

use std::{
    sync::{
        Arc, Mutex,
        atomic::{AtomicUsize, Ordering},
    },
    time::{Duration, Instant},
};

use serde_json::{Value, json};
use stateknot_core::{
    AgentResultProvenance, AttemptId, BoundedJson, BoxFuture, BudgetRemaining, BudgetUsage,
    CancellationSignal, CapabilityIdentity, CapabilityName, CapabilityReference, Checkpoint,
    CheckpointId, CheckpointState, CheckpointWrite, CompiledGraph, Digest, EventId,
    FailureCategory, GraphExecutionLimits, GraphNode, GraphReducerReference, GraphRoutes,
    InvocationId, IssuerId, JournalAppend, JournalEventIntent, JournalEventKind,
    JournalExpectation, JournalPayload, NodeActivation, NodeId, PrincipalIdentity, ReadyNodes,
    ResolvedBudget, RetryAdvice, RunId, RunTransition, SchemaId, SchemaReference, SubjectId,
    Superstep, TenantId, ThreadId, ToolArtifacts, ToolDescriptor, ToolExternalEffect, ToolInput,
    ToolInvocationHead, ToolInvocationIntent, ToolInvocationState, ToolInvocationStatus,
    ToolResult, ToolResultProvenance, Version,
};
use stateknot_integrations::{
    A2aAgentCapabilities, A2aAgentCard, A2aAgentCardEndpoint, A2aAgentCardTrust, A2aAgentInterface,
    A2aAgentSkill, A2aBearerTokenProvider, A2aBinding, A2aClient, A2aClientAuthorizationError,
    A2aClientAuthorizationRequest, A2aClientInterfacePin, A2aClientOperation, A2aClientOptions,
    A2aClientSecurity, A2aRemoteAgent, A2aRemoteAgentDelivery, A2aSecurityScheme,
    AnonymousMcpAuthorization, ApiKey, McpAuthorization, McpAuthorizationError, McpHttpOptions,
    McpRemoteTool, McpServerIdentity, McpToolApproval, McpToolAuthorizationRequest,
    McpToolAuthorizer, ProviderEndpoint, a2a_agent_card_digest, mcp_tool_descriptor_digest,
};
use stateknot_runtime::{
    DurableInvocationExecutor, DurableInvocationExecutorOptions, InvocationAttemptEventIds,
    InvocationBudgetContext, InvocationBudgetProvider, InvocationBudgetProviderError,
    InvocationClock, InvocationClockError, InvocationClockObservation, JsonSchemaRegistry,
    JsonSchemaRegistryBuilder, ModelProviderRegistryBuilder, ToolAttemptHandoff,
    ToolAttemptOutcome, ToolAttemptTerminalKind, ToolProviderRegistryBuilder,
    ToolReconciliationHandoff, ToolReconciliationKind, ToolReconciliationOutcome,
    register_standard_invocation_execution_event_schema,
};
use stateknot_store_postgres::{
    CheckpointCommitOutcome, GraphDefinitionRegistrationOutcome, PostgresStore,
    PostgresStoreOptions, PostgresTransportSecurity, RunProjection,
};
use tokio::{
    io::{AsyncReadExt, AsyncWriteExt},
    net::TcpListener,
    sync::{Notify, mpsc},
    task::JoinHandle,
};

const DATABASE_URL_ENV: &str = "STATEKNOT_TEST_DATABASE_URL";
const REQUIRE_DATABASE_ENV: &str = "STATEKNOT_REQUIRE_POSTGRES_TESTS";
const DURABLE_A2A_TOKEN: &str = "durable-a2a-attempt-scoped";

struct PausedLostResponseMcpServer {
    endpoint: ProviderEndpoint,
    call_seen: mpsc::Receiver<()>,
    release_call: Arc<Notify>,
    tool_calls: Arc<AtomicUsize>,
    task: JoinHandle<()>,
}

struct PausedLostResponseA2aServer {
    card_endpoint: A2aAgentCardEndpoint,
    interface_pin: A2aClientInterfacePin,
    card: Value,
    call_seen: mpsc::Receiver<()>,
    release_call: Arc<Notify>,
    message_sends: Arc<AtomicUsize>,
    send_url: String,
    message_requests: Arc<Mutex<Vec<Vec<u8>>>>,
    task: JoinHandle<()>,
}

fn durable_a2a_card(interface_url: &str, authorized: bool) -> Value {
    let builder = A2aAgentCard::builder(
        "StateKnot durable A2A test",
        "Applies one test message before losing its response.",
        "1.0.0",
    )
    .unwrap()
    .capabilities(A2aAgentCapabilities::new())
    .interface(A2aAgentInterface::new(interface_url, A2aBinding::HttpJson).unwrap())
    .unwrap()
    .default_input_modes(vec!["application/json".to_string()])
    .unwrap()
    .default_output_modes(vec!["application/json".to_string()])
    .unwrap()
    .skill(
        A2aAgentSkill::new(
            "write_once",
            "Write once",
            "Applies exactly one durable test write.",
            vec!["test".to_string()],
        )
        .unwrap()
        .with_input_modes(vec!["application/json".to_string()])
        .unwrap()
        .with_output_modes(vec!["application/json".to_string()])
        .unwrap(),
    )
    .unwrap();
    let builder = if authorized {
        builder
            .security_scheme(
                "oidc",
                A2aSecurityScheme::open_id_connect(
                    "https://issuer.example/.well-known/openid-configuration",
                    None,
                )
                .unwrap(),
            )
            .unwrap()
            .security_requirements(vec![std::collections::HashMap::from([(
                "oidc".to_string(),
                vec!["durable.invoke".to_string()],
            )])])
            .unwrap()
    } else {
        builder
    };
    builder.build().unwrap().to_json().unwrap()
}

impl PausedLostResponseA2aServer {
    async fn start() -> Self {
        Self::start_authorized(false).await
    }

    async fn start_authorized(authorized: bool) -> Self {
        let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let address = listener.local_addr().unwrap();
        let interface_url = format!("http://{address}/a2a");
        let card = durable_a2a_card(&interface_url, authorized);
        let encoded_card = serde_json::to_vec(&card).unwrap();
        let (call_sender, call_seen) = mpsc::channel(1);
        let release_call = Arc::new(Notify::new());
        let release = Arc::clone(&release_call);
        let message_sends = Arc::new(AtomicUsize::new(0));
        let sends = Arc::clone(&message_sends);
        let message_requests = Arc::new(Mutex::new(Vec::new()));
        let requests = Arc::clone(&message_requests);
        let task = tokio::spawn(async move {
            let (mut socket, _) = listener.accept().await.unwrap();
            let discovery = read_request(&mut socket).await;
            assert!(
                String::from_utf8_lossy(&discovery)
                    .starts_with("GET /.well-known/agent-card.json HTTP/1.1")
            );
            write_a2a_response(&mut socket, "application/json", &encoded_card).await;

            let (mut socket, _) = listener.accept().await.unwrap();
            let request = read_request(&mut socket).await;
            assert!(
                String::from_utf8_lossy(&request).starts_with("POST /a2a/message:send HTTP/1.1")
            );
            let body: Value = serde_json::from_slice(request_body(&request)).unwrap();
            assert_eq!(body["configuration"]["returnImmediately"], true);
            if authorized {
                assert!(
                    String::from_utf8_lossy(&request)
                        .to_ascii_lowercase()
                        .contains(&format!("authorization: bearer {DURABLE_A2A_TOKEN}"))
                );
                assert!(find_bytes(request_body(&request), DURABLE_A2A_TOKEN.as_bytes()).is_none());
            }
            requests.lock().unwrap().push(request);
            sends.fetch_add(1, Ordering::SeqCst);
            call_sender.send(()).await.unwrap();
            release.notified().await;
            socket.shutdown().await.unwrap();
        });
        Self {
            card_endpoint: A2aAgentCardEndpoint::loopback_http(&format!(
                "http://{address}/.well-known/agent-card.json"
            ))
            .unwrap(),
            interface_pin: A2aClientInterfacePin::loopback_http(
                &interface_url,
                A2aBinding::HttpJson,
            )
            .unwrap(),
            card,
            call_seen,
            release_call,
            message_sends,
            send_url: format!("{interface_url}/message:send"),
            message_requests,
            task,
        }
    }
}

impl PausedLostResponseMcpServer {
    async fn start(input_schema: Value, output_schema: Value) -> Self {
        Self::start_authorized(input_schema, output_schema, false).await
    }

    async fn start_authorized(input_schema: Value, output_schema: Value, approved: bool) -> Self {
        let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let address = listener.local_addr().unwrap();
        let endpoint = ProviderEndpoint::loopback_http(&format!("http://{address}/mcp/")).unwrap();
        let (call_sender, call_seen) = mpsc::channel(1);
        let release_call = Arc::new(Notify::new());
        let release = Arc::clone(&release_call);
        let tool_calls = Arc::new(AtomicUsize::new(0));
        let calls = Arc::clone(&tool_calls);
        let task = tokio::spawn(async move {
            for _ in 0..3 {
                let (mut socket, _) = listener.accept().await.unwrap();
                let request = read_request(&mut socket).await;
                let message: Value = serde_json::from_slice(request_body(&request)).unwrap();
                let id = message["id"].clone();
                let response = match message["method"].as_str().unwrap() {
                    "server/discover" => json!({
                        "jsonrpc": "2.0",
                        "id": id,
                        "result": {
                            "resultType": "complete",
                            "supportedVersions": ["2026-07-28"],
                            "capabilities": {"tools": {}},
                            "ttlMs": 0,
                            "cacheScope": "private",
                            "_meta": {
                                "io.modelcontextprotocol/serverInfo": {
                                    "name": "stateknot-durable-test-mcp",
                                    "version": "1.0.0"
                                }
                            }
                        }
                    }),
                    "tools/list" => json!({
                        "jsonrpc": "2.0",
                        "id": id,
                        "result": {
                            "resultType": "complete",
                            "tools": [{
                                "name": "write_once",
                                "description": "Applies exactly one test write.",
                                "inputSchema": input_schema,
                                "outputSchema": output_schema,
                                "annotations": {
                                    "readOnlyHint": false,
                                    "destructiveHint": true
                                }
                            }],
                            "ttlMs": 0,
                            "cacheScope": "private"
                        }
                    }),
                    "tools/call" => {
                        if approved {
                            assert!(
                                String::from_utf8_lossy(&request)
                                    .contains("Bearer durable-attempt-scoped")
                            );
                            assert_eq!(
                                message["params"],
                                json!({"name":"write_once", "arguments":{"request":"apply-once"}, "_meta": {
                                    "io.modelcontextprotocol/clientCapabilities": {},
                                    "io.modelcontextprotocol/clientInfo": {"name":"stateknot", "version":env!("CARGO_PKG_VERSION")},
                                    "io.modelcontextprotocol/protocolVersion":"2026-07-28", "progressToken":1
                                }})
                            );
                        }
                        calls.fetch_add(1, Ordering::SeqCst);
                        call_sender.send(()).await.unwrap();
                        release.notified().await;
                        socket.shutdown().await.unwrap();
                        continue;
                    }
                    method => panic!("unexpected MCP method {method}"),
                };
                write_json_response(&mut socket, &response).await;
            }
        });
        Self {
            endpoint,
            call_seen,
            release_call,
            tool_calls,
            task,
        }
    }
}

async fn read_request(socket: &mut tokio::net::TcpStream) -> Vec<u8> {
    let mut bytes = Vec::new();
    let mut buffer = [0_u8; 2048];
    loop {
        let read = socket.read(&mut buffer).await.unwrap();
        assert_ne!(read, 0, "request ended before its declared body");
        bytes.extend_from_slice(&buffer[..read]);
        let Some(header_end) = find_bytes(&bytes, b"\r\n\r\n") else {
            continue;
        };
        let headers = String::from_utf8_lossy(&bytes[..header_end]);
        let content_length = headers
            .lines()
            .find_map(|line| {
                let (name, value) = line.split_once(':')?;
                name.eq_ignore_ascii_case("content-length")
                    .then(|| value.trim().parse::<usize>().ok())
                    .flatten()
            })
            .unwrap_or(0);
        if bytes.len() >= header_end + 4 + content_length {
            return bytes;
        }
    }
}

fn find_bytes(haystack: &[u8], needle: &[u8]) -> Option<usize> {
    haystack
        .windows(needle.len())
        .position(|window| window == needle)
}

fn request_body(request: &[u8]) -> &[u8] {
    let header_end = find_bytes(request, b"\r\n\r\n").unwrap();
    &request[header_end + 4..]
}

async fn write_json_response(socket: &mut tokio::net::TcpStream, response: &Value) {
    let encoded = serde_json::to_vec(response).unwrap();
    let headers = format!(
        "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: {}\r\nConnection: close\r\n\r\n",
        encoded.len()
    );
    socket.write_all(headers.as_bytes()).await.unwrap();
    socket.write_all(&encoded).await.unwrap();
    socket.shutdown().await.unwrap();
}

async fn write_a2a_response(socket: &mut tokio::net::TcpStream, content_type: &str, body: &[u8]) {
    let headers = format!(
        "HTTP/1.1 200 OK\r\nContent-Type: {content_type}\r\nContent-Length: {}\r\nConnection: close\r\n\r\n",
        body.len()
    );
    socket.write_all(headers.as_bytes()).await.unwrap();
    socket.write_all(body).await.unwrap();
    socket.shutdown().await.unwrap();
}

struct StaticInvocationBudget {
    resolved: ResolvedBudget,
}

impl InvocationBudgetProvider for StaticInvocationBudget {
    fn remaining(
        &self,
        context: InvocationBudgetContext,
    ) -> BoxFuture<'_, Result<BudgetRemaining, InvocationBudgetProviderError>> {
        let remaining = self
            .resolved
            .remaining(&BudgetUsage::zero(), context.observed_at())
            .map_err(InvocationBudgetProviderError::new);
        Box::pin(async move { remaining })
    }
}

struct FixedInvocationClock;

impl InvocationClock for FixedInvocationClock {
    fn observe(&self) -> Result<InvocationClockObservation, InvocationClockError> {
        Ok(InvocationClockObservation::new(
            "2029-12-31T23:59:30.000000Z".parse().unwrap(),
            Instant::now(),
        ))
    }
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
#[allow(clippy::too_many_lines)]
async fn mcp_write_is_durable_before_dispatch_and_reconciles_without_redispatch() {
    Box::pin(qualify_mcp_write(false, false)).await;
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn mcp_approved_write_is_authorized_after_durable_start_and_reconciles_once() {
    Box::pin(qualify_mcp_write(true, false)).await;
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn mcp_approved_denial_commits_without_remote_dispatch_or_repeat_authorization() {
    Box::pin(qualify_mcp_write(true, true)).await;
}

struct DurablePolicy {
    store: PostgresStore,
    deny: bool,
    calls: AtomicUsize,
}

impl McpToolAuthorizer for DurablePolicy {
    fn resolve_startup(
        &self,
        _: &ToolDescriptor,
    ) -> BoxFuture<'_, Result<McpAuthorization, McpAuthorizationError>> {
        Box::pin(async { Ok(McpAuthorization::Anonymous) })
    }

    fn authorize_call<'a>(
        &'a self,
        request: McpToolAuthorizationRequest<'a>,
    ) -> BoxFuture<'a, Result<McpAuthorization, McpAuthorizationError>> {
        Box::pin(async move {
            self.calls.fetch_add(1, Ordering::SeqCst);
            let context = request.context();
            let invocation = self
                .store
                .load_tool_invocation(
                    context.tenant_id(),
                    context.run_id(),
                    context.invocation_id(),
                )
                .await
                .unwrap();
            assert_eq!(invocation.status(), ToolInvocationStatus::Executing);
            assert_eq!(invocation.attempt_id(), Some(context.attempt_id()));
            assert_eq!(
                context.origin_event_id(),
                Some(invocation.journal_head().event_id())
            );
            assert_eq!(invocation.intent().input(), request.input());
            assert_eq!(invocation.intent().descriptor(), request.descriptor());
            if self.deny {
                Err(McpAuthorizationError::PermissionDenied)
            } else {
                Ok(McpAuthorization::Bearer(
                    ApiKey::new("durable-attempt-scoped").unwrap(),
                ))
            }
        })
    }
}

#[allow(clippy::too_many_lines)]
async fn qualify_mcp_write(approved: bool, deny: bool) {
    let Some(store) = test_store().await else {
        return;
    };
    let (schemas, input_schema, input_document, output_schema, output_document) = tool_schemas();
    let descriptor = write_descriptor(&input_schema, &output_schema);
    let pin = mcp_tool_descriptor_digest(&json!({
        "name":"write_once", "description":"Applies exactly one test write.",
        "inputSchema":input_document, "outputSchema":output_document,
        "annotations":{"readOnlyHint":false,"destructiveHint":true}
    }))
    .unwrap();
    let policy = Arc::new(DurablePolicy {
        store: store.clone(),
        deny,
        calls: AtomicUsize::new(0),
    });
    let mut server = if approved {
        PausedLostResponseMcpServer::start_authorized(input_document, output_document, true).await
    } else {
        PausedLostResponseMcpServer::start(input_document, output_document).await
    };
    let adapter = if approved {
        McpRemoteTool::connect_authorized(
            descriptor.clone(),
            "write_once",
            server.endpoint.clone(),
            McpServerIdentity::new("stateknot-durable-test-mcp", "1.0.0").unwrap(),
            Arc::new(schemas.clone()),
            McpToolApproval::new(pin, policy.clone()),
            McpHttpOptions::default(),
        )
        .await
        .unwrap()
    } else {
        McpRemoteTool::connect(
            descriptor.clone(),
            "write_once",
            server.endpoint.clone(),
            McpServerIdentity::new("stateknot-durable-test-mcp", "1.0.0").unwrap(),
            Arc::new(schemas.clone()),
            Arc::new(AnonymousMcpAuthorization),
            McpHttpOptions::default(),
        )
        .await
        .unwrap()
    };

    let graph = graph();
    let tenant_id = TenantId::new(format!("mcp-durable-{}", RunId::generate())).unwrap();
    let run_id = RunId::generate();
    let checkpoint = start_run(&store, &graph, tenant_id.clone(), run_id).await;
    let lease = store
        .claim_lease(&tenant_id, run_id, AttemptId::generate())
        .await
        .unwrap()
        .lease()
        .clone();
    let invocation_id = InvocationId::generate();
    let prepared = store
        .prepare_tool_invocation(
            worker_append(
                tenant_id.clone(),
                run_id,
                EventId::generate(),
                checkpoint.event().head(),
                lease.fence().clone(),
            ),
            ToolInvocationIntent::new(
                invocation_activation(checkpoint.checkpoint()),
                invocation_id,
                descriptor.clone(),
                ToolInput::new(
                    input_schema,
                    BoundedJson::try_from_value(json!({"request": "apply-once"})).unwrap(),
                )
                .unwrap(),
                descriptor.limits().clone(),
            )
            .unwrap(),
        )
        .await
        .unwrap();

    let mut tools = ToolProviderRegistryBuilder::new();
    tools.register(Arc::new(adapter)).unwrap();
    let executor = DurableInvocationExecutor::with_clock(
        store.clone(),
        schemas,
        ModelProviderRegistryBuilder::new().build(),
        tools.build(),
        Arc::new(StaticInvocationBudget {
            resolved: invocation_budget(),
        }),
        Arc::new(FixedInvocationClock),
        DurableInvocationExecutorOptions::default(),
    )
    .unwrap();
    let handoff = ToolAttemptHandoff::new(
        lease.fence().clone(),
        prepared.invocation().clone(),
        AttemptId::generate(),
        InvocationAttemptEventIds::generate(),
        CancellationSignal::never(),
        None,
    )
    .unwrap();
    let executing_task = {
        let executor = executor.clone();
        let handoff = handoff.clone();
        tokio::spawn(async move { executor.execute_tool(handoff).await })
    };

    if deny {
        let outcome = tokio::time::timeout(Duration::from_secs(5), executing_task)
            .await
            .unwrap()
            .unwrap()
            .unwrap();
        assert!(matches!(
            outcome,
            ToolAttemptOutcome::Dispatched {
                terminal: ToolAttemptTerminalKind::Error,
                ..
            }
        ));
        let failed = store
            .load_tool_invocation(&tenant_id, run_id, invocation_id)
            .await
            .unwrap();
        assert_eq!(failed.status(), ToolInvocationStatus::Failed);
        assert!(matches!(
            executor.execute_tool(handoff).await.unwrap(),
            ToolAttemptOutcome::Recovered { .. }
        ));
        let duplicate = store
            .load_tool_invocation(&tenant_id, run_id, invocation_id)
            .await
            .unwrap();
        assert_eq!(
            failed.head(),
            duplicate.head(),
            "duplicate must not append another ledger revision"
        );
        assert_eq!(policy.calls.load(Ordering::SeqCst), 1);
        assert_eq!(server.tool_calls.load(Ordering::SeqCst), 0);
        server.task.abort();
        assert!(server.task.await.unwrap_err().is_cancelled());
        println!(
            "\nSTATEKNOT_MCP_AUTHORIZATION_EVIDENCE={{\"case\":\"denial\",\"durable_before_authorization\":true,\"calls\":0,\"policy_calls\":1,\"duplicate_ledger_unchanged\":true}}"
        );
        store.close().await;
        return;
    }

    tokio::time::timeout(Duration::from_secs(5), server.call_seen.recv())
        .await
        .expect("MCP tools/call must reach the loopback server")
        .expect("MCP call observation channel must remain open");
    assert_eq!(
        store
            .load_tool_invocation(&tenant_id, run_id, invocation_id)
            .await
            .unwrap()
            .status(),
        ToolInvocationStatus::Executing,
        "the durable start must commit before MCP request I/O"
    );
    server.release_call.notify_one();

    let outcome = executing_task.await.unwrap().unwrap();
    assert!(matches!(
        outcome,
        ToolAttemptOutcome::Dispatched {
            terminal: ToolAttemptTerminalKind::Error,
            ..
        }
    ));
    let unknown = store
        .load_tool_invocation(&tenant_id, run_id, invocation_id)
        .await
        .unwrap();
    assert_eq!(unknown.status(), ToolInvocationStatus::Unknown);
    assert_eq!(server.tool_calls.load(Ordering::SeqCst), 1);

    assert!(matches!(
        executor.execute_tool(handoff.clone()).await.unwrap(),
        ToolAttemptOutcome::Recovered { .. }
    ));
    assert_eq!(server.tool_calls.load(Ordering::SeqCst), 1);

    let result = ToolResult::new(
        ToolResultProvenance::new(
            invocation_id,
            unknown.attempt_id().unwrap(),
            descriptor.metadata().identity().clone(),
        ),
        descriptor.output_schema().clone(),
        BoundedJson::try_from_value(json!({"status": "applied"})).unwrap(),
        ToolArtifacts::empty(),
    );
    let reconciliation = ToolReconciliationHandoff::result(
        lease.fence().clone(),
        unknown,
        EventId::generate(),
        result,
    )
    .unwrap();
    let committed = executor
        .commit_tool_reconciliation(reconciliation.clone())
        .await
        .unwrap();
    assert!(matches!(
        committed,
        ToolReconciliationOutcome::Committed { .. }
    ));
    assert_eq!(committed.kind(), ToolReconciliationKind::Result);
    assert_eq!(
        committed.invocation().status(),
        ToolInvocationStatus::Committed
    );
    assert_eq!(
        committed.event().payload().kind().as_str(),
        "tool-reconciliation-result-committed"
    );
    assert!(
        executor
            .commit_tool_reconciliation(reconciliation)
            .await
            .unwrap()
            .is_idempotent()
    );
    assert!(matches!(
        executor.execute_tool(handoff).await.unwrap(),
        ToolAttemptOutcome::Recovered { .. }
    ));
    assert_eq!(server.tool_calls.load(Ordering::SeqCst), 1);

    server.task.await.unwrap();
    if approved {
        assert_eq!(policy.calls.load(Ordering::SeqCst), 1);
        println!(
            "\nSTATEKNOT_MCP_AUTHORIZATION_EVIDENCE={{\"case\":\"lost_response\",\"durable_before_authorization\":true,\"calls\":1,\"policy_calls\":1,\"reconciliation_idempotent\":true}}"
        );
    }
    store.close().await;
}

struct DurableA2aPolicy {
    store: PostgresStore,
    expected: Mutex<Option<ToolAttemptHandoff>>,
    send_url: String,
    deny: bool,
    calls: AtomicUsize,
    observations: Mutex<Vec<(ToolInvocationHead, A2aClientAuthorizationRequest)>>,
}

impl A2aBearerTokenProvider for DurableA2aPolicy {
    fn resolve(
        &self,
        request: &A2aClientAuthorizationRequest,
    ) -> BoxFuture<'_, Result<ApiKey, A2aClientAuthorizationError>> {
        let request = request.clone();
        Box::pin(async move {
            self.calls.fetch_add(1, Ordering::SeqCst);
            let expected = self.expected.lock().unwrap().clone().unwrap();
            let attempt = request
                .attempt()
                .expect("durable adapter supplies its attempt");
            assert_eq!(attempt.tenant_id(), expected.fence().tenant_id());
            assert_eq!(attempt.run_id(), expected.fence().run_id());
            assert_eq!(
                attempt.invocation_id(),
                expected.invocation().intent().invocation_id()
            );
            assert_eq!(attempt.attempt_id(), expected.attempt_id());

            let invocation = self
                .store
                .load_tool_invocation(
                    attempt.tenant_id(),
                    attempt.run_id(),
                    attempt.invocation_id(),
                )
                .await
                .unwrap();
            assert_eq!(invocation.status(), ToolInvocationStatus::Executing);
            assert_eq!(invocation.attempt_id(), Some(expected.attempt_id()));
            assert_eq!(invocation.intent(), expected.invocation().intent());
            assert_eq!(invocation.previous(), Some(&expected.invocation().head()));
            assert_eq!(
                invocation.journal_head().event_id(),
                expected.events().start()
            );
            assert_eq!(
                invocation.revision(),
                expected.invocation().revision().checked_next().unwrap()
            );
            let (event, anchored) = self
                .store
                .load_tool_invocation_revision(
                    attempt.tenant_id(),
                    attempt.run_id(),
                    attempt.invocation_id(),
                    invocation.revision(),
                )
                .await
                .unwrap();
            assert_eq!(anchored.head(), invocation.head());
            assert_eq!(&event.head(), invocation.journal_head());
            assert_eq!(event.source().worker_fence(), Some(expected.fence()));
            assert_eq!(event.payload().kind().as_str(), "tool-attempt-started");

            assert_eq!(request.operation(), A2aClientOperation::SendMessage);
            assert_eq!(request.binding(), A2aBinding::HttpJson);
            assert_eq!(request.request_method(), "POST");
            assert_eq!(request.request_url(), self.send_url);
            assert_eq!(request.remote_tenant(), None);
            assert_eq!(
                request.required_scopes().collect::<Vec<_>>(),
                ["durable.invoke"]
            );
            let bytes = request.request_body().expect("SendMessage has a body");
            let body: Value = serde_json::from_slice(bytes).unwrap();
            assert_eq!(
                body,
                json!({
                    "message": {
                        "messageId": format!("stateknot-attempt-{}", expected.attempt_id()),
                        "role": "ROLE_USER",
                        "parts": [{
                            "data": invocation.intent().input().value().as_value(),
                            "mediaType": "application/json"
                        }]
                    },
                    "configuration": {
                        "acceptedOutputModes": ["application/json"],
                        "returnImmediately": true
                    }
                })
            );
            assert!(find_bytes(bytes, DURABLE_A2A_TOKEN.as_bytes()).is_none());
            let debug = format!("{request:?}");
            assert!(!debug.contains(request.request_url()));
            assert!(!debug.contains("apply-once"));
            self.observations
                .lock()
                .unwrap()
                .push((invocation.head(), request));
            if self.deny {
                Err(A2aClientAuthorizationError::PermissionDenied)
            } else {
                Ok(ApiKey::new(DURABLE_A2A_TOKEN).unwrap())
            }
        })
    }
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn a2a_send_is_durable_before_dispatch_and_unknown_is_not_redispatched() {
    Box::pin(qualify_a2a_send(false, false)).await;
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn a2a_authorized_send_reads_the_durable_start_and_recovery_does_not_send_again() {
    Box::pin(qualify_a2a_send(true, false)).await;
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn a2a_authorized_denial_commits_once_without_business_send_or_policy_repeat() {
    Box::pin(qualify_a2a_send(true, true)).await;
}

#[allow(clippy::too_many_lines)]
async fn qualify_a2a_send(authorized: bool, deny: bool) {
    let Some(store) = test_store().await else {
        return;
    };
    let (schemas, input_schema, _, output_schema, _) = tool_schemas();
    let descriptor = a2a_write_descriptor(&input_schema, &output_schema);
    let descriptor = if authorized {
        let mut value = serde_json::to_value(&descriptor).unwrap();
        value["resources"]["credentials"] = Value::Bool(true);
        serde_json::from_value(value).unwrap()
    } else {
        descriptor
    };
    let mut server = if authorized {
        PausedLostResponseA2aServer::start_authorized(true).await
    } else {
        PausedLostResponseA2aServer::start().await
    };
    let policy = Arc::new(DurableA2aPolicy {
        store: store.clone(),
        expected: Mutex::new(None),
        send_url: server.send_url.clone(),
        deny,
        calls: AtomicUsize::new(0),
        observations: Mutex::new(Vec::new()),
    });
    let client = A2aClient::discover(
        server.card_endpoint.clone(),
        vec![server.interface_pin.clone()],
        A2aAgentCardTrust::CanonicalSha256(a2a_agent_card_digest(&server.card).unwrap()),
        if authorized {
            A2aClientSecurity::bearer("oidc", policy.clone()).unwrap()
        } else {
            A2aClientSecurity::Anonymous
        },
        Vec::new(),
        A2aClientOptions::default(),
    )
    .await
    .unwrap();
    let adapter = A2aRemoteAgent::bind(
        descriptor.clone(),
        client,
        "write_once",
        A2aRemoteAgentDelivery::AtMostOnce,
        Arc::new(schemas.clone()),
    )
    .unwrap();

    let graph = graph();
    let tenant_id = TenantId::new(format!("a2a-durable-{}", RunId::generate())).unwrap();
    let run_id = RunId::generate();
    let checkpoint = start_run(&store, &graph, tenant_id.clone(), run_id).await;
    let lease = store
        .claim_lease(&tenant_id, run_id, AttemptId::generate())
        .await
        .unwrap()
        .lease()
        .clone();
    let invocation_id = InvocationId::generate();
    let prepared = store
        .prepare_tool_invocation(
            worker_append(
                tenant_id.clone(),
                run_id,
                EventId::generate(),
                checkpoint.event().head(),
                lease.fence().clone(),
            ),
            ToolInvocationIntent::new(
                invocation_activation(checkpoint.checkpoint()),
                invocation_id,
                descriptor.clone(),
                ToolInput::new(
                    input_schema,
                    BoundedJson::try_from_value(json!({"request": "apply-once"})).unwrap(),
                )
                .unwrap(),
                descriptor.limits().clone(),
            )
            .unwrap(),
        )
        .await
        .unwrap();

    let mut tools = ToolProviderRegistryBuilder::new();
    tools.register(Arc::new(adapter)).unwrap();
    let executor = DurableInvocationExecutor::with_clock(
        store.clone(),
        schemas,
        ModelProviderRegistryBuilder::new().build(),
        tools.build(),
        Arc::new(StaticInvocationBudget {
            resolved: invocation_budget(),
        }),
        Arc::new(FixedInvocationClock),
        DurableInvocationExecutorOptions::default(),
    )
    .unwrap();
    let handoff = ToolAttemptHandoff::new(
        lease.fence().clone(),
        prepared.invocation().clone(),
        AttemptId::generate(),
        InvocationAttemptEventIds::generate(),
        CancellationSignal::never(),
        None,
    )
    .unwrap();
    *policy.expected.lock().unwrap() = Some(handoff.clone());
    let executing_task = {
        let executor = executor.clone();
        let handoff = handoff.clone();
        tokio::spawn(async move { executor.execute_tool(handoff).await })
    };

    if deny {
        let outcome = tokio::time::timeout(Duration::from_secs(5), executing_task)
            .await
            .unwrap()
            .unwrap()
            .unwrap();
        assert!(matches!(
            outcome,
            ToolAttemptOutcome::Dispatched {
                terminal: ToolAttemptTerminalKind::Error,
                ..
            }
        ));
        let failed = store
            .load_tool_invocation(&tenant_id, run_id, invocation_id)
            .await
            .unwrap();
        assert_eq!(failed.status(), ToolInvocationStatus::Failed);
        let ToolInvocationState::Failed { error } = failed.state() else {
            panic!("authorization denial must commit known failure evidence");
        };
        assert_eq!(error.external_effect(), ToolExternalEffect::NotStarted);
        assert_eq!(error.failure().retry_advice(), RetryAdvice::Never);
        assert_eq!(
            error.failure().category(),
            FailureCategory::PermissionDenied
        );
        assert_eq!(
            error.failure().code().as_str(),
            "authorization.permission_denied"
        );
        {
            let observations = policy.observations.lock().unwrap();
            assert_eq!(observations.len(), 1);
            assert_eq!(failed.previous(), Some(&observations[0].0));
        }
        assert_eq!(
            failed.journal_head().event_id(),
            handoff.events().terminal()
        );
        assert!(matches!(
            executor.execute_tool(handoff).await.unwrap(),
            ToolAttemptOutcome::Recovered { .. }
        ));
        let duplicate = store
            .load_tool_invocation(&tenant_id, run_id, invocation_id)
            .await
            .unwrap();
        assert_eq!(
            failed.head(),
            duplicate.head(),
            "duplicate must not append a ledger revision"
        );
        assert_eq!(policy.calls.load(Ordering::SeqCst), 1);
        assert_eq!(server.message_sends.load(Ordering::SeqCst), 0);
        assert!(server.message_requests.lock().unwrap().is_empty());
        assert!(
            tokio::time::timeout(Duration::from_millis(150), server.call_seen.recv())
                .await
                .is_err()
        );
        server.task.abort();
        assert!(server.task.await.unwrap_err().is_cancelled());
        println!(
            "\nSTATEKNOT_A2A_AUTHORIZATION_EVIDENCE={{\"case\":\"denial\",\"durable_start_verified\":true,\"payload_from_full_input\":true,\"calls\":0,\"policy_calls\":1,\"duplicate_ledger_unchanged\":true}}"
        );
        store.close().await;
        return;
    }

    tokio::time::timeout(Duration::from_secs(5), server.call_seen.recv())
        .await
        .expect("A2A message/send must reach the loopback server")
        .expect("A2A call observation channel must remain open");
    assert_eq!(
        store
            .load_tool_invocation(&tenant_id, run_id, invocation_id)
            .await
            .unwrap()
            .status(),
        ToolInvocationStatus::Executing,
        "the durable start must commit before A2A request I/O"
    );
    server.release_call.notify_one();

    let outcome = executing_task.await.unwrap().unwrap();
    assert!(matches!(
        outcome,
        ToolAttemptOutcome::Dispatched {
            terminal: ToolAttemptTerminalKind::Error,
            ..
        }
    ));
    let unknown = store
        .load_tool_invocation(&tenant_id, run_id, invocation_id)
        .await
        .unwrap();
    assert_eq!(unknown.status(), ToolInvocationStatus::Unknown);
    assert_eq!(server.message_sends.load(Ordering::SeqCst), 1);
    assert!(matches!(
        executor.execute_tool(handoff).await.unwrap(),
        ToolAttemptOutcome::Recovered { .. }
    ));
    assert_eq!(server.message_sends.load(Ordering::SeqCst), 1);

    if authorized {
        let duplicate = store
            .load_tool_invocation(&tenant_id, run_id, invocation_id)
            .await
            .unwrap();
        assert_eq!(unknown.head(), duplicate.head());
        assert_eq!(policy.calls.load(Ordering::SeqCst), 1);
        let ToolInvocationState::Unknown { error } = unknown.state() else {
            panic!("lost response must retain the ambiguous effect");
        };
        assert_eq!(error.external_effect(), ToolExternalEffect::Unknown);
        assert_eq!(
            error.failure().category(),
            FailureCategory::AmbiguousExternalOutcome
        );
        assert_eq!(error.failure().retry_advice(), RetryAdvice::ReconcileFirst);
        let observations = policy.observations.lock().unwrap();
        let requests = server.message_requests.lock().unwrap();
        assert_eq!(observations.len(), 1);
        assert_eq!(requests.len(), 1);
        assert_eq!(unknown.previous(), Some(&observations[0].0));
        assert_eq!(
            observations[0].1.request_body(),
            Some(request_body(&requests[0]))
        );
        let headers_end = find_bytes(&requests[0], b"\r\n\r\n").unwrap();
        let headers = std::str::from_utf8(&requests[0][..headers_end]).unwrap();
        let mut line = headers.lines().next().unwrap().split_ascii_whitespace();
        assert_eq!(observations[0].1.request_method(), line.next().unwrap());
        let target = line.next().unwrap();
        let host = headers
            .lines()
            .find_map(|header| {
                let (name, value) = header.split_once(':')?;
                name.eq_ignore_ascii_case("host").then(|| value.trim())
            })
            .unwrap();
        assert_eq!(
            observations[0].1.request_url(),
            format!("http://{host}{target}")
        );
    }

    server.task.await.unwrap();
    if authorized {
        println!(
            "\nSTATEKNOT_A2A_AUTHORIZATION_EVIDENCE={{\"case\":\"lost_response\",\"durable_start_verified\":true,\"payload_from_full_input\":true,\"calls\":1,\"policy_calls\":1,\"duplicate_ledger_unchanged\":true}}"
        );
    }
    store.close().await;
}

fn tool_schemas() -> (
    JsonSchemaRegistry,
    SchemaReference,
    Value,
    SchemaReference,
    Value,
) {
    let input = json!({
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "$id": "https://schemas.stateknot.test/mcp-durable-input/1.0.0",
        "type": "object",
        "properties": {"request": {"type": "string", "maxLength": 64}},
        "required": ["request"],
        "additionalProperties": false
    });
    let output = json!({
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "$id": "https://schemas.stateknot.test/mcp-durable-output/1.0.0",
        "type": "object",
        "properties": {"status": {"const": "applied"}},
        "required": ["status"],
        "additionalProperties": false
    });
    let input_reference = schema_reference(&input);
    let output_reference = schema_reference(&output);
    let mut builder = JsonSchemaRegistryBuilder::with_default_limits();
    register_standard_invocation_execution_event_schema(&mut builder).unwrap();
    builder
        .register(input_reference.clone(), input.clone())
        .unwrap();
    builder
        .register(output_reference.clone(), output.clone())
        .unwrap();
    (
        builder.build().unwrap(),
        input_reference,
        input,
        output_reference,
        output,
    )
}

fn schema_reference(document: &Value) -> SchemaReference {
    SchemaReference::new(
        document["$id"]
            .as_str()
            .unwrap()
            .parse::<SchemaId>()
            .unwrap(),
        Version::new(1, 0, 0),
        Digest::sha256(serde_json_canonicalizer::to_vec(document).unwrap()),
    )
}

fn write_descriptor(input: &SchemaReference, output: &SchemaReference) -> ToolDescriptor {
    let fixture: Value = serde_json::from_str(include_str!(
        "../../stateknot-core/tests/fixtures/core-tool-v1.json"
    ))
    .unwrap();
    let mut value = fixture["descriptors"]["valid"][0].clone();
    value["input_schema"] = serde_json::to_value(input).unwrap();
    value["output_schema"] = serde_json::to_value(output).unwrap();
    value["semantics"] = json!({
        "risk": "idempotent_write",
        "idempotency": "intrinsic",
        "status_query": true,
        "compensation": false
    });
    value["resources"] = json!({
        "network": "read_write",
        "filesystem": "none",
        "credentials": false,
        "dynamic_code": false
    });
    value["invocation"] = json!({
        "cancellation": "cooperative",
        "max_progress_events": "0"
    });
    serde_json::from_value(value).unwrap()
}

fn a2a_write_descriptor(input: &SchemaReference, output: &SchemaReference) -> ToolDescriptor {
    let mut value = serde_json::to_value(write_descriptor(input, output)).unwrap();
    value["semantics"] = json!({
        "risk": "non_idempotent_write",
        "idempotency": "unsupported",
        "status_query": false,
        "compensation": false
    });
    serde_json::from_value(value).unwrap()
}

fn graph() -> CompiledGraph {
    let (input_schema, _) = generic_schema("mcp-durable-graph-input");
    let (state_schema, _) = generic_schema("mcp-durable-graph-state");
    let (update_schema, _) = generic_schema("mcp-durable-graph-update");
    let (output_schema, _) = generic_schema("mcp-durable-graph-output");
    let node_id = NodeId::new("McpWrite").unwrap();
    CompiledGraph::compile(
        capability("mcp-durable-graph"),
        input_schema,
        state_schema,
        update_schema,
        output_schema,
        GraphReducerReference::new(
            capability("mcp-durable-reducer"),
            Digest::sha256(b"stateknot mcp durable integration reducer v1"),
        ),
        ReadyNodes::try_new([node_id.clone()]).unwrap(),
        [GraphNode::new(node_id, None, GraphRoutes::empty(), None, true).unwrap()],
        GraphExecutionLimits::new(Superstep::new(4).unwrap(), 1).unwrap(),
    )
    .unwrap()
}

fn generic_schema(name: &str) -> (SchemaReference, Value) {
    let id = format!("https://schemas.stateknot.test/{name}/1.0.0");
    let document = json!({
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "$id": id,
        "type": "object"
    });
    let reference = schema_reference(&document);
    (reference, document)
}

fn capability(name: &str) -> CapabilityIdentity {
    CapabilityIdentity::new(
        PrincipalIdentity::new(
            "https://issuer.example.com/stateknot"
                .parse::<IssuerId>()
                .unwrap(),
            "mcp-durable-tests".parse::<SubjectId>().unwrap(),
        ),
        CapabilityReference::new(CapabilityName::new(name).unwrap(), Version::new(1, 0, 0)),
    )
}

fn invocation_budget() -> ResolvedBudget {
    let fixture: Value = serde_json::from_str(include_str!(
        "../../stateknot-core/tests/fixtures/core-budget-v1.json"
    ))
    .unwrap();
    serde_json::from_value(fixture["resolved"]["valid"][0].clone()).unwrap()
}

fn invocation_activation(checkpoint: &Checkpoint) -> NodeActivation {
    let node_id = checkpoint.ready_nodes().iter().next().unwrap().clone();
    NodeActivation::for_ready_root(checkpoint, node_id).unwrap()
}

async fn test_store() -> Option<PostgresStore> {
    let database_url = match std::env::var(DATABASE_URL_ENV) {
        Ok(value) => value,
        Err(std::env::VarError::NotPresent) if std::env::var_os(REQUIRE_DATABASE_ENV).is_some() => {
            panic!("mandatory PostgreSQL test URL is missing")
        }
        Err(std::env::VarError::NotPresent) => return None,
        Err(std::env::VarError::NotUnicode(_)) => {
            panic!("PostgreSQL test URL must be valid Unicode")
        }
    };
    let options = PostgresStoreOptions::default()
        .with_transport_security(PostgresTransportSecurity::Disabled)
        .with_pool_size(1, 8)
        .with_acquire_timeout(Duration::from_secs(30))
        .with_transaction_timeouts(Duration::from_secs(5), Duration::from_secs(20));
    PostgresStore::migrate_database(&database_url, options.clone())
        .await
        .expect("migrations must succeed");
    Some(
        PostgresStore::connect(&database_url, options)
            .await
            .expect("test PostgreSQL must connect with an exact schema"),
    )
}

async fn start_run(
    store: &PostgresStore,
    graph: &CompiledGraph,
    tenant_id: TenantId,
    run_id: RunId,
) -> CheckpointCommitOutcome {
    let provenance = AgentResultProvenance::new(
        tenant_id.clone(),
        run_id,
        ThreadId::generate(),
        InvocationId::generate(),
        capability("mcp-durable-agent"),
    );
    let registered = store
        .register_graph_definition(tenant_id.clone(), graph.clone())
        .await
        .unwrap();
    assert!(matches!(
        registered,
        GraphDefinitionRegistrationOutcome::Registered(_)
            | GraphDefinitionRegistrationOutcome::Idempotent(_)
    ));
    let admitted = store.admit_run(provenance).await.unwrap();
    let state = CheckpointState::new(
        graph.state_schema().clone(),
        BoundedJson::try_from_value(json!({"step": "initial"})).unwrap(),
    )
    .unwrap();
    let write = CheckpointWrite::initial(
        tenant_id.clone(),
        run_id,
        CheckpointId::generate(),
        graph.reference(),
        state,
        graph.entry_nodes().clone(),
    )
    .unwrap();
    store
        .append_control_plane_checkpoint(
            control_append(tenant_id, run_id, EventId::generate()),
            RunProjection::transition(
                admitted.lifecycle().revision(),
                RunTransition::Start {
                    started_at: admitted.lifecycle().admitted_at(),
                },
            ),
            write,
        )
        .await
        .unwrap()
}

fn test_payload() -> JournalPayload {
    JournalPayload::new(
        SchemaReference::new(
            "https://schemas.stateknot.test/mcp-durable-control/1.0.0"
                .parse::<SchemaId>()
                .unwrap(),
            Version::new(1, 0, 0),
            Digest::sha256(b"stateknot mcp durable control schema"),
        ),
        JournalEventKind::new("mcp-durable-integration").unwrap(),
        BoundedJson::try_from_value(json!({"test": true})).unwrap(),
    )
    .unwrap()
}

fn control_append(tenant_id: TenantId, run_id: RunId, event_id: EventId) -> JournalAppend {
    JournalAppend::new(
        JournalExpectation::empty(),
        JournalEventIntent::control_plane(tenant_id, run_id, event_id, test_payload()).unwrap(),
    )
    .unwrap()
}

fn worker_append(
    tenant_id: TenantId,
    run_id: RunId,
    event_id: EventId,
    head: stateknot_core::JournalHead,
    fence: stateknot_core::RunFence,
) -> JournalAppend {
    JournalAppend::new(
        JournalExpectation::exact(head),
        JournalEventIntent::worker(tenant_id, run_id, event_id, fence, test_payload()).unwrap(),
    )
    .unwrap()
}
