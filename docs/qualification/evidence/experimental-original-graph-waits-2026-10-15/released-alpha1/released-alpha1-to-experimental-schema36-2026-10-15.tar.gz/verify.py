#!/usr/bin/env python3
# Copyright 2026 StateKnot contributors
# SPDX-License-Identifier: Apache-2.0
"""Read-only offline evidence verifier. No database access, test runs or compilation."""
import argparse
import datetime as dt
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

P = Path(__file__).resolve().parent

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def check(condition, message):
    if not condition:
        raise AssertionError(message)

def json_file(name):
    return json.loads((P / name).read_text())

index = json_file('artifact-index.json')
artifacts = {r['path'].removesuffix('.gz') if r['encoding'] == 'gzip' else r['path']: r for r in index['files']}

def raw(name):
    r = artifacts[name]
    data = (P / r['path']).read_bytes()
    return gzip.decompress(data) if r['encoding'] == 'gzip' else data

def doc(name):
    return json.loads(raw(name))

def timestamp(value):
    # PostgreSQL text timestamps use +00; Python 3.9 requires +00:00.
    return dt.datetime.fromisoformat(re.sub(r'([+-]\d{2})$', r'\1:00', value))

def canonical(rows):
    return sorted(json.dumps(r, sort_keys=True, separators=(',', ':')) for r in rows)

def archive_files(data):
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:*') as archive:
        members = archive.getmembers()
        check(all(m.isfile() for m in members), 'source/archive has unexpected non-file member')
        check(len({m.name for m in members}) == len(members), 'duplicate archive member')
        check(all(not m.name.startswith('/') and '..' not in Path(m.name).parts for m in members), 'unsafe archive path')
        return {m.name: archive.extractfile(m).read() for m in members}

def snapshot(major, phase):
    prefix = f'evidence/upgrade/pg{major}-writer-v2/{phase}/'
    metadata = doc(prefix + 'snapshot.json')
    data = {}
    for table, row in metadata['tables'].items():
        payload = raw(prefix + row['file'])
        check(sha(payload) == row['sha256'], f'{phase}/{table} raw snapshot hash')
        data[table] = json.loads(payload)
        check(len(data[table]) == row['rows'], f'{phase}/{table} row count')
    columns = raw(prefix + 'columns.json')
    check(sha(columns) == metadata['columns_sha256'], 'column metadata hash')
    check(sha(raw(prefix + 'schema.sql')) == metadata['schema_sha256'], 'raw pg_dump hash')
    return data, json.loads(columns)

def successful_native(prefix, receipt_name, log_name, binary_sha):
    receipt = doc(prefix + receipt_name)
    payload = raw(prefix + log_name)
    body = payload.decode()
    check(receipt['exit_code'] == 0, receipt_name + ' process did not succeed')
    check(receipt['binary_sha256'] == binary_sha, receipt_name + ' binary binding')
    check(receipt['log_sha256'] == sha(payload), receipt_name + ' original raw-log hash')
    check(re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', body) == [('ok', '1', '0', '0')], receipt_name + ' exact harness summary')
    check(receipt['summaries'] == [['ok', '1', '0', '0']], receipt_name + ' recorded summary')
    return receipt, body

def marker(body, name, expected):
    matches = re.findall(re.escape(name) + r' (\{[^\n]*\})', body)
    check(len(matches) == 1, name + ' marker count')
    check(json.loads(matches[0]) == expected, name + ' marker contents')

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--local-inputs', action='store_true', help='also read retained external binaries and frozen sources; never certifies main')
    args = parser.parse_args()
    manifest = json_file('manifest.json')
    actual = {str(p.relative_to(P)) for p in P.rglob('*') if p.is_file() and p.name != 'manifest.json' and '__pycache__' not in p.parts}
    check(actual == {r['path'] for r in manifest['files']}, 'manifest inventory mismatch')
    for r in manifest['files']:
        payload = (P / r['path']).read_bytes()
        check(len(payload) == r['bytes'] and sha(payload) == r['sha256'], 'bundle hash: ' + r['path'])
    for r in index['files']:
        payload = (P / r['path']).read_bytes()
        check(len(payload) == r['bytes'] and sha(payload) == r['sha256'], 'artifact compressed hash')
        if r['encoding'] == 'gzip':
            check(payload[:3] == b'\x1f\x8b\x08' and payload[3] == 0 and payload[4:8] == b'\0\0\0\0', 'gzip must have zero mtime and no filename')
            payload = gzip.decompress(payload)
        check(len(payload) == r['raw_bytes'] and sha(payload) == r['raw_sha256'], 'artifact original-byte hash')

    profile = json_file('report.json')
    for field, name in [('artifact_index_sha256', 'artifact-index.json'), ('source_proof_sha256', 'source-proof.json'), ('production_inputs_sha256', 'production-inputs.json'), ('bytea_proof_sha256', 'original-bytea-proof.json')]:
        check(profile[field] == sha((P / name).read_bytes()), 'profile evidence binding')
    check(not profile['main_compatibility_qualified'] and not profile['scope']['automatic_transfer_to_main_or_other_source'], 'qualification exceeds frozen candidate')
    for key in ['full_compatibility_matrix', 'n_minus_2_release_available', 'capacity_or_performance_qualified', 'full_native_qualified', 'r1_complete']:
        check(profile['scope'][key] is False, 'overbroad scope: ' + key)
    inventory = doc('evidence/released-inventory/receipt.json')
    check(inventory['tag_commit'] == profile['released_writer']['tag_commit'], 'release tag binding')
    package_contents = {}
    for package in inventory['packages']:
        name = package['name']
        versions = [json.loads(line) for line in raw(f'evidence/released-inventory/{name}-index.jsonl').decode().splitlines() if line]
        check([v['vers'] for v in versions] == ['0.1.0-alpha.1'], 'another recorded registry release exists')
        data = raw(f'evidence/released-inventory/{name}-0.1.0-alpha.1.crate')
        check(sha(data) == package['archive_sha256'] == versions[0]['cksum'], 'actual .crate registry checksum')
        package_contents[name] = archive_files(data)
    old_before = doc('evidence/released-build-v2/source-before.json')
    check(old_before == doc('evidence/released-build-v2/source-after.json') and len(old_before) == 63, 'old 63 source inputs changed')
    old_map = {r['path']: r['sha256'] for r in old_before}
    store_archive = package_contents['stateknot-store-postgres']
    check(len(store_archive) == 58, 'published Store archive file count')
    check(all(old_map.get(path) == sha(payload) for path, payload in store_archive.items()), 'original Store library/tests/lock were modified')
    fixture_info = doc('evidence/released-build-v2/external-fixtures.json')
    check(len(fixture_info['fixtures']) == 5, 'unexpected fixture additions')
    check(set(old_map) - set(store_archive) == {r['path'] for r in fixture_info['fixtures']}, 'nonfixture source addition')
    for r in fixture_info['fixtures']:
        check(sha(package_contents['stateknot-core'][r['archive_member']]) == r['sha256'] == old_map[r['path']], 'fixture is not original published Core bytes')
    lock_path = 'stateknot-store-postgres-0.1.0-alpha.1/Cargo.lock'
    check(sha(store_archive[lock_path]) == profile['released_writer']['original_lock_sha256'], 'original published lock')
    old_artifacts = [json.loads(line) for line in raw('evidence/released-build-v2/build.stdout.jsonl').decode().splitlines() if line]
    core_artifacts = [r for r in old_artifacts if r.get('reason') == 'compiler-artifact' and r.get('target', {}).get('name') == 'stateknot_core']
    check(len(core_artifacts) == 1 and core_artifacts[0]['package_id'] == 'registry+https://github.com/rust-lang/crates.io-index#stateknot-core@0.1.0-alpha.1', 'actual linked Core is not registry alpha.1')
    lock_text = store_archive[lock_path].decode()
    core_lock = re.search(r'(?ms)^\[\[package\]\]\nname = "stateknot-core"\n(.*?)(?=^\[\[package\]\]|\Z)', lock_text).group(1)
    check('version = "0.1.0-alpha.1"' in core_lock and 'source = "registry+https://github.com/rust-lang/crates.io-index"' in core_lock and 'checksum = "2c262ff26419879425dd7435107c128513e45f6ba763df5ce453605c35b3ac7e"' in core_lock, 'original lock registry Core checksum/version')
    check(doc('evidence/released-build-v2/command.json')[:2] == ['cargo', '+1.88.0'], 'released build fixed compiler')
    released_build = doc('evidence/released-build-v2/receipt.json')
    check(released_build['exit_code'] == 0 and released_build['all_original_published_store_files_unchanged'], 'released build qualification')
    check(released_build['registry_core_exact_version'] == '0.1.0-alpha.1', 'Core dependency is not actual published registry version')
    check(doc('evidence/released-build-v1/receipt.json')['exit_code'] == 101, 'first missing-fixture build not preserved')
    check(b"couldn't read" in raw('evidence/released-build-v1/build.stdout.jsonl'), 'missing fixture compiler diagnostics absent')

    parent = doc('evidence/upgrade/parent-source-manifest.json')
    check(parent['file_count'] == 919 and parent['source_tree_sha256'] == profile['reader_parent_source_tree_sha256'], 'parent candidate binding')
    source_before = doc('evidence/upgrade/reader-build-v2/source-before.json')
    check(source_before == doc('evidence/upgrade/reader-build-v2/source-after.json') and len(source_before) == 920, 'reader frozen source changed')
    reader_files = archive_files(raw('evidence/reader-source.tar'))
    check(set(reader_files) == {r['path'] for r in source_before}, 'reader archive inventory')
    for r in source_before:
        check(len(reader_files[r['path']]) == r['bytes'] and sha(reader_files[r['path']]) == r['sha256'], 'reader file hash ' + r['path'])
    harness = 'crates/stateknot-store-postgres/tests/postgres.rs'
    suffix = b'\n#[path = "postgres/released_alpha1_upgrade.rs"]\nmod released_alpha1_upgrade;\n'
    fixture = 'crates/stateknot-store-postgres/tests/postgres/released_alpha1_upgrade.rs'
    check(set(reader_files) - {r['path'] for r in parent['files']} == {fixture}, 'unexpected reader source additions')
    for r in parent['files']:
        payload = reader_files[r['path']]
        if r['path'] == harness:
            check(payload.endswith(suffix), 'unexpected harness mutation')
            payload = payload[:-len(suffix)]
        check(len(payload) == r['bytes'] and sha(payload) == r['sha256'], 'parent source changed ' + r['path'])
    inputs = json_file('production-inputs.json')
    check(inputs['file_count'] == len(inputs['files']) == 160, 'production input count')
    calculated_inputs = [r for r in source_before if (r['path'].startswith(('crates/stateknot-core/', 'crates/stateknot-store-postgres/')) and '/tests/' not in r['path']) or r['path'] in ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml'] or r['path'].startswith('.cargo/')]
    check(inputs['files'] == calculated_inputs, 'production input selection mismatch')
    build = doc('evidence/upgrade/reader-build-v2/receipt.json')
    check(build['exit_code'] == 0 and build['source_unchanged'] and len(build['artifacts']) == 1, 'reader strict build not successful')
    check(build['artifacts'][0]['sha256'] == profile['reader_binary_sha256'], 'reader binary hash')
    strict = doc('evidence/upgrade/reader-build-v2/command.json')['strict_env']
    check(strict == {'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_DEV_DEBUG': '0', 'CARGO_PROFILE_TEST_DEBUG': '0', 'RUSTFLAGS': '-D warnings', 'RUSTDOCFLAGS': '-D warnings'}, 'strict default-resource build environment')
    check(doc('evidence/upgrade/reader-build-v1/receipt.json')['exit_code'] == 101 and b'E0599' in raw('evidence/upgrade/reader-build-v1/build.stdout.jsonl'), 'first fixture compile red not retained')
    first_source = doc('evidence/upgrade/reader-build-v1/source-before.json')
    bad_fixture = raw('evidence/upgrade/reader-build-v1/released_alpha1_upgrade.rs')
    check(next(r['sha256'] for r in first_source if r['path'] == fixture) == sha(bad_fixture), 'first erroneous fixture hash')
    runner_red = doc('evidence/upgrade/runner-v1-diagnostic/receipt.json')
    check(all(r['original_runner_terminal_exit_code'] == 1 and r['offline_incorrect_assert_reproduction_exit'] == 1 and not r['original_native_exit_code_saved'] and r['sorted_versions'] == list(range(1, 27)) and r['all_success'] for r in runner_red['cases']), 'acquisition red/reproduction provenance')

    new_table_names = {'stateknot.' + t for t in ['graph_frame_barriers', 'graph_frame_caller_bindings', 'graph_frame_closed_callers', 'graph_frame_closures', 'graph_frame_entries', 'graph_frame_heads', 'graph_frame_returns', 'graph_frame_stacks', 'graph_wait_conditions', 'root_graph_barriers']}
    extra_columns = {'stateknot.run_checkpoints': {'graph_namespace', 'frame_identity_digest', 'frame_checkpoint_digest', 'frame_checkpoint_head_bytes', 'frame_checkpoint_head_checksum'}, 'stateknot.runs': {'checkpoint_graph_namespace'}, 'stateknot.agent_admissions': {'checkpoint_graph_namespace'}, 'stateknot.child_run_ownership': {'parent_graph_namespace'}}
    lease_fields = {'fencing_epoch', 'lease_acquired_at', 'lease_attempt_id', 'lease_expires_at', 'lease_renewed_at', 'updated_at'}
    bytea_proof = json_file('original-bytea-proof.json')
    for major in ['16', '17']:
        prefix = f'evidence/upgrade/pg{major}-writer-v2/'
        old_receipt, old_body = successful_native(prefix, 'released-writer.receipt.json', 'released-writer.native.log', profile['released_writer']['binary_sha256'])
        check(old_receipt['mandatory_database'] and old_receipt['schema_version'] == 26 and old_receipt['ledger_count'] == 26, 'old writer mandatory schema evidence')
        check(old_receipt['server'].split('|')[0] == {'16': '160015', '17': '170011'}[major] and old_receipt['server'].split('|')[1].split()[0] == {'16': '16.15', '17': '17.11'}[major], 'actual server version')
        check(old_receipt['original_resources'] == {'lease_seconds': 30, 'transaction_lock_timeout_seconds': 5, 'transaction_statement_timeout_seconds': 20, 'pool_min': 1, 'pool_max': 48, 'default_stack': True}, 'original resource profile')
        _, migrate_body = successful_native(prefix, 'migrate_exact_schema36.receipt.json', 'migrate_exact_schema36.native.log', profile['reader_binary_sha256'])
        marker(migrate_body, 'RELEASED_ALPHA1_MIGRATION', {'exact_schema36_catalog': True})
        _, replay_body = successful_native(prefix, 'replay_noninitial_and_complete_root.receipt.json', 'replay_noninitial_and_complete_root.native.log', profile['reader_binary_sha256'])
        marker(replay_body, 'RELEASED_ALPHA1_NONINITIAL', {'checkpoints': 2, 'barriers': 1, 'results': 1, 'higher_fence': True, 'pinned_reducer': True})
        marker(replay_body, 'RELEASED_ALPHA1_COMPLETE_ROOT', {'checkpoints': 2, 'barriers': 1, 'results': 1, 'frames': 0, 'returns': 0, 'waits': 0, 'journal_unchanged': True, 'revalidated': True, 'not_quarantined': True})
        old, old_cols = snapshot(major, 'schema26-before-reader')
        migrated, new_cols = snapshot(major, 'schema36-before-claim')
        after, after_cols = snapshot(major, 'schema36-after-replay')
        negative, negative_cols = snapshot(major, 'schema36-after-negative')
        check(set(migrated) == set(after) == set(negative) and len(after) == len(negative) == 55, 'post-migration table inventory changed')
        check(len(old) == 45 and sum(map(len, old.values())) == 39 and len(migrated) == 55, 'actual tables/rows')
        check(len(old['stateknot.run_checkpoints']) == 2 and len(old['stateknot.run_events']) == 4 and len(old['stateknot.pending_node_results']) == 1, 'original scenario facts')
        check(sorted(r['version'] for r in old['public._sqlx_migrations']) == list(range(1, 27)), 'old ledger versions')
        check(sorted(r['version'] for r in migrated['public._sqlx_migrations']) == list(range(1, 37)), 'new ledger versions')
        check(all(r['success'] for r in migrated['public._sqlx_migrations']), 'new ledger failed')
        check(set(migrated) - set(old) == new_table_names and all(not migrated[t] for t in new_table_names), 'migration new tables or invented rows')
        col_names = {}
        new_names = {}
        for c in old_cols:
            col_names.setdefault(c['table_schema'] + '.' + c['table_name'], set()).add(c['column_name'])
        for c in new_cols:
            new_names.setdefault(c['table_schema'] + '.' + c['table_name'], set()).add(c['column_name'])
        for table, rows in old.items():
            m = migrated[table]
            if table == 'public._sqlx_migrations':
                m = [r for r in m if r['version'] <= 26]
            check(canonical(rows) == canonical([{k: r[k] for k in col_names[table]} for r in m]), 'original migration row/column mutation ' + table)
            check(new_names[table] - col_names[table] == extra_columns.get(table, set()) and col_names[table] <= new_names[table], 'unexpected added/removed column ' + table)
        for row in migrated['stateknot.run_checkpoints']:
            check(row['graph_namespace'] == '' and all(row[k] is None for k in extra_columns['stateknot.run_checkpoints'] - {'graph_namespace'}), 'checkpoint root backfill')
        check(migrated['stateknot.runs'][0]['checkpoint_graph_namespace'] == '', 'generated Root namespace')
        changed_tables = {t for t in migrated if canonical(migrated[t]) != canonical(after[t])}
        check(changed_tables == {'stateknot.runs'}, 'unexpected replay writes')
        a = migrated['stateknot.runs'][0]
        z = after['stateknot.runs'][0]
        check({k for k in a if a[k] != z[k]} == lease_fields and a.keys() == z.keys(), 'lease changes are not exactly six explicit fields')
        check(a['fencing_epoch'] == 1 and z['fencing_epoch'] == 2 and a['lease_attempt_id'] != z['lease_attempt_id'], 'actual higher fence')
        for r in [a, z]:
            acquired = timestamp(r['lease_acquired_at'])
            check(timestamp(r['lease_expires_at']) - acquired == dt.timedelta(seconds=30) and r['lease_acquired_at'] == r['lease_renewed_at'], 'lease resource was extended')
        clock, expiry, expired = raw(prefix + 'natural-lease-expiry.log').decode().strip().split('|')
        check(expired == 't' and timestamp(clock) >= timestamp(expiry) and timestamp(expiry) == timestamp(a['lease_expires_at']), 'old lease did not expire naturally')
        check(not after['stateknot.run_quarantines'], 'reader quarantined original run')
        check(new_cols == after_cols == negative_cols and after == negative, 'negative check changed catalog columns or any row')
        neg = doc(prefix + 'old-writer-new-schema.negative.receipt.json')
        neg_raw = raw(prefix + 'old-writer-new-schema.negative.log')
        check(neg['exit_code'] == 101 and neg['summaries'] == [['FAILED', '0', '1', '0']] and not neg['product_native_pass'], 'negative refusal counted as Native pass')
        check(neg['log_sha256'] == sha(neg_raw) and b'Migration { source: VersionMissing(27) }' in neg_raw, 'actual historical schema rejection')
        check(re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', neg_raw.decode()) == [('FAILED', '0', '1', '0')], 'negative actual terminal summary')
        proof = next(r for r in bytea_proof if r['postgres_major'] == major)
        recomputed = []
        for c in sorted((c for c in old_cols if c['data_type'] == 'bytea'), key=lambda c: (c['table_schema'], c['table_name'], c['column_name'])):
            table = c['table_schema'] + '.' + c['table_name']
            column = c['column_name']
            post = after[table]
            if table == 'public._sqlx_migrations':
                post = [r for r in post if r['version'] <= 26]
            def byte_cells(rows):
                cells = []
                for r in rows:
                    v = r[column]
                    if v is None:
                        cells.append(None)
                    else:
                        check(v.startswith('\\x'), 'bytea encoding')
                        b = bytes.fromhex(v[2:])
                        cells.append({'bytes': len(b), 'sha256': sha(b)})
                return sorted(cells, key=lambda v: json.dumps(v, sort_keys=True))
            cells = byte_cells(old[table])
            check(cells == byte_cells(post), 'original bytea changed ' + table + '.' + column)
            recomputed.append({'table': table, 'column': column, 'values': cells, 'unchanged': True})
        check(sorted(proof['columns'], key=lambda r: (r['table'], r['column'])) == recomputed, 'bytea proof data mismatch')
        check(sum(v is not None for r in recomputed for v in r['values']) == proof['nonnull_cell_count'] == 103, 'bytea count')
        migration_comparison = doc(prefix + 'migration-data-comparison.json')
        replay_comparison = doc(prefix + 'replay-data-comparison.json')
        check(migration_comparison['all_original_rows_and_columns_unchanged'] and migration_comparison['old_ledger_rows_all_fields_byte_exact'], 'migration comparison receipt')
        for row in migration_comparison['table_comparisons']:
            check(row['old_rows'] == len(old[row['table']]) and row['all_original_columns_byte_exact'], 'comparison row counts')
        check(replay_comparison['only_explicit_expected_lease_fields_changed'], 'explicit replay receipt')
        expected_changes = [{'column': k, 'before': a[k], 'after': z[k]} for k in sorted(lease_fields)]
        check([r for r in replay_comparison['all_tables'] if not r['all_rows_equal']][0]['changes'] == expected_changes, 'six-column exact values')

    for name in ['report.md', 'report.zh-CN.md']:
        for link in re.findall(r'\[[^\]]*\]\(([^)]+)\)', (P / name).read_text()):
            if not re.match(r'[a-zA-Z][a-zA-Z0-9+.-]*:', link):
                check((P / link.split('#')[0]).is_file(), 'broken Markdown link ' + link)
    if args.local_inputs:
        retained = index['binary_files_deliberately_external']
        check(sha(Path(retained['released']).read_bytes()) == profile['released_writer']['binary_sha256'], 'retained released binary bytes')
        check(sha(Path(retained['reader']).read_bytes()) == profile['reader_binary_sha256'], 'retained reader binary bytes')
        old_root = Path('/private/tmp/stateknot-r1-released-alpha1-20261015-source')
        for r in old_before:
            check(sha((old_root / r['path']).read_bytes()) == r['sha256'], 'retained old source changed')
        reader_root = P.parents[2] / 'released-alpha1-current-reader-source'
        check(reader_root.is_dir(), 'retained reader source path')
        for r in source_before:
            check(sha((reader_root / r['path']).read_bytes()) == r['sha256'], 'retained reader source changed')
    print(json.dumps({'verified': True, 'manifest_files': len(manifest['files']), 'original_artifacts': len(index['files']), 'source_files': 920, 'production_inputs': 160, 'postgres_majors': [16, 17], 'one_released_writer': '0.1.0-alpha.1', 'one_existing_business_scenario': True, 'schema': [26, 36], 'original_rows_each': 39, 'original_nonnull_bytea_cells_each': 103, 'root_replay_each': {'checkpoints': 2, 'barriers': 1, 'results': 1}, 'negative_exit101_not_native_pass': True, 'main_certified': False, 'local_inputs_checked': args.local_inputs}, indent=2))

if __name__ == '__main__':
    main()
