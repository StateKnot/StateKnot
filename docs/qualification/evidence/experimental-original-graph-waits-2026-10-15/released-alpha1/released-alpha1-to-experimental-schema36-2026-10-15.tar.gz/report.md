# Experimental release alpha.1 → schema36 qualification — 2026-10-15

The **one existing noninitial Root scenario** written by the actual published `0.1.0-alpha.1` Store test binary migrated and replayed successfully on PostgreSQL **16.15 and 17.11**. This qualifies only the frozen **schema36 experimental reader**, parent tree `bca1889badb0d3318fcca66490d153a2fec08ab28ab205a474db44f9b6510d45` (919 original files plus one test fixture = 920). It was **not adopted into main** `c7d8768356b30207cd637d81e406056b745d35ac` when this task ran. This is not a current-main compatibility result, a full compatibility matrix, capacity/performance qualification, complete Native acceptance, or completion of R1. No second actually released version exists in the recorded registry/release inventory, so this does not claim N−2 coverage.

[Machine profile](report.json), [immutable source proof](source-proof.json), [160 production inputs](production-inputs.json), [all original bytea cells](original-bytea-proof.json), and [artifact index with original-byte and compressed-byte hashes](artifact-index.json) support this limited result. `manifest.json` binds the complete bundle; `python3 verify.py` checks it without a database or compilation.

## Actual released writer and frozen experimental reader

The writer was built with Rust 1.88.0, strict warnings, its **original published Cargo.lock** (`11f1cae4978fce7be53baabe8ac985856bf361e5ca139aa7842716387555729b`) and actual registry `stateknot-core = 0.1.0-alpha.1`. All 58 original published Store files, including library/tests/lock, are byte unchanged. The only five extra source inputs are original JSON fixtures copied from the same published Core archive into the sibling paths required by the published test's `include_str!`; they do not replace the registry Core dependency. All 63 files stayed unchanged before/after build and execution. The release tag resolves to `9f697735b8a0164197bd06697d07d8c63d169b68`, with schema26.

The writer binary SHA-256 is `3fd728a83cd38665bfbfcc8c1f635cc0e2f48d961277d07c10d6af6af29f2829`. The experimental reader binary SHA-256 is `e9f8322a9c1be650a384f274ed8ba0f799f619e5ceec890c3fa9c02dabf16c56`. Binary bytes remain outside build caches in local evidence and are excluded from this compact bundle. The bundle contains both checksum-verified original `.crate` archives, registry index/release responses, source manifests, an exact 920-file reader source archive, strict build receipts, and original diagnostic logs. The reader changed no Core/Store production source, migrations, lockfile or configuration: it only appended a test-module declaration and added the isolated test fixture.

[Release inventory](evidence/released-inventory/receipt.json), [published writer build](evidence/released-build-v2/receipt.json), [five original fixture bindings](evidence/released-build-v2/external-fixtures.json), [reader build](evidence/upgrade/reader-build-v2/receipt.json), [reader source archive](evidence/reader-source.tar.gz).

## Exact business execution on each PostgreSQL major

Each server uses a newly created, task-owned `stateknot_r1_alpha1_upgrade_oct15v2` database. The original released binary ran exactly `noninitial_replay_recomputes_committed_state_with_bounded_memory`, with the published mandatory database flag. It returned exit 0, **1 passed / 0 failed / 0 ignored** per major and left one actual `noninitial-replay-valid-*` tenant/run at schema26. Its original bounded-memory rejection assertion also executed. These are original test assertions, not reconstructed historical data from a current writer.

The new test first called public `PostgresStore::migrate_database`, then public `connect` to validate the complete exact schema36 catalog and all 36 migration entries. A separate exact replay test loaded the original run, waited for the already-expired original lease according to the database clock, claimed a genuinely higher fence **1 → 2**, loaded the actual pinned graph and used its reducer reference with the unchanged parent test reducer/schema validator. It called public `validate_noninitial_replay`, then public `validate_graph_replay(None, …)` over the complete legacy Root Continue history. Both migration and replay tests returned exit 0, **1/0/0** per major.

| Check | PG16.15 | PG17.11 |
| --- | --- | --- |
| Actual released writer | exit 0, 1/0/0 | exit 0, 1/0/0 |
| Public migrate + exact catalog | exit 0, 1/0/0 | exit 0, 1/0/0 |
| Noninitial + complete Root reader | exit 0, 1/0/0 | exit 0, 1/0/0 |
| Root checkpoints / barriers / results | 2 / 1 / 1 | 2 / 1 / 1 |
| Frames / returns / waits in this original history | 0 / 0 / 0 | 0 / 0 / 0 |
| Final original journal recheck / no quarantine | passed | passed |

The fixture retained the published **30-second lease, 5/20-second transaction limits, 1..48 connection pool and default stack**. Neither lease duration nor transaction/stack/capacity limits were increased. No old registry, authority or durable fact was rewritten to produce a pass.

[PG16 exact upgrade receipt](evidence/upgrade/pg16-writer-v2/upgrade-receipt.json), [PG17 exact upgrade receipt](evidence/upgrade/pg17-writer-v2/upgrade-receipt.json), [PG16 Root log](evidence/upgrade/pg16-writer-v2/replay_noninitial_and_complete_root.native.log.gz), [PG17 Root log](evidence/upgrade/pg17-writer-v2/replay_noninitial_and_complete_root.native.log.gz).

## Complete original-data comparison and explicit allowed changes

Before migration, each database had **45 tables and 39 rows: 26 migration ledger rows plus 13 business rows** (one graph definition, one node-attempt completion, one node attempt, one result consumption, one pending result, one run-attempt claim, two checkpoints, four events and one run). Every original row and every original column value is compared through the migration, including all **103 non-null bytea cells** per major; that count includes canonical bytes, digests and 26 original ledger checksums. All are unchanged by migration. Original ledger rows retain every column, including installation/execution fields; only ten new successful versions 27..36 are added.

Migration creates ten empty tables: `graph_frame_barriers`, `graph_frame_caller_bindings`, `graph_frame_closed_callers`, `graph_frame_closures`, `graph_frame_entries`, `graph_frame_heads`, `graph_frame_returns`, `graph_frame_stacks`, `graph_wait_conditions`, and `root_graph_barriers`. It adds eight columns across four old tables: `run_checkpoints.graph_namespace=''` and four nullable frame fields/checksum (all null for both original checkpoints), generated `runs.checkpoint_graph_namespace=''`, generated `agent_admissions.checkpoint_graph_namespace` (no old rows), and `child_run_ownership.parent_graph_namespace` (no old rows). These additions are recorded explicitly, not silently filtered.

After migration, the higher-fence claim and replay change **only six columns in the single original runs row**: `fencing_epoch` 1→2; `lease_attempt_id`; `lease_acquired_at`; `lease_renewed_at`; `lease_expires_at` (exactly new acquisition +30 seconds); and `updated_at`. All before/after values are retained. All other columns in all 55 tables remain equal, including every original canonical byte/digest, lifecycle, event, checkpoint, node/result and original ledger field. Thus the report does not describe the ownership columns themselves as immutable.

[PG16 migration comparison](evidence/upgrade/pg16-writer-v2/migration-data-comparison.json), [PG17 migration comparison](evidence/upgrade/pg17-writer-v2/migration-data-comparison.json), [PG16 lease-only changes](evidence/upgrade/pg16-writer-v2/replay-data-comparison.json), [PG17 lease-only changes](evidence/upgrade/pg17-writer-v2/replay-data-comparison.json). Full original/after-migration/after-replay/after-negative per-table snapshots, exact column metadata and raw schema dumps are included as deterministic gzip files in the artifact index.

## Historical writer refusal is a separate negative check

After the successful reader scenario, the same original released test binary was intentionally invoked against schema36. Both runs returned **exit 101, 0 passed / 1 failed / 0 ignored**, specifically `Migration { source: VersionMissing(27) }`, before business writes. Complete row and column snapshots stayed unchanged. This expected newer-schema refusal is a **negative compatibility check, never a product Native pass**.

[PG16 negative receipt](evidence/upgrade/pg16-writer-v2/old-writer-new-schema.negative.receipt.json), [PG17 negative receipt](evidence/upgrade/pg17-writer-v2/old-writer-new-schema.negative.receipt.json), [PG16 raw refusal](evidence/upgrade/pg16-writer-v2/old-writer-new-schema.negative.log.gz), [PG17 raw refusal](evidence/upgrade/pg17-writer-v2/old-writer-new-schema.negative.log.gz).

## Preserved unsuccessful setup attempts

The first published-package build returned 101 because the published test's sibling Core JSON paths were absent. It preserved all 58 original files and the original lock. Supplying exactly five original published fixtures fixed the environment without editing library/tests/lock. The first external acquisition runner observed successful writer harness summaries but exited 1 because it incorrectly treated whole-JSON row ordering as migration-version ordering. Its original stderr was seen in the tool terminal but was not saved as raw bytes; the bundle labels a separately captured offline reproduction of that exact incorrect assertion against the frozen original v1 snapshots. Fresh v2 databases and an exit-first receipt avoid granting qualification from that incomplete acquisition. The first reader fixture build returned 101 with E0599 because the fixture called the nonexistent `GraphReference::reducer`; the corrected fixture compares the complete pinned GraphReference and obtains the reducer from the loaded CompiledGraph. Production sources did not change. All failed build receipts/diagnostics, original v1 snapshots and the erroneous fixture are retained; no failed product validation was weakened.

[Missing-fixture build](evidence/released-build-v1/receipt.json), [runner diagnostic and precise provenance](evidence/upgrade/runner-v1-diagnostic/receipt.json), [first reader build](evidence/upgrade/reader-build-v1/receipt.json), [first reader fixture](evidence/upgrade/reader-build-v1/released_alpha1_upgrade.rs).

## Reproduction and transfer boundary

Run `python3 verify.py` inside this bundle for hashes, deterministic gzip, original release archives/fixtures, exact reader inputs, actual Native summaries/markers, complete row/bytea/ledger comparisons, exact lease-only changes and negative-check evidence. `python3 verify.py --local-inputs` additionally checks retained external binary bytes and live frozen source files; it does not run tests, mutate databases or certify main. The compact archive omits binaries and rebuildable target caches.

Only a later explicitly reviewed, byte-for-byte compiled-input equivalence proof can transfer this **specific case** to a final schema36 candidate. A new source, a combined candidate, schema36 adoption, additional historical scenarios, release versions, resources or platform claims require their own applicable proof or execution. This report makes none of those broader claims.

The task-only reader compilation cache was removed after real-path/Cargo cache tag/Git/open-file checks. Logs, binaries and source remain outside that cache. The filesystem reported an observed +517480 KiB available change during concurrent team activity; this is not a sum of `du` sizes. [Cleanup receipt](evidence/upgrade/cache-clean-receipt.json).
