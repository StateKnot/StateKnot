// Copyright 2026 StateKnot contributors
// SPDX-License-Identifier: Apache-2.0

//! Isolated release-package writer to exact current reader qualification.

use super::*;

#[tokio::test]
async fn migrate_exact_schema36() {
    let url = std::env::var(DATABASE_URL_ENV).expect("mandatory isolated database URL");
    let options = test_options(Duration::from_secs(30));
    PostgresStore::migrate_database(&url, options.clone())
        .await
        .expect("released alpha.1 schema26 must migrate through public API");
    let store = PostgresStore::connect(&url, options)
        .await
        .expect("complete exact current catalog and migration ledger must validate");
    store.close().await;
    println!("RELEASED_ALPHA1_MIGRATION {{\"exact_schema36_catalog\":true}}");
}

#[tokio::test]
async fn replay_noninitial_and_complete_root() {
    let url = std::env::var(DATABASE_URL_ENV).expect("mandatory isolated database URL");
    let store = PostgresStore::connect(&url, test_options(Duration::from_secs(30)))
        .await
        .expect("migrated catalog must remain exact");
    let tenant_id = TenantId::new(std::env::var("STATEKNOT_RELEASED_TENANT").unwrap()).unwrap();
    let run_id: RunId = std::env::var("STATEKNOT_RELEASED_RUN_ID")
        .unwrap()
        .parse()
        .unwrap();
    let old = store.load_run(&tenant_id, run_id).await.unwrap();
    let old_epoch = old
        .lease()
        .expect("released writer retained its original lease")
        .fence()
        .epoch();
    let current = store
        .claim_lease(&tenant_id, run_id, AttemptId::generate())
        .await
        .expect("original lease must expire naturally before higher-fence claim");
    let fence = current.lease().fence().clone();
    assert!(fence.epoch() > old_epoch);
    let run = store.load_run(&tenant_id, run_id).await.unwrap();
    assert_eq!(run.journal_head(), old.journal_head());
    let context = CorruptionQuarantineContext::new(
        tenant_id.clone(),
        run_id,
        QuarantineId::generate(),
        JournalExpectation::exact(run.journal_head().unwrap().clone()),
        Digest::sha256(b"actual released alpha.1 schema26 to exact schema36 reader evidence"),
    )
    .unwrap();
    let recovery = store
        .begin_claimed_run_recovery(fence, context)
        .await
        .unwrap();
    let definition = recovery.load_pinned_graph().await.unwrap();
    let reducer = IntegrationGraphReducer {
        reference: definition.graph().reducer().clone(),
    };
    let report = recovery
        .validate_noninitial_replay(&AcceptGraphSchemas, &reducer, GraphReplayLimits::default())
        .await
        .expect("actual released noninitial checkpoints must replay");
    assert_eq!(report.checkpoints_validated(), 2);
    assert_eq!(report.barriers_replayed(), 1);
    assert_eq!(report.results_replayed(), 1);
    assert!(report.maximum_barrier_result_bytes() > 1);
    println!(
        "RELEASED_ALPHA1_NONINITIAL {{\"checkpoints\":2,\"barriers\":1,\"results\":1,\"higher_fence\":true,\"pinned_reducer\":true}}"
    );
    let whole = recovery
        .validate_graph_replay(
            None,
            &AcceptGraphSchemas,
            |graph| {
                (graph.reducer() == reducer.reference()).then_some(&reducer as &dyn GraphReducer)
            },
            GraphReplayLimits::default(),
        )
        .await
        .expect("actual released legacy Continue must support complete Root replay");
    assert_eq!(whole.root_report(), report);
    assert_eq!(whole.root_checkpoints_validated(), 2);
    assert_eq!(whole.barriers_replayed(), 1);
    assert_eq!(whole.results_replayed(), 1);
    assert_eq!(whole.frames_validated(), 0);
    assert_eq!(whole.returns_validated(), 0);
    assert_eq!(whole.waits_validated(), 0);
    assert_eq!(whole.journal_head(), run.journal_head().unwrap());
    recovery.revalidate().await.unwrap();
    assert!(matches!(
        store.load_run_quarantine(&tenant_id, run_id).await,
        Err(StoreError::RunQuarantineNotFound)
    ));
    store.close().await;
    println!(
        "RELEASED_ALPHA1_COMPLETE_ROOT {{\"checkpoints\":2,\"barriers\":1,\"results\":1,\"frames\":0,\"returns\":0,\"waits\":0,\"journal_unchanged\":true,\"revalidated\":true,\"not_quarantined\":true}}"
    );
}
