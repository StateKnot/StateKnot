from pathlib import Path
import subprocess,json,hashlib,os,re,time,sys
ROOT=Path('/Users/jiawy/Documents/RustAgentFramework');BASE=ROOT/'.local-verification/2026-10-15';OUT=BASE/'evidence/released-alpha1-upgrade';DB='stateknot_r1_alpha1_upgrade_oct15v1';OLD=BASE/'evidence/released-alpha1-build-v2/postgres';OLD_SHA='3fd728a83cd38665bfbfcc8c1f635cc0e2f48d961277d07c10d6af6af29f2829'
def save(p,d):p.write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
def psql(major,sql,db=DB):
 r=subprocess.run(['docker','exec','-i','stateknot-r1-oct15-pg'+major,'psql','-X','-v','ON_ERROR_STOP=1','-U','postgres','-d',db,'-At','-f','-'],input=sql,text=True,capture_output=True);assert r.returncode==0,r.stderr;return r.stdout

def snapshot(major,label):
 out=OUT/('pg'+major)/label;out.mkdir(exist_ok=False)
 tables=json.loads(psql(major,"SELECT json_agg(json_build_array(schemaname,tablename) ORDER BY schemaname,tablename) FROM pg_tables WHERE schemaname IN ('stateknot','public');"));data={}
 for schema,table in tables:
  assert re.fullmatch('[a-z_][a-z_0-9]*',schema)and re.fullmatch('[a-z_][a-z_0-9]*',table)
  sql=f'SELECT COALESCE(jsonb_agg(j ORDER BY j::text),\'[]\'::jsonb) FROM (SELECT to_jsonb(t) j FROM "{schema}"."{table}" t) s;'
  raw=psql(major,sql);(out/(schema+'.'+table+'.json')).write_text(raw);data[schema+'.'+table]=json.loads(raw)
 columns=psql(major,"SELECT jsonb_agg(to_jsonb(c) ORDER BY table_schema,table_name,ordinal_position) FROM information_schema.columns c WHERE table_schema IN ('stateknot','public');");(out/'columns.json').write_text(columns)
 r=subprocess.run(['docker','exec','stateknot-r1-oct15-pg'+major,'pg_dump','-U','postgres','-d',DB,'--schema-only','--no-owner','--no-privileges'],capture_output=True);assert r.returncode==0,r.stderr;(out/'schema.sql').write_bytes(r.stdout)
 ledger=data['public._sqlx_migrations'];save(out/'snapshot.json',{'database':DB,'tables':{k:{'rows':len(v),'file':k+'.json','sha256':hashlib.sha256((out/(k+'.json')).read_bytes()).hexdigest()}for k,v in data.items()},'ledger_versions':[r['version']for r in ledger],'all_migrations_success':all(r['success']for r in ledger),'columns_sha256':hashlib.sha256(columns.encode()).hexdigest(),'schema_sha256':hashlib.sha256(r.stdout).hexdigest()});return data

def old(major):
 assert major in ['16','17'];out=OUT/('pg'+major);out.mkdir(exist_ok=False);assert hashlib.sha256(OLD.read_bytes()).hexdigest()==OLD_SHA
 (out/'before.df').write_bytes(subprocess.check_output(['df','-k',str(ROOT)]));info=json.loads(subprocess.check_output(['docker','inspect','stateknot-r1-oct15-pg'+major]))[0];assert info['Config']['Labels'].get('stateknot.task')=='r1-oct15'and info['State']['Running'];save(out/'container-identity.json',{'name':info['Name'],'id':info['Id'],'image':info['Image'],'labels':info['Config']['Labels'],'ports':info['NetworkSettings']['Ports']})
 version=psql(major,"SELECT current_setting('server_version_num')::int,current_setting('server_version');",'postgres').strip();assert int(version.split('|')[0])//10000==int(major);assert psql(major,f"SELECT count(*) FROM pg_database WHERE datname='{DB}';",'postgres').strip()=='0','must be a fresh database'
 (out/'create-database.log').write_text(psql(major,'CREATE DATABASE '+DB+' TEMPLATE template0;','postgres'));assert psql(major,"SELECT count(*) FROM pg_tables WHERE schemaname IN ('stateknot','public');").strip()=='0'
 env=os.environ.copy()
 for k in list(env):
  if k.startswith('STATEKNOT_')or k in ['DATABASE_URL','RUST_MIN_STACK']:env.pop(k,None)
 env['STATEKNOT_TEST_DATABASE_URL']='postgres://postgres:stateknot_test_password@127.0.0.1:554'+major+'/'+DB;env['STATEKNOT_REQUIRE_POSTGRES_TESTS']='1';command=[str(OLD),'noninitial_replay_recomputes_committed_state_with_bounded_memory','--exact','--nocapture','--test-threads=1'];start=time.time()
 with(out/'released-writer.native.log').open('w')as log:
  r=subprocess.run(command,env=env,cwd='/private/tmp/stateknot-r1-released-alpha1-20261015-source/stateknot-store-postgres-0.1.0-alpha.1',stdout=log,stderr=subprocess.STDOUT)
 body=(out/'released-writer.native.log').read_text();summaries=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',body);data=snapshot(major,'schema26-before-reader');ledger=data['public._sqlx_migrations'];assert [r['version']for r in ledger]==list(range(1,27))and all(r['success']for r in ledger);runs=data['stateknot.runs'];assert len(runs)==1;save(out/'released-writer.receipt.json',{'exit_code':r.returncode,'summaries':summaries,'command':command,'binary_sha256':OLD_SHA,'server':version,'database':DB,'seconds':time.time()-start,'schema_version':26,'ledger_count':26,'actual_runs':runs,'source_tenant':'noninitial-replay-valid','mandatory_database':True,'original_resources':{'lease_seconds':30,'transaction_lock_timeout_seconds':5,'transaction_statement_timeout_seconds':20,'pool_min':1,'pool_max':48,'default_stack':True},'log_sha256':hashlib.sha256(body.encode()).hexdigest()});assert r.returncode==0 and summaries==[('ok','1','0','0')];print('pg'+major+' released writer 1/0/0; schema26; 26 checksummed ledger entries; original rows frozen',flush=True)
if __name__=='__main__':old(sys.argv[1])
