from pathlib import Path
import json,hashlib,subprocess,os,time,shutil,sys
root=Path('/Users/jiawy/Documents/RustAgentFramework');b=root/'.local-verification/2026-10-15';out=b/'evidence/released-alpha1-upgrade/reader-build-v1';out.mkdir(exist_ok=False);src=b/'released-alpha1-current-reader-source';target=root/'target/r1-oct15-released-upgrade-reader';assert not target.exists();(out/'before.df').write_bytes(subprocess.check_output(['df','-k',str(root)]));m=json.loads((out.parent/'parent-source-manifest.json').read_text());allowed='crates/stateknot-store-postgres/tests/postgres.rs';addition=b'\n#[path = "postgres/released_alpha1_upgrade.rs"]\nmod released_alpha1_upgrade;\n'
for r in m['files']:
 p=src/r['path'];raw=p.read_bytes();original=(Path(m['source_root'])/r['path']).read_bytes();assert hashlib.sha256(original).hexdigest()==r['sha256'];assert raw==original+addition if r['path']==allowed else raw==original,r['path']
rows=[{'path':str(p.relative_to(src)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in sorted(src.rglob('*'))if p.is_file()];assert len(rows)==920;(out/'source-before.json').write_text(json.dumps(rows,indent=2)+'\n');env=os.environ.copy()
for k in list(env):
 if k.startswith('STATEKNOT_')or k in ['DATABASE_URL','RUST_MIN_STACK']:env.pop(k,None)
env.update(CARGO_TARGET_DIR=str(target),CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUSTFLAGS='-D warnings',RUSTDOCFLAGS='-D warnings');cmd=['cargo','+1.88.0','test','--manifest-path',str(src/'Cargo.toml'),'-p','stateknot-store-postgres','--test','postgres','--all-features','--locked','--no-run','--message-format=json'];(out/'command.json').write_text(json.dumps({'command':cmd,'target':str(target),'strict_env':{k:env[k]for k in ['CARGO_INCREMENTAL','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG','RUSTFLAGS','RUSTDOCFLAGS']}},indent=2)+'\n');start=time.time()
with(out/'build.stdout.jsonl').open('w')as stdout,(out/'build.stderr.log').open('w')as stderr:r=subprocess.run(cmd,env=env,cwd=src,stdout=stdout,stderr=stderr)
rows2=[{'path':str(p.relative_to(src)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in sorted(src.rglob('*'))if p.is_file()];(out/'source-after.json').write_text(json.dumps(rows2,indent=2)+'\n');assert rows==rows2;arts=[]
for line in(out/'build.stdout.jsonl').read_text().splitlines():
 try:d=json.loads(line)
 except ValueError:continue
 if d.get('reason')=='compiler-artifact'and d.get('executable')and d.get('target',{}).get('name')=='postgres':
  p=out/'postgres';shutil.copy2(d['executable'],p);arts.append({'binary':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'fresh':d['fresh']})
receipt={'exit_code':r.returncode,'seconds':time.time()-start,'source_unchanged':rows==rows2,'parent_tree':m['source_tree_sha256'],'source_files':len(rows),'all_production_lock_configuration_original':True,'only_original_test_harness_change':allowed,'new_fixture':'crates/stateknot-store-postgres/tests/postgres/released_alpha1_upgrade.rs','target':str(target),'artifacts':arts};(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2));sys.exit(r.returncode)
