from fixture import *
import datetime

def load(label,major):
 p=OUT/('pg'+major+'-writer-v2')/label
 return {k:json.loads((p/(k+'.json')).read_text())for k in json.loads((p/'snapshot.json').read_text())['tables']}

def canonical(rows):return sorted(json.dumps(r,sort_keys=True,separators=(',',':'))for r in rows)
def compare_migration(major,old,new):
 details=[];success=True
 oldcols=json.loads((OUT/('pg'+major+'-writer-v2')/'schema26-before-reader/columns.json').read_text());newcols=json.loads((OUT/('pg'+major+'-writer-v2')/'schema36-before-claim/columns.json').read_text());oldnames={}
 for c in oldcols:oldnames.setdefault(c['table_schema']+'.'+c['table_name'],[]).append(c['column_name'])
 for table,rows in old.items():
  n=new[table]
  if table=='public._sqlx_migrations':n=[r for r in n if r['version']<=26]
  projected=[{k:r[k]for k in oldnames[table]}for r in n];equal=canonical(rows)==canonical(projected);success&=equal
  additions=[c for c in newcols if c['table_schema']+'.'+c['table_name']==table and c['column_name']not in oldnames[table]]
  details.append({'table':table,'old_rows':len(rows),'corresponding_migrated_rows':len(n),'all_original_columns_byte_exact':equal,'new_columns':[{**c,'observed_values':[r[c['column_name']]for r in new[table]]}for c in additions]})
 result={'all_original_rows_and_columns_unchanged':success,'old_ledger_rows_all_fields_byte_exact':next(r for r in details if r['table']=='public._sqlx_migrations')['all_original_columns_byte_exact'],'table_comparisons':details,'new_tables':[{'table':k,'rows':len(v),'raw_file':'schema36-before-claim/'+k+'.json'}for k,v in new.items()if k not in old],'new_ledger_versions':sorted(r['version']for r in new['public._sqlx_migrations']if r['version']>26)};save(OUT/('pg'+major+'-writer-v2')/'migration-data-comparison.json',result);assert success and result['new_ledger_versions']==list(range(27,37));return result

def compare_replay(major,before,after):
 details=[]
 for table,rows in before.items():
  n=after[table];same=canonical(rows)==canonical(n);changes=[]
  if not same:
   assert len(rows)==len(n)
   for a,z in zip(sorted(rows,key=lambda x:json.dumps(x,sort_keys=True)),sorted(n,key=lambda x:json.dumps(x,sort_keys=True))):
    changes.extend({'column':k,'before':a.get(k),'after':z.get(k)}for k in sorted(set(a)|set(z))if a.get(k)!=z.get(k))
  details.append({'table':table,'rows_before':len(rows),'rows_after':len(n),'all_rows_equal':same,'changes':changes})
 changed=[d for d in details if not d['all_rows_equal']];expected={'fencing_epoch','lease_attempt_id','lease_acquired_at','lease_renewed_at','lease_expires_at','updated_at'}
 success=len(changed)==1 and changed[0]['table']=='stateknot.runs'and {c['column']for c in changed[0]['changes']}==expected
 if success:
  r=before['stateknot.runs'][0];z=after['stateknot.runs'][0];success=z['fencing_epoch']==r['fencing_epoch']+1 and all(z[k]==r[k]for k in r if k not in expected)
 result={'only_explicit_expected_lease_fields_changed':success,'all_tables':details,'expected_columns':sorted(expected),'unexpected_new_tables':sorted(set(after)-set(before))};save(OUT/('pg'+major+'-writer-v2')/'replay-data-comparison.json',result);assert success,result

def execute(major):
 out=OUT/('pg'+major+'-writer-v2');build=json.loads((OUT/'reader-build-v2/receipt.json').read_text());assert build['exit_code']==0 and len(build['artifacts'])==1;binary=Path(build['artifacts'][0]['binary']);assert hashlib.sha256(binary.read_bytes()).hexdigest()==build['artifacts'][0]['sha256'];(out/'reader-before.df').write_bytes(subprocess.check_output(['df','-k',str(ROOT)]));original=load('schema26-before-reader',major);run=original['stateknot.runs'][0];assert run['tenant_id'].startswith('noninitial-replay-valid-');assert len(original['stateknot.run_checkpoints'])==2
 env=os.environ.copy()
 for k in list(env):
  if k.startswith('STATEKNOT_')or k in ['DATABASE_URL','RUST_MIN_STACK']:env.pop(k,None)
 env.update(STATEKNOT_TEST_DATABASE_URL='postgres://postgres:stateknot_test_password@127.0.0.1:554'+major+'/'+DB,STATEKNOT_REQUIRE_POSTGRES_TESTS='1',STATEKNOT_RELEASED_TENANT=run['tenant_id'],STATEKNOT_RELEASED_RUN_ID=run['run_id']);receipts=[]
 def native(name,marker):
  cmd=[str(binary),'released_alpha1_upgrade::'+name,'--exact','--nocapture','--test-threads=1'];start=time.time()
  with(out/(name+'.native.log')).open('w')as log:r=subprocess.run(cmd,env=env,cwd=BASE/'released-alpha1-current-reader-source',stdout=log,stderr=subprocess.STDOUT)
  raw=(out/(name+'.native.log')).read_bytes();body=raw.decode();summaries=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',body);receipt={'exact_test':'released_alpha1_upgrade::'+name,'command':cmd,'binary_sha256':build['artifacts'][0]['sha256'],'exit_code':r.returncode,'seconds':time.time()-start,'summaries':summaries,'expected_marker':marker,'marker_count':body.count(marker+' '),'log_sha256':hashlib.sha256(raw).hexdigest(),'default_stack':True,'database':DB};save(out/(name+'.receipt.json'),receipt);receipts.append(receipt);return r.returncode==0 and summaries==[('ok','1','0','0')]and body.count(marker+' ')==1
 migrated=native('migrate_exact_schema36','RELEASED_ALPHA1_MIGRATION');data=snapshot(major,'schema36-before-claim');save(out/'migration-stage.json',{'native_passed':migrated,'snapshot_complete':True});assert migrated
 ledger=data['public._sqlx_migrations'];assert sorted(r['version']for r in ledger)==list(range(1,37))and all(r['success']for r in ledger);compare_migration(major,original,data)
 observed=psql(major,"SELECT clock_timestamp(),lease_expires_at,clock_timestamp()>=lease_expires_at FROM stateknot.runs;");(out/'natural-lease-expiry.log').write_text(observed);assert observed.strip().endswith('|t'),'must let original lease expire naturally before claim'
 replayed=native('replay_noninitial_and_complete_root','RELEASED_ALPHA1_COMPLETE_ROOT');after=snapshot(major,'schema36-after-replay');compare_replay(major,data,after);assert replayed
 receipt={'postgres_major':major,'released_version':'0.1.0-alpha.1','schema_before':26,'schema_after':36,'single_original_business_scenario':'noninitial_replay_recomputes_committed_state_with_bounded_memory','original_writer_exact_one_passed':True,'public_migration_and_complete_catalog_validated':True,'current_noninitial_checkpoints':2,'current_noninitial_barriers':1,'current_noninitial_results':1,'complete_root_replay':True,'original_lease_naturally_expired':True,'higher_fence':True,'all_original_canonical_bytes_unchanged':True,'only_replay_data_changes':'explicit six lease ownership/update columns, no journal/checkpoint/node/result changes','resource_settings':'original 30s lease; 5/20s transaction; 1..48 pool; default stack','native_receipts':receipts,'qualification_scope':'One actually released alpha.1 writer; one existing noninitial business scenario; this PostgreSQL major only. No N-2 release exists; not a full compatibility matrix, capacity/performance, complete Native or R1 qualification.'};save(out/'upgrade-receipt.json',receipt);print('pg'+major+' schema26→36 and complete original Root replay passed',flush=True)
if __name__=='__main__':execute(sys.argv[1])
