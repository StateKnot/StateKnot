import json,sys
from pathlib import Path
p=Path(sys.argv[1]);ledger=json.loads(p.read_text());assert [r['version']for r in ledger]==list(range(1,27))and all(r['success']for r in ledger)
