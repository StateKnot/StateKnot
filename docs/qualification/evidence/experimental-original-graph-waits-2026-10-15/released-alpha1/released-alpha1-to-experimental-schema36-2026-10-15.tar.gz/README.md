# Exact experimental released-writer upgrade evidence

Read the [English qualification](report.md), [中文验收](report.zh-CN.md), or [machine profile](report.json).

```sh
python3 -B verify.py
```

This read-only command checks all files, decompressed raw hashes, original registry archives, 920 frozen source inputs, exact test summaries/markers, every original row/column and bytea value, explicit migration additions, lease-only changes and the separate expected refusal. It needs no compilation, network, Docker or PostgreSQL. The fixed program used Rust 1.88.0; the verifier uses only the Python 3.9+ standard library.

`python3 -B verify.py --local-inputs` additionally checks the retained external binaries and frozen source paths on the originating host. Binary bytes remain outside build caches and are omitted from this compact bundle.

The reader is the frozen 919-file schema36 **experimental candidate plus one test fixture**, not adopted main. Qualification covers only the one existing noninitial Root scenario from the one actual alpha.1 release on PG16.15/17.11. It grants no automatic transfer to another source, complete compatibility matrix, performance/capacity, full Native or R1 qualification.

Every gzip entry has zero mtime and no original-filename header. [Artifact index](artifact-index.json) binds both original and actual stored bytes; original receipt hashes refer to the decompressed bytes. [Manifest](manifest.json) binds all bundle files. Missing-fixture build failure, runner ordering failure with explicitly labelled offline reproduction, and reader-fixture compile failure remain preserved. An expected old-writer exit101 is never a Native pass.
