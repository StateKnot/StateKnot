# 实验候选：真实发布 alpha.1 → schema36 验收 — 2026-10-15

真实已发布 `0.1.0-alpha.1` Store 测试二进制写入的**一个既有非初始 Root 业务场景**，已在 PostgreSQL **16.15、17.11** 完成迁移和重放。资格仅属于冻结的 **schema36 实验 reader**：父源码树 `bca1889badb0d3318fcca66490d153a2fec08ab28ab205a474db44f9b6510d45`，919 个原文件加一个测试 fixture，共 920 个文件。本任务执行时，该候选**尚未采用到 main** `c7d8768356b30207cd637d81e406056b745d35ac`。这不是当前 main 的兼容通过，也不是完整兼容矩阵、容量/性能、全量 Native 或 R1 完成证明。已记录的 registry/release 清单只有一个实际发布版本，没有第二个 release，因此不声称 N−2 覆盖。

[机器回执](report.json)、[不可变源码证明](source-proof.json)、[160 个生产输入](production-inputs.json)、[全部原 bytea 单元](original-bytea-proof.json)、[同时绑定原字节与压缩字节哈希的索引](artifact-index.json)支持这一限定结果。`manifest.json` 绑定完整证据包；`python3 verify.py` 可离线检查，无需数据库或编译。

## 真实发布 writer 与冻结实验 reader

旧 writer 使用 Rust 1.88.0、严格 warnings、**发布包原 Cargo.lock**（`11f1cae4978fce7be53baabe8ac985856bf361e5ca139aa7842716387555729b`），依赖真实 registry 的 `stateknot-core = 0.1.0-alpha.1`。发布 Store 包的全部 58 个原文件，包括 library/tests/lock，逐字不变。仅额外补充同一个真实已发布 Core archive 内的 5 个原 JSON 到发布测试 `include_str!` 所要求的 sibling 路径，不替换 registry Core 依赖。63 个输入在构建和执行前后均不变。原发布 tag 指向 `9f697735b8a0164197bd06697d07d8c63d169b68`，实际 schema26。

旧 writer 二进制 SHA-256 为 `3fd728a83cd38665bfbfcc8c1f635cc0e2f48d961277d07c10d6af6af29f2829`；实验 reader 为 `e9f8322a9c1be650a384f274ed8ba0f799f619e5ceec890c3fa9c02dabf16c56`。二进制原件留存在编译缓存外，不放入紧凑发布包。证据包包含两个已核 checksum 的原 `.crate`、registry index/release 响应、源码清单、920 文件精确 reader 源码归档、严格构建回执与原诊断日志。reader 未修改 Core/Store 生产源码、迁移、锁或配置；仅追加测试模块声明并新增隔离 fixture。

[发布清单](evidence/released-inventory/receipt.json)、[原包构建](evidence/released-build-v2/receipt.json)、[5 个原 fixture 绑定](evidence/released-build-v2/external-fixtures.json)、[reader 构建](evidence/upgrade/reader-build-v2/receipt.json)、[reader 源码归档](evidence/reader-source.tar.gz)。

## 双 PostgreSQL 上的精确业务执行

每个服务器使用新建且归本任务所有的 `stateknot_r1_alpha1_upgrade_oct15v2` 独立数据库。原发布二进制在原强制数据库开关下精确执行 `noninitial_replay_recomputes_committed_state_with_bounded_memory`：各 exit 0、**1 通过 / 0 失败 / 0 ignored**，真实写入一个 `noninitial-replay-valid-*` tenant/run 和 schema26。原 bounded-memory 资源拒绝断言也实际执行。这是旧程序的原断言，不是由当前 writer 重建的历史数据。

新 fixture 先调用公开 `PostgresStore::migrate_database`，再由公开 `connect` 验证完整精确 schema36 catalog 与 36 个迁移条目。独立 exact 重放测试加载旧 run，由数据库时钟确认原租约自然到期后，真实领取更高 fence **1→2**；使用 `load_pinned_graph` 取得的真实 reducer reference，以及未改的父测试 reducer/schema validator。测试调用公开 `validate_noninitial_replay`，再调用 `validate_graph_replay(None, …)` 重放完整 legacy Root Continue 历史。迁移和重放各在每个 major 返回 exit 0、**1/0/0**。

| 检查 | PG16.15 | PG17.11 |
| --- | --- | --- |
| 真实旧版 writer | exit 0，1/0/0 | exit 0，1/0/0 |
| 公开迁移与精确 catalog | exit 0，1/0/0 | exit 0，1/0/0 |
| 非初始与完整 Root reader | exit 0，1/0/0 | exit 0，1/0/0 |
| Root checkpoint / barrier / result | 2 / 1 / 1 | 2 / 1 / 1 |
| 原历史中的 frame / return / wait | 0 / 0 / 0 | 0 / 0 / 0 |
| 原 journal 最终重验 / 无 quarantine | 通过 | 通过 |

沿用发布测试原 **30 秒租约、5/20 秒事务限制、1..48 pool 和默认 stack**。未增加租约、事务、stack 或容量限制，未改写旧 registry、authority 或 durable facts 来制造通过。

[PG16 升级回执](evidence/upgrade/pg16-writer-v2/upgrade-receipt.json)、[PG17 升级回执](evidence/upgrade/pg17-writer-v2/upgrade-receipt.json)、[PG16 Root 日志](evidence/upgrade/pg16-writer-v2/replay_noninitial_and_complete_root.native.log.gz)、[PG17 Root 日志](evidence/upgrade/pg17-writer-v2/replay_noninitial_and_complete_root.native.log.gz)。

## 原数据完整比较与逐项变化

迁移前，每版数据库有 **45 表、39 行：26 条迁移 ledger 与 13 条业务行**，包括 graph definition、node-attempt completion、node attempt、result consumption、pending result、run-attempt claim 各 1 条，checkpoint 2 条、event 4 条、run 1 条。迁移阶段逐个比较每条原行的每个原列，包括每版全部 **103 个非空 bytea 单元**（含 canonical bytes、digest、26 个原 ledger checksum），全部保持不变。26 条旧 ledger 的安装/执行字段等完整列值也保持不变；只新增成功版本 27..36。

迁移新增 10 张空表：`graph_frame_barriers`、`graph_frame_caller_bindings`、`graph_frame_closed_callers`、`graph_frame_closures`、`graph_frame_entries`、`graph_frame_heads`、`graph_frame_returns`、`graph_frame_stacks`、`graph_wait_conditions`、`root_graph_barriers`。4 张旧表共新增 8 列：`run_checkpoints.graph_namespace=''` 与 4 个可空 frame 字段/checksum（两个原 checkpoint 均为 null）；生成列 `runs.checkpoint_graph_namespace=''`；生成列 `agent_admissions.checkpoint_graph_namespace`（无旧行）；`child_run_ownership.parent_graph_namespace`（无旧行）。这些新增项均明确记录，未静默过滤。

迁移后，higher-fence claim 与重放**仅改变原 runs 单行的 6 列**：`fencing_epoch` 1→2、`lease_attempt_id`、`lease_acquired_at`、`lease_renewed_at`、`lease_expires_at`（严格为新 acquisition +30 秒）、`updated_at`。所有前后值均保留。全部 55 表的其余列保持一致，包括所有原 canonical byte/digest、lifecycle、event、checkpoint、node/result 与原 ledger 字段。因此，本报告不把这 6 个所有权字段本身描述成不可变。

[PG16 迁移比较](evidence/upgrade/pg16-writer-v2/migration-data-comparison.json)、[PG17 迁移比较](evidence/upgrade/pg17-writer-v2/migration-data-comparison.json)、[PG16 租约六列变化](evidence/upgrade/pg16-writer-v2/replay-data-comparison.json)、[PG17 租约六列变化](evidence/upgrade/pg17-writer-v2/replay-data-comparison.json)。完整原始/迁移后/重放后/负向检查后的逐表快照、准确列元数据及原 schema dump 均以确定性 gzip 保留并由索引绑定。

## 旧 writer 拒绝新 schema 是独立负向检查

成功 reader 场景后，同一个原发布测试二进制被明确用于 schema36。双版均 **exit 101、0 通过 / 1 失败 / 0 ignored**，原因为 `Migration { source: VersionMissing(27) }`，发生在业务写入前。完整行/列快照保持不变。这是预期的新 schema 拒绝负向检查，**绝不计为产品 Native 通过**。

[PG16 负向回执](evidence/upgrade/pg16-writer-v2/old-writer-new-schema.negative.receipt.json)、[PG17 负向回执](evidence/upgrade/pg17-writer-v2/old-writer-new-schema.negative.receipt.json)、[PG16 原拒绝日志](evidence/upgrade/pg16-writer-v2/old-writer-new-schema.negative.log.gz)、[PG17 原拒绝日志](evidence/upgrade/pg17-writer-v2/old-writer-new-schema.negative.log.gz)。

## 保留的失败准备步骤

首次发布包构建因缺 sibling Core JSON 路径而 exit 101，58 个原文件与锁未变；补齐恰好 5 个原发布 fixture 后构建通过，未编辑 library/tests/lock。首版外部采集 runner 看到旧 writer 成功摘要，但误把整行 JSON 排序当作迁移版本排序而 exit 1；原 stderr 仅在工具终端看到，未保存原始字节。本包明确把针对原 v1 冻结快照、同一错误断言另行捕获的日志标为离线复现，不冒充原 stderr。采用新 v2 库，并在后续检查前先落进程退出回执，避免从不完整采集授予资格。首次 reader fixture 构建因调用不存在的 `GraphReference::reducer` 而 E0599/exit 101；修正为完整 pinned GraphReference 相等，并从已加载 CompiledGraph 取得 reducer。生产源码未变。全部失败构建回执/诊断、原 v1 快照与错误 fixture 均保留，未放宽失败的产品验证。

[缺 fixture 的原构建](evidence/released-build-v1/receipt.json)、[runner 诊断与准确来源](evidence/upgrade/runner-v1-diagnostic/receipt.json)、[reader 首编](evidence/upgrade/reader-build-v1/receipt.json)、[首编错误 fixture](evidence/upgrade/reader-build-v1/released_alpha1_upgrade.rs)。

## 复核与资格转授边界

在本包执行 `python3 verify.py`，可检查实际文件/原字节哈希、确定性 gzip、原 release archive/fixture、精确 reader 输入、真实 Native 摘要/marker、全部行/bytea/ledger 比较、明确租约六列变化和负向检查。`python3 verify.py --local-inputs` 额外核保留的外部二进制与冻结源码，不运行测试、不改数据库，也不认证 main。紧凑归档不包含二进制或可重建 target cache。

只有后续经过独立审阅的生产编译输入逐字相等证明，才可把**这一具体 case**转授到最终 schema36 候选。其他源码、组合候选、schema36 采用、历史场景、发布版本、资源或平台声明仍须相应证明或实际执行。本报告不授予这些更广资格。

本任务 reader 编译缓存已在核实 realpath、Cargo cache tag、Git 与打开文件后清理；日志、二进制和源码均保存在缓存外。并发团队活动期间 `df` 实际观察可用空间增加 517480 KiB，不以 `du` 累计量声称释放空间。[清理回执](evidence/upgrade/cache-clean-receipt.json)。
