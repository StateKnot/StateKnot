# A2A 初始授权文档静态预审

范围：独立审阅 draft-v1 五份文档相对 `1638f5adb597f5cafdcb2923608ca63ed75eccfe` 的增量，对照 green-source-v1 的 `a2a_server.rs`、冻结 v3 contract/入口与 body 矩阵及 additive `compatibility-scope.md`。本审阅未编写这五份文本；不属于最终源码、测试或执行资格审阅。

发现 1 项文档范围歧义（P2），无其他本轮范围内发现：

- `docs/a2a-server.md:87–89` 在 “Host authentication, policy and admission futures...” 后写 “the boundary refuses a late valid result after control returns”；中文 `docs/a2a-server.zh-CN.md:76–77` 对应句相同。该连读把新 post-clock 拒绝保证泛化到 authentication。生产 `enforce_boundary:1095–1122` 保留原 `timeout(authenticate).await`，没有认证开始期限的后置时钟检查；新 preparation D 在成功认证返回后才建立。应将后句限定为准备阶段的 normalization/decoded authorization/admission 晚结果，不改变原认证语义或新增认证保证。Root 已明确接受此更正；本 v1 原件保持不变，后续另 v2 闭合。

已核对：单次 post-auth monotonic D；两 policy callback 共用剩余时间而 backend 保留独立预算；十一 decoded operation 与三类实际 JSON 路径；push 原 Parts/headers/Content-Length/bytes 与同 configured limit；原 buffer 400/413、允许 Origin、send/RPC 原 early-error 与新 408/503 分工；初始 policy 使用原 binding pre-stream error envelope；复合无效输入不承诺原拒绝优先级；late valid normalization/policy 检查、pending future 由请求拥有、permit 最后 guard 的可能瞬时 acquire、request 容量释放、同步工作不可抢占、外部配额不回滚及无即时 disconnect/持久 Task cancellation 承诺。

五文件均为插入式增量（共124行新增、0行移除）；所有原段落和组装示例未删除或改写。既有订阅资格文字原样保留，本轮没有补任何新测试通过断言。中文/英文 RFC25 保持 Draft。只做文件/Git show 只读与 ignored 证据写入，无 Rust、网络、DB、Docker、缓存或 main/index 修改。
