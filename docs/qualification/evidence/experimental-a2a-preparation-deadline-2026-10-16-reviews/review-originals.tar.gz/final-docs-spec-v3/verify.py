#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,sys
H=Path(__file__).resolve().parent;R=H.parents[3]
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 draft=sys.argv[1:]==['--draft'];assert not sys.argv[1:] or draft
 if not draft:
  m=load(H/'manifest.json');assert sha(H/'manifest.json')==load(H/'seal.json')['manifest_sha256']
  assert {str(p.relative_to(H)) for p in H.rglob('*') if p.is_file()}=={x['path'] for x in m['files']}|{'manifest.json','seal.json'}
  for v in m['files']:
   p=H/v['path'];assert p.stat().st_size==v['bytes'] and sha(p)==v['sha256']
 for v in load(H/'inputs.json')['files']:
  p=R/v['path'];assert p.stat().st_size==v['bytes'] and sha(p)==v['sha256']
 r=load(H/'receipt.json');assert r['remaining_findings']==0 and len(r['changed_files'])==2
 assert r['qualification_target_contents_or_publication_verified'] is False
 print(json.dumps({'state':'verified','docs5_remaining_Spec_findings':0,'link_target_content_review':'deferred to publication candidate','new_Native_fullCI_R1':False}))
if __name__=='__main__':main()
