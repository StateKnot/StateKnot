#!/usr/bin/env python3
"""Read-only publication Spec replay. Never executes Cargo or preserved runners."""
import ast
import gzip
import hashlib
import io
import json
import re
import tarfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
DAY = ROOT / '.local-verification/2026-10-16'
NAME = 'experimental-a2a-preparation-deadline-2026-10-16'
EP = 'docs/qualification/evidence/' + NAME
sha = lambda b: hashlib.sha256(b).hexdigest()
obj = lambda p: json.loads(p.read_bytes())


def safe(value):
    p = Path(value)
    assert value and not p.is_absolute() and '..' not in p.parts, value
    return p


def checked_rows(base, rows):
    assert len({r['path'] for r in rows}) == len(rows)
    for row in rows:
        p = base / safe(row['path'])
        assert p.is_file() and not p.is_symlink()
        data = p.read_bytes()
        assert (len(data), sha(data)) == (row['bytes'], row['sha256']), row['path']


def functions(text):
    return {n.name: ast.get_source_segment(text, n) for n in ast.parse(text).body
            if isinstance(n, ast.FunctionDef)}


def summaries(data):
    return [tuple(map(int, r)) for r in re.findall(
        rb'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',
        data, re.M)]


def main():
    inputs = obj(HERE / 'inputs.json')
    checked_rows(ROOT, inputs['fixed_input_files'])
    package = DAY / 'a2a-initial-authority-publication-preparation-v3'
    candidate = package / 'candidate'
    evidence = candidate / EP
    rows = obj(package / 'candidate-manifest.json')['files']
    checked_rows(candidate, rows)
    actual = {p.relative_to(candidate).as_posix() for p in candidate.rglob('*') if p.is_file()}
    assert actual == {r['path'] for r in rows} and len(rows) == 186
    assert sum(r['bytes'] for r in rows) == 1568011
    assert all(not set(Path(p).parts) & {'target', 'node_modules', '.git', '__pycache__'} for p in actual)
    checked_rows(evidence, obj(evidence / 'manifest.json')['artifacts'])

    index = obj(evidence / 'artifact-index.json')['artifacts']
    assert len(index) == 175
    index_by_path = {r['path']: r for r in index}

    def raw(name):
        if name not in index_by_path:
            name += '.gz'
        r = index_by_path[name]
        data = (evidence / safe(name)).read_bytes()
        assert (len(data), sha(data)) == (r['stored_bytes'], r['stored_sha256'])
        if r['storage_encoding'] == 'gzip':
            assert data[4:8] == b'\0' * 4 and not data[3] & 8
            data = gzip.decompress(data)
        else:
            assert r['storage_encoding'] == 'identity'
        assert (len(data), sha(data)) == (r['raw_bytes'], r['raw_sha256'])
        return data

    origin_modes = {'literal_bytes': 0, 'original_gzip_raw': 0}
    for row in index:
        data = raw(row['path'])
        if row['origin'].startswith('.local-verification/'):
            original = (ROOT / safe(row['origin'])).read_bytes()
            if original == data:
                origin_modes['literal_bytes'] += 1
            else:
                assert row['origin'].endswith('.gz')
                assert gzip.decompress(original) == data
                origin_modes['original_gzip_raw'] += 1
                # These four originals are already deterministic archives.
                assert original == (evidence / row['path']).read_bytes()
    assert origin_modes == {'literal_bytes': 163, 'original_gzip_raw': 4}

    delivery = obj(evidence / 'reviews/delivery.json')
    with tarfile.open(fileobj=io.BytesIO(raw(delivery['archive'])), mode='r:') as archive:
        members = archive.getmembers()
        assert len(members) == len({m.name for m in members}) == len(delivery['files']) == 45
        assert all(m.isfile() and not m.issym() and not m.islnk() for m in members)
        review_bytes = {safe(m.name).as_posix(): archive.extractfile(m).read() for m in members}
    for r in delivery['files']:
        data = review_bytes[r['path']]
        assert data == (ROOT / safe(r['origin'])).read_bytes()
        assert (len(data), sha(data)) == (r['bytes'], r['sha256'])
    assert raw('contract/input-corrections.md') == review_bytes['source-spec-v1/input-corrections.md']
    assert sha(raw('contract/input-corrections.md')) == '6157df186b06c61505b862ce7bc05077d21d241c6043e11f0348fc39afd714bb'

    provenance = obj(evidence / 'source/reader-provenance.json')
    original_reader = (ROOT / safe(provenance['published_reader_path'])).read_bytes()
    reader = (evidence / 'reconstruct.py').read_bytes()
    assert sha(original_reader) == provenance['published_reader_sha256']
    assert sha(reader) == provenance['extracted_reader_sha256']
    f, g = functions(original_reader.decode()), functions(reader.decode())
    assert all(f[n] == g[n] for n in provenance['functions'])
    assert provenance['executes_preserved_runners'] is False
    references = obj(evidence / 'source/references.json')['files']
    checked_rows(ROOT, references)
    assert len(references) == 28

    commands = obj(evidence / 'execution/commands.json')
    runner_tree = ast.parse(raw('original/q5/run-gate.py'))
    gates_literal = next(ast.literal_eval(n.value) for n in runner_tree.body
                         if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'GATES' for t in n.targets))
    assert commands == gates_literal
    receipts = []
    for name in index_by_path:
        if not (name.startswith('original/') and name.endswith('.receipt.json')):
            continue
        r = json.loads(raw(name))
        if 'gate' not in r:
            continue
        label = name.split('/')[1]
        prefix = 'original/' + label + '/'
        scope = json.loads(raw(prefix + 'scope.json'))
        frozen = json.loads(raw(prefix + 'frozen-source-manifest.json'))
        assert r['argv'] == commands[r['gate']]
        assert Path(r['cwd']) == DAY / scope['source_directory']
        assert r['runner_sha256'] == sha(raw(prefix + 'run-gate.py'))
        assert r['source_tree'] == frozen['source_tree_sha256']
        assert r['log_sha256'] == sha(raw(prefix + r['gate'] + '.log'))
        assert r['source_before_after_exact'] is True and r['native_database_execution'] is False
        assert r['pid'] > 0 and r['runner_pid'] > 0 and r['start_unix'] > 0 and r['seconds'] >= 0
        env = r['environment_allowlist']
        assert env['CARGO_INCREMENTAL'] == '0'
        assert env['RUSTFLAGS'] == env['RUSTDOCFLAGS'] == '-D warnings'
        for profile in ('DEV', 'TEST'):
            for field in ('OPT_LEVEL', 'DEBUG'):
                assert env['CARGO_PROFILE_' + profile + '_' + field] == '0'
            for field in ('DEBUG_ASSERTIONS', 'OVERFLOW_CHECKS'):
                assert env['CARGO_PROFILE_' + profile + '_' + field] == 'true'
        assert not any(r['override_presence'].values())
        receipts.append({'path': name, 'gate': r['gate'], 'exit_code': r['exit_code']})
    assert len(receipts) == 15
    expected_history = {
        'original/red/red-policy.log': [(0, 1, 0)],
        'original/q1/tcp.log': [(5, 4, 0)],
        'original/q2/tcp.log': [(7, 2, 0)],
        'original/q3/tcp.log': [(9, 0, 0)],
    }
    for name, expected in expected_history.items():
        assert summaries(raw(name)) == expected
    assert b'left: 200' in raw('original/red/red-policy.log') and b'right: 500' in raw('original/red/red-policy.log')
    for name in ('original/red/red-policy', 'original/q1/tcp', 'original/q2/tcp', 'original/q3/clippy', 'original/q4/clippy'):
        assert json.loads(raw(name + '.receipt.json'))['exit_code'] == 101
    ws, docs = summaries(raw('original/q5/workspace.log')), summaries(raw('original/q5/doctests.log'))
    assert (len(ws), tuple(sum(r[i] for r in ws) for i in range(3))) == (100, (2119, 0, 6))
    assert (len(docs), tuple(sum(r[i] for r in docs) for i in range(3))) == (10, (48, 0, 0))

    profile = obj(evidence / 'execution-profile.json')
    report = obj(candidate / ('docs/qualification/' + NAME + '.json'))
    assert all(report[k] == v for k, v in profile.items())
    assert profile['integration_family_total_including_retained'] == 9
    assert 'new_TCP_family_total_including_retained' not in profile and 'new_TCP_family_total_including_retained' not in report
    assert profile['supplied_compilation_inputs'] == 540 and profile['source_rows_bound_but_not_fully_reconstructed'] == 931
    assert all(profile[k] is False for k in ('Native_database_qualified', 'fullCI_qualified', 'cold30m_qualified', 'stdio_qualified', 'R1_complete', 'actual_main_adoption_proved_in_this_seal'))
    reconstruction = obj(evidence / 'source/reconstruction.json')
    assert reconstruction['reconstruct_all931_noncompiled_source_files'] is False
    assert reconstruction['whole_Git_or_compiler_read_closure'] is False
    assert len(reconstruction['changes']) == 4
    for change in reconstruction['changes']:
        assert sha(raw(change['payload'])) == change['after_sha256']
    # Full reconstruction, historical patch replay, manifest binding and current
    # workspace bytecheck are additionally exercised by the package verifier.
    for label in ('v3-offline', 'v3-workspace'):
        receipt = obj(HERE / (label + '.receipt.json'))
        assert receipt['exit_code'] == 0 and receipt['verifier_sha256'] == sha((evidence / 'verify.py').read_bytes())
        for stream in ('stdout', 'stderr'):
            assert receipt[stream + '_sha256'] == sha((HERE / (label + '.' + stream)).read_bytes())
        output = obj(HERE / (label + '.stdout'))
        assert output['status'] == 'passed' and output['gate_receipts_verified'] == 15
        assert output['workspace_bytecheck'] == (label == 'v3-workspace')
        assert output['reconstructed_supplied_compilation_inputs'] == 540
        assert output['Native_database_qualification'] is False and output['whole_Git_or_compiler_read_closure'] is False

    # Compare actual bytes, rather than relying on authors' increment claims.
    increments = []
    for a, b in ((1, 2), (2, 3)):
        oldp = DAY / ('a2a-initial-authority-publication-preparation-v' + str(a))
        newp = DAY / ('a2a-initial-authority-publication-preparation-v' + str(b))
        old = {r['path']: r for r in obj(oldp / 'candidate-manifest.json')['files']}
        new = {r['path']: r for r in obj(newp / 'candidate-manifest.json')['files']}
        checked_rows(oldp / 'candidate', list(old.values()))
        checked_rows(newp / 'candidate', list(new.values()))
        changed = sorted(n for n in old.keys() | new.keys() if old.get(n) != new.get(n))
        increment = obj(newp / 'increment.json')
        claimed = increment.get('changed_files', increment.get('changes'))
        assert changed == sorted(r['path'] for r in claimed)
        assert len(changed) == 8
        for row in claimed:
            n = row['path']
            assert row['before_sha256'] == (old[n]['sha256'] if n in old else None)
            assert row['after_sha256'] == new[n]['sha256']
        for n in old:
            if n.startswith(EP + '/original/') or n.startswith(EP + '/source/') or n.startswith(EP + '/reviews/'):
                assert (oldp / 'candidate' / n).read_bytes() == (newp / 'candidate' / n).read_bytes()
        increments.append({'from': a, 'to': b, 'changed_paths': len(changed)})

    links = []
    for suffix in ('.md', '.zh-CN.md'):
        page = candidate / ('docs/qualification/' + NAME + suffix)
        for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)', page.read_text()):
            assert '://' not in target and (page.parent / target.split('#')[0]).is_file(), target
            links.append(target)
        assert 'contract/input-corrections.md' in page.read_text()
    assert len(links) == 16
    docs = DAY / 'a2a-initial-authority-adoption-docs-v3/candidate'
    for guide, suffix in (('docs/a2a-server.md', '.md'), ('docs/a2a-server.zh-CN.md', '.zh-CN.md')):
        text = (docs / guide).read_text()
        target = 'qualification/' + NAME + suffix
        assert target in text
        assert (candidate / 'docs' / target).is_file()
        assert (ROOT / guide).read_bytes() == (docs / guide).read_bytes()
    if (HERE / 'manifest.json').exists():
        checked_rows(HERE, obj(HERE / 'manifest.json')['files'])
        assert obj(HERE / 'seal.json')['manifest_sha256'] == sha((HERE / 'manifest.json').read_bytes())
    print(json.dumps({'status': 'passed', 'candidate_paths': 186, 'artifacts_indexed': 175,
        'origin_comparisons': origin_modes, 'review_originals_exact': 45, 'reader_functions_exact': 4,
        'published_source_references_exact': 28, 'original_gate_receipts': len(receipts),
        'report_links': len(links), 'adoption_guide_targets': 2, 'increments': increments,
        'actionable_publication_Spec_findings': 0, 'Native_or_fullCI_or_R1_qualification': False}, sort_keys=True))


if __name__ == '__main__':
    main()
