# A2A preparation deadline 发布包独立 Spec 审查

最终结论：publication-preparation-v3 的剩余可行动 Spec 问题为 **0**。独立运行最终发布 verifier 的 offline 和当前主树 `--workspace` 均实际 exit0；本目录的补充离线核验也实际 exit0。本审查没有执行 Cargo、网络、数据库、Docker 或 CI，没有修改主树、候选、原始回执或既有封签。

审核者没有编写这份发布包、生产实现、测试或采用文档；审核者编写过起始契约，并在先前独立实现 Spec 审核中公开纠正了自己提供的四个 RPC 方法名。这里复用已封源码 Spec/文档 Spec 的限定结论，重新审核发布交付及最终链接，不把起始契约作者身份隐去。测试与发布包由同一作者完成，未把作者自验算成独立审查。

## 最终身份与增量

- 最终 candidate：186 paths、1,568,011 bytes；manifest `a840127abc483db26f3f1af3fd653a7023b837545f1bae9c68fe8601a38cf8ff`。
- evidence manifest `32a9b08c732318022da2d0e5dd26a9979a30be5c05f1bca41d4274222cc09426`；seal `11b27dae01728967caf61d8e64caa7f5b0e6e1938bd7e512193583fde2ae379e`。
- 原931行来源清单摘要 `9a98cd929c10698f8cb866b99b3fd00a9b0f69dd840a68da1d01f5b30817f49d`；540个 supplied compilation inputs 摘要 `c3c5ed5bb8f102d9b1b31bf1afbb21e75e1e05d4e2b37d523f4ba4ca2bc80edc`。

逐字比较 v1→v2、v2→v3，每个增量都只有8个清单路径变化，分别对应已知标签/措辞更正和公开勘误及随之变化的绑定文件。全部既有 original/source/reviews 文件逐字不变。v1、v2 的 manifest、seal、原始失败保持原件。

v1 将9个混合 Router/TCP integration families 命名为 `new_TCP_family_total_including_retained`，并将 Q5 的 callback Drop 观察泛称 admission 控制；这些文字/机器范围问题在 v2 关闭。v3 直接交付 `contract/input-corrections.md`，内容与源码 Spec 原件及 review tar 中的同一文件逐字相等，SHA `6157df186b06c61505b862ce7bc05077d21d241c6043e11f0348fc39afd714bb`。两份报告可直接打开勘误；原 entry-matrix 四个历史错误 wire 名未被覆盖，也不再作为当前 wire 要求。

## 证据与真实执行口径

175条 artifact 索引全部核验 stored/raw SHA。167项有明确本机原始来源，其中163项与原始 bytes 相等，4份本来已压缩的 patch 的原 gzip bytes 以及解压内容均相等。45份原始 Standards v1–v5 / Spec 文件与各自封签目录逐字相等，tar 只在内存中读取，未解包写回。四个 source reader 函数与已发布 verifier 的对应函数源文本一致，28份旧公开源码引用的 bytes/hash 相符。没有复制整个旧源码 archive、构建产物或缓存；旧公开资产只作为来源读取，不转授旧测试资格。

实际 `run-gate.py` 和 `run-six-gates.py` 完整交付。`execution/commands.json` 与实际 runner 的 literal GATES 表相等；15份历史/最终 gate 回执的 argv、cwd、pid/start、runner SHA、原始 log SHA、来源清单、源码前后相等、allowlist profile 与 override 状态均对应原件。最终6门实际 exit0：workspace 100组、2119通过、0失败、6项旧 ignored；doctests 10组、48通过、0失败/ignored。Rust1.88、固定 nightly、dev/test opt0/debug0/incremental0、debug assertions/overflow checks 和 warnings-denied 记录与 EN/CN/JSON 一致，未转写为 CI opt1/cold 性能资格。

原产品 red 是第一个累计 deadline 用例完整 HTTP200 与应有500的实际反例，0通过/1失败/8过滤；没有扩成所有21项都已见红。Q1 的5通过/4失败是旧 rlib 复用，Q2 的7通过/2失败是通知/SDK method 夹具错误，Q3 的9通过与随后生产函数尺寸 Clippy 失败、Q4 三项夹具 lint 和静态 owner 观测范围问题、Q5 全门通过分别保留。初始 source equality 不被说成 compiler read closure，mtime freshness 记录也没有被说成完整编译读取证明。两次发布作者辅助 verifier 的元数据格式/查找错误仍留在 v1 authoring-failures；不是产品 red。本审核自己的输入收集器曾猜错 docs 清单文件名，在实际 package verifier 运行前终止，已另留 `collector-attempt1.json`，未伪装为产品/包校验失败。

## 契约、链接与边界

两份报告和机器报告对单个 post-auth body/normalization/decoded policy deadline、authn/backend 各自原独立 budget、11操作双绑定、原及时 callback 错误、原 push bytes/parts/配置上限、shutdown/clock 检查、最后 permit 可瞬时取得后立即退役等描述，与最终 source-v5/helper、已封源码 Spec 和真实门禁一致。3个新 private tests、8个新 integration families 和原1个17×2矩阵按真实 libtest family 计数，未把9个 family 都称为 TCP、未把矩阵行数当独立测试数。内部同步 SDK decode 的 CPU 时间及 acquire→guard 无 await 窗口未强制重现，报告如实保留；没有 CPU 抢占、固定响应时限、已发 bytes 回收、callback 外部副作用回滚承诺。

16个报告相对链接全部落在最终 candidate 内。最终5docs-v3 的两个 guide 链接现在都对应实际 EN/CN 报告；两个主树 guide 与已封采用候选 bytes 相等。先前文档审查中“链接目标待成包”这一限定已在此关闭，未反改旧审查记录。旧表输入纠错、已接受的复合无效输入拒绝先后范围和 truncated TCP 只有在传输暴露完整响应时才比较的限定均可公开读取。

最终 verifier 重构的是540个实际交付编译输入，931行只核其摘要和回执绑定，没有重构其余非编译文档。当前 `--workspace` exit0 是 code/docs 已采用后该540项的逐字正控，不意味着包内已证明采用前结果、完整 Git tree、实际 compiler read closure、采用文档完整性或远端提交状态；未回写旧失败。Native database、真实 IdP/current-mapping 后端、durable tasks、stdio、完整 CI、原30分钟预算、pilot 和 R1 完成仍未获本包资格。本审查也不新增上述运行资格。
