# 初始 A2A authority — Standards 静态审阅 v1

角色：四个变更源码的非作者 Standards 审阅，不是 Spec、执行事实或最终资格审阅。固定 `a2a-initial-authority-source-v1`：931 文件/tree `2c5b1af6062e6c6c4e221f8461c385f00528784b8121297e28cc6c1bcfd1b2d7`，540 个保守编译输入 canonical `f013eb590df4b86515c777a1e393d2c731d175a06822f37a61697b286fe87245`。对照 `1638f5` 来源的 source-base-v2、冻结 v3 contract 和 additive compatibility decision。

硬性标准违反 0；生产代码阻碍 0。另有两项非阻塞、判断性质的测试改进，Root 已接受、待独立 v2 闭合：

1. `tests/a2a_server_subscription/initial_authority.rs:385`：`business` 已记录真实 `A2aServerOperation`，`assert_facts` 却只断言数量。十一操作正常正控即使 dispatch 到错误的 backend 方法，也可能仍满足一个 business 记录。保留数量断言，并逐项核对记录的 enum 等于预期 `operation.operation`，可使现有正控直接证明实际方法。此为 oracle 强化建议，不是已验证生产错派发。
2. `src/a2a_server/preparation_tests.rs:124`：`clones > 0` 要求 extractor 输入必须发生复制，超出了“交付原 extension 实例、完整原 parts/bytes”的契约；未来合法的不复制实现也会失败。保留 `instance == 0`、完整 HeaderMap/URI/version/raw bytes 等断言，将 clone 次数仅作观测或移除该要求。此为实现耦合的维护性判断，不是兼容性漏洞。

依据：`CONTRIBUTING.md` 的行为变化测试、范围和长期维护要求；RFC process 对边界/兼容变化的要求；用户要求生产级方案；deep-module 与 Fowler smell 基线作为判断启发。未把 formatter/Clippy 等工具可判的事项列为静态发现。新行为已有冻结契约、独立文档候选/CHANGELOG；它们的实际采用及门禁另行处理。RFC25/pre-alpha 状态不因本报告改变。

本轮逐字核验：相对 baseline929，恰好2改+2新增、927文件不变；生产去掉唯一 cfg-test child hook 后等于已预审 `2f6bc118…`；从 `unary` 起的原生产 suffix（含 stream/bounded stream/全部业务方法）字节不变；原17×两binding TCP矩阵函数2082字节/SHA `e4c9790f9e19c10be1ea1649ba89068d3c28376e6447530b7d172ef167fe2a97` 完整保留；旧 subscription 私有测试文件逐字相同；三测试文件与作者冻结 payload hashes 一致。

已读所有新 child 与 parent/prod 差异：task-local deadline 私有且无 fallback、单D由 boundary 持有、SDK extractor/错误复用而非重写 parser、DefaultBodyLimit 原数值组合、请求拥有的 callback/body 与 permit、legacy initial=None 路径、完整 REST/RPC 错误比较与唯一 UTC 字段规范化、真实 TCP vs direct ownership 分工、Clone-distinguishable 原 Parts、11operation×2binding 矩阵、cap1 正控及 pending/ready/shutdown 对照。没有新增通用接口/依赖/SQL/默认 stack/业务资源修改。未见需要因 smell baseline 扩大重构的理由。

本报告未执行 Cargo、Rust、TCP、DB、Docker 或网络命令，未修改 main、候选源码、缓存或原证据。8 integration families+3 private tests 只是静态 inventory，原红、实际二进制来源和后续门禁结果不由本报告转授。当前 Root 另在验证实际编译输入；本静态结论不替代它。
