#!/usr/bin/env python3
"""Offline source/evidence Spec verification; does not execute Rust/network/DB."""
from pathlib import Path
import hashlib,json,re,sys
H=Path(__file__).resolve().parent;R=H.parents[3];B=R/'.local-verification/2026-10-16';Q=B/'a2a-initial-authority-qualification-v5';S=B/'a2a-initial-authority-source-v5'
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 draft=sys.argv[1:]==['--draft'];assert not sys.argv[1:] or draft
 if not draft:
  m=load(H/'manifest.json');assert sha(H/'manifest.json')==load(H/'seal.json')['manifest_sha256']
  assert {str(p.relative_to(H)) for p in H.rglob('*') if p.is_file()}=={r['path'] for r in m['files']}|{'manifest.json','seal.json'}
  for v in m['files']:
   p=H/v['path'];assert p.stat().st_size==v['bytes'] and sha(p)==v['sha256'],v['path']
 for v in load(H/'inputs.json')['files']:
  p=Path(v['path']);p=p if p.is_absolute() else R/p
  assert p.stat().st_size==v['bytes'] and sha(p)==v['sha256'],str(p)
 for name,count in [('frozen-source-manifest.json',931),('compiled-inputs.json',540)]:
  m=load(Q/name);assert m['count']==len(m['files'])==count
  for row in m['files']:
   p=S/row['path'];assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
 summary=load(Q/'summary.json');assert summary['six_gates_passed']
 for gate in ['fmt','clippy','workspace','doctests','rustdoc','nightly']:
  v=load(Q/(gate+'.receipt.json'));assert v['exit_code']==0 and v['source_before_after_exact']
  assert v['runner_sha256']==sha(Q/'run-gate.py') and v['log_sha256']==sha(Q/(gate+'.log'))
  assert not v['native_database_execution'] and all(not x for x in v['override_presence'].values())
  for prof in ['DEV','TEST']:
   for suffix,val in [('OPT_LEVEL','0'),('DEBUG','0'),('DEBUG_ASSERTIONS','true'),('OVERFLOW_CHECKS','true')]:assert v['environment_allowlist'][f'CARGO_PROFILE_{prof}_{suffix}']==val
 def parse(p):
  rows=[tuple(map(int,m.groups())) for m in (re.fullmatch(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in .+',l) for l in p.read_text().splitlines()) if m]
  return [len(rows)]+[sum(r[i] for r in rows) for i in range(3)]
 assert parse(Q/'workspace.log')==[100,2119,0,6] and parse(Q/'doctests.log')==[10,48,0,0]
 assert len(load(H/'static-progress.json')['contract21_mapping'])==21
 assert load(H/'receipt.json')['actionable_Spec_findings']==0
 print(json.dumps({'state':'verified','actionable_Spec_findings':0,'source931':summary['source_tree'],'compiled540':summary['compiled_sha256'],'workspace_passed':2119,'doctests_passed':48,'Native_fullCI_R1':False}))
if __name__=='__main__':main()
