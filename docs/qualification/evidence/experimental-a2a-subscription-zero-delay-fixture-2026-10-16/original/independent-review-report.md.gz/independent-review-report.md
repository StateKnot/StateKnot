# A2A 零延时夹具与失败诊断独立审查

审查者 `/root/a2a_fixture_review_oct16c`。固定基线为 `ff7fea7db88a611e2f0db29ceedf6b0b4b48f5fa`，候选为 `a2a-subscription-status-diagnostic-authoring-v1/{candidate,red-control-candidate}`，并核对父 agent 后续的 red-v2 / green-v2 源码与实际记录。本 agent 没有编译 Rust、执行测试、访问数据库、Docker 或远程，也没有修改主工作树；只在本 ignored 审查目录写文件。读取记录不等于独立重跑这些测试。

使用 mattpocock `code-review` 与 `codebase-design` 技能。按父任务要求由同一独立审查者分别完成 Standards 和 Spec 两轴；没有再启动子 agent。这不是两个互相隔离的平行评审。

## Standards

**剩余可操作发现：0。**

依据 `CONTRIBUTING.md` 的聚焦、可独立回退、行为需有测试和不得扩大生产资格要求，以及 workspace edition2024、禁止 unsafe 和现有 lint 配置，两个 authoring 候选各只提供一个原有测试文件。Setup、Authenticator、Policy、Service 和生产实现的原始区域未改；没有增加公开 interface、依赖、allow、重试、超时数值或生产配置。诊断 helper 在测试内部集中多处失败采集责任，有实际复用与 locality，没有因本次需要引入新的生产 seam。

原 authoring red 的局部 `use std::future::Future as _;` 已在第一次真实严格编译被判定为 unused。该次 exit101 没有执行测试，不能作为回归 red。父 agent 在 red-v2 仅删除该导入，并保留 rustfmt 对 `event.to_string().replace(...)` 的换行整理；green 相对 red-v2 只有 `else` 改为 `else if !delay.is_zero()`。这项已修正的编译问题不计为剩余发现。最终完整质量门禁与跨平台 CI 由父任务继续执行，本审查不替代它们。

## Spec

**剩余可操作发现：0。**

要求来自父任务的失败取证与夹具语义约束，并以已冻结 subscription acceptance matrix、既有 preparation deadline 与源码为上下文。独立字节检查确认原 **81 个断言** 全部保留，完整 **17-ID × REST/JSON-RPC** matrix 尾部 SHA256 为 `69dd78bc74c4fb49487d142f0f386c7bcc3af920aa4ee60a4dbf9eae03512d8b`，两候选和最终 green 保持相同；所有原 `Duration` 表达式顺序不变，包括 10/40 ms 请求预算、30 ms 阻塞延时和原非零 pre/post 延时。新增第 82 个断言仅检查零延时回调首次 poll。

HTTP200 且无异常 event 时，observer 立即返回，不读 body 或引入 await 挂起点；正常 SSE 仍由原 reader 读取。HTTP 失败采集使用原 `HARNESS_WAIT`，保留至多 2,048 个 body 字节；错误 task SSE 只输出至多 2,048 个序列化 event 字节，并记录 binding、case、Setup 和阶段计数。它不输出 header、bearer 或 principal，明确替换固定夹具 token。该结论限于受控 loopback fixture：此 helper 不是通用生产脱敏器；event 在截取前完整序列化，2,048 是输出前缀上限，不能据此宣称任意 event 的峰值分配有界。

新控制先经真实 HTTP 请求取得 HEALTHY 与 TASK 的 owning authorization requests，再调用同一 `Policy::authorize` interface，对每个新 future 用 noop waker 仅 poll 一次。默认配置的 gate/pending/block 为空，mode/remapped 为初值；它验证该夹具的零延时 allow 路径立即 Ready。TASK 的新调用索引可能已越过首次请求索引；控制不证明生产授权 future 必须同步、不覆盖每个授权阶段，也不替代原矩阵。非零 sleep、pending、gate、同步 block 和生产截止复核保持原样。

## 实际记录与资格边界

本审查重算了两个源码副本的每份 **933 行完整源清单** 与 **542 行 supplied compilation inputs** 的每文件字节和规范化摘要；red-v2 / green-v2 除该测试文件外逐项一致，且相对其 Wait 源码父清单也仅改这一路径。其完整源摘要分别为 `06c5c6d4e28c6c23faec378cd697634364363f2c1303ec56c305aaececa6a643` 与 `577fa6e6dac49dad92d37eb0683bfaf43a673e86f99d3ad47111b51b26a9104a`。清单按生产者原有 Path 顺序核验，不额外假定相对路径字符串排序，也不把 supplied inputs 当作编译器实际读文件闭包。

已认证父 agent 保存的 raw log / receipt / runner / argv / 允许环境和前后源码绑定：

| 记录 | 实际结果 | 可支持的结论 |
| --- | --- | --- |
| red-v1 | exit101，unused Future import，无 `running 1 test` | 编译失败，未形成回归 red |
| red-v2 | 编译完成后 exit101，0 passed / 1 failed / 9 filtered；HEALTHY 与 TASK 均为 Pending | 实际本机旧零延时夹具不满足新增 first-poll 要求 |
| green-v2 | 编译完成后 exit0，1 passed / 0 failed / 9 filtered | 跳过零时长 sleep 满足这一个控制 |

原 macOS HTTP500、Windows HTTP500 和后一次 Windows HTTP200/Null 日志分别绑定并保留。这些旧日志没有错误正文/event，故不据本机 red→green 推定它们的共同根因，也不宣布 Windows 修复、全 CI、完整 Native、R1 或生产可用阶段完成。需要原完整 target 的并发压力、规定门禁及真实跨平台 CI 继续验证。

`verify.py` 是本次只读复核器，`inputs.json` 固定54个已读来源；仓库来源绑定固定 Git revision，避免父任务后续合法提交让基线被悄然替换。`verification.json` 保存实际成功运行结果。审查期间父 agent 已推进 HEAD 至 `0fbd0a780b41f2b999ec5a95e908d41d2a3f14d9`，其主树状态干净；本审查始终针对上述固定候选和基线。

复核器首次运行因本审查者误加“完整源清单必须字符串排序”的假定返回1；源码与记录没有改变。删除这一未被生产者承诺的排序假定后实际复核为0。该复核器错误不计作源码或 Rust 测试失败。

Standards 0 个剩余发现；Spec 0 个剩余发现。两个轴均无剩余最严重问题；上述执行与资格范围限制继续成立。
