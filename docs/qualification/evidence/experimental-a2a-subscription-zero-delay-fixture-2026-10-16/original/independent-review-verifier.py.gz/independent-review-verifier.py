#!/usr/bin/env python3
"""Read-only checks for one fixture review; does not execute Cargo or tests."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

REPO = Path(__file__).resolve().parents[4]
HERE = Path(__file__).resolve().parent
BASE = REPO / '.local-verification/2026-10-16'
AUTHOR = BASE / 'a2a-subscription-status-diagnostic-authoring-v1'
TEST = 'crates/stateknot-integrations/tests/a2a_server_subscription.rs'
HEAD = 'ff7fea7db88a611e2f0db29ceedf6b0b4b48f5fa'
MATRIX = '#[tokio::test(flavor = "multi_thread", worker_threads = 2)]\nasync fn real_server_subscription_authorization_matrix_covers_both_bindings()'
CONTROL = '#[tokio::test]\nasync fn zero_delay_policy_is_ready_for_real_healthy_and_task_authorizations()'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':')).encode()


def load(path):
    return json.loads(path.read_bytes())


def assertions(source):
    """Extract balanced assert macro bytes, including their original strings."""
    matches = []
    macro = re.compile(r'\b(?:assert|assert_eq|assert_ne|debug_assert|debug_assert_eq|debug_assert_ne)!\s*([({\[])')
    quoted = re.compile(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])\'')
    for match in macro.finditer(source):
        stack = []
        index = match.end() - 1
        while index < len(source):
            char = source[index]
            if source.startswith('//', index):
                end = source.find('\n', index)
                index = len(source) if end == -1 else end + 1
                continue
            if source.startswith('/*', index):
                end = source.index('*/', index + 2)
                index = end + 2
                continue
            literal = quoted.match(source, index)
            if literal:
                index = literal.end()
                continue
            if char in '({[':
                stack.append(char)
            elif char in ')}]':
                assert stack.pop() == {')': '(', '}': '{', ']': '['}[char]
                if not stack:
                    matches.append(source[match.start():index + 1])
                    break
            index += 1
        else:
            raise AssertionError('unterminated assertion macro')
    return matches


def verify_frozen(phase):
    qual = BASE / ('a2a-zero-delay-' + phase + '-qualification-v2')
    source = BASE / ('a2a-zero-delay-' + phase + '-source-v2')
    frozen = load(qual / 'frozen-source-manifest.json')
    compiled = load(qual / 'compiled-inputs.json')
    assert frozen['count'] == len(frozen['files']) == 933
    assert compiled['count'] == len(compiled['files']) == 542
    assert sha(canonical(frozen['files'])) == frozen['source_tree_sha256']
    assert sha(canonical(compiled['files'])) == compiled['sha256']
    rows = frozen['files']
    # Preserve the producer's recorded Path ordering; do not invent a string-order rule.
    mapped = {row['path']: row for row in rows}
    assert len(mapped) == 933
    assert all(row == mapped[row['path']] for row in compiled['files'])
    for row in rows:
        file = source / row['path']
        assert not file.is_symlink()
        raw = file.read_bytes()
        assert (len(raw), sha(raw)) == (row['bytes'], row['sha256']), file
    parent = load(BASE / 'graph-frame-wait-process-fault-qualification-v2/frozen-source-manifest.json')
    assert [row['path'] for row, previous in zip(rows, parent['files']) if row != previous] == [TEST]
    receipt = load(qual / 'zero-delay.receipt.json')
    log = (qual / 'zero-delay.log').read_bytes()
    assert receipt['source_tree'] == frozen['source_tree_sha256']
    assert receipt['log_sha256'] == sha(log)
    assert receipt['runner_sha256'] == sha((qual / 'run-gate.py').read_bytes())
    assert receipt['source_before_after_exact'] is True
    assert receipt['native_database_execution'] is False
    assert receipt['cwd'] == str(source)
    assert receipt['argv'] == [
        'cargo', '+1.88.0', 'test', '-p', 'stateknot-integrations', '--test',
        'a2a_server_subscription', '--all-features', '--locked',
        'zero_delay_policy_is_ready_for_real_healthy_and_task_authorizations',
        '--', '--exact', '--nocapture',
    ]
    env = receipt['environment_allowlist']
    for key in ['CARGO_INCREMENTAL', 'CARGO_PROFILE_DEV_DEBUG', 'CARGO_PROFILE_TEST_DEBUG',
                'CARGO_PROFILE_DEV_OPT_LEVEL', 'CARGO_PROFILE_TEST_OPT_LEVEL']:
        assert env[key] == '0'
    for key in ['CARGO_PROFILE_DEV_DEBUG_ASSERTIONS', 'CARGO_PROFILE_TEST_DEBUG_ASSERTIONS',
                'CARGO_PROFILE_DEV_OVERFLOW_CHECKS', 'CARGO_PROFILE_TEST_OVERFLOW_CHECKS']:
        assert env[key] == 'true'
    assert env['RUSTFLAGS'] == env['RUSTDOCFLAGS'] == '-D warnings'
    assert not any(receipt['override_presence'].values())
    assert b'Finished `test` profile [unoptimized]' in log and b'running 1 test' in log
    if phase == 'red':
        assert receipt['exit_code'] == 101
        assert b'[("task-b", Pending), ("task-a", Pending)]' in log
        assert b'test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 9 filtered out' in log
    else:
        assert receipt['exit_code'] == 0
        assert b'test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 9 filtered out' in log
    return frozen, compiled, receipt


def main():
    inputs = load(HERE / 'inputs.json')
    for row in inputs['files']:
        path = Path(row['path']) if row['absolute'] else REPO / row['path']
        if row.get('revision'):
            raw = subprocess.check_output(['git', 'show', row['revision'] + ':' + row['path']], cwd=REPO)
        else:
            raw = path.read_bytes()
        assert (len(raw), sha(raw)) == (row['bytes'], row['sha256']), path
    baseline = (AUTHOR / 'baseline' / TEST).read_bytes()
    assert baseline == subprocess.check_output(['git', 'show', HEAD + ':' + TEST], cwd=REPO)
    candidate = (AUTHOR / 'candidate' / TEST).read_text()
    raw_red = (AUTHOR / 'red-control-candidate' / TEST).read_text()
    base = baseline.decode()
    original = assertions(base)
    assert len(original) == 81
    assert assertions(candidate) == original
    # The additional control appears just before the original matrix's final assert.
    assert assertions(raw_red)[:80] == original[:80]
    assert assertions(raw_red)[-1] == original[-1]
    assert len(assertions(raw_red)) == 82
    durations = lambda text: re.findall(r'Duration::(?:ZERO|from_[a-z_]+\([^)]*\))', text)
    assert durations(base) == durations(candidate) == durations(raw_red)
    matrix = base[base.index(MATRIX):]
    assert candidate[candidate.index(MATRIX):] == matrix
    assert raw_red[raw_red.index(MATRIX):] == matrix
    prefix = base[:base.index('    async fn healthy(')]
    assert candidate[:candidate.index('    // Failure-only evidence')] == prefix
    assert raw_red[:raw_red.index('    // Failure-only evidence')] == prefix
    control_start = raw_red.index(CONTROL)
    control_end = raw_red.index(MATRIX)
    assert raw_red[:control_start] + raw_red[control_end:] == candidate
    control = raw_red[control_start:control_end]
    for text in [
        'Server::start(Setup::default()).await',
        '.healthy(Binding::Rest, "zero_delay_callback_control")',
        'first(&server, Binding::Rest, "SubscribeToTask").await',
        '[HEALTHY, TASK].map', 'requests.map', 'policy.authorize(request)',
        'Context::from_waker(futures_util::task::noop_waker_ref())',
        'future.as_mut().poll(&mut context)', 'Poll::Ready(Ok(()))',
    ]:
        assert text in control
    observer = candidate[candidate.index('    async fn observe_response_failure('):candidate.index('    async fn healthy(')]
    assert 'if response.status() == 200 && event.is_none() {\n            return;' in observer
    assert 'tokio::time::timeout(HARNESS_WAIT, async' in observer
    assert 'while bytes.len() < 2048' in observer
    assert 'chunk[..chunk.len().min(remaining)]' in observer
    assert observer.count('.replace("subscription-token", "<REDACTED>")') == 2
    assert not any(text in observer for text in ['.bearer(', '.headers(', '.principal('])
    assert sorted(str(p.relative_to(AUTHOR / 'candidate')) for p in (AUTHOR / 'candidate').rglob('*') if p.is_file()) == [TEST]
    assert sorted(str(p.relative_to(AUTHOR / 'red-control-candidate')) for p in (AUTHOR / 'red-control-candidate').rglob('*') if p.is_file()) == [TEST]
    red = (BASE / 'a2a-zero-delay-red-source-v2' / TEST).read_text()
    green = (BASE / 'a2a-zero-delay-green-source-v2' / TEST).read_text()
    without_import = raw_red.replace('    use std::future::Future as _;\n\n', '')
    format_before = '            let rendered = event.to_string().replace("subscription-token", "<REDACTED>");'
    format_after = '            let rendered = event\n                .to_string()\n                .replace("subscription-token", "<REDACTED>");'
    assert without_import.replace(format_before, format_after) == red
    old = '            } else {\n                tokio::time::sleep(delay).await;\n            }'
    new = '            } else if !delay.is_zero() {\n                tokio::time::sleep(delay).await;\n            }'
    assert red.count(old) == 1 and red.replace(old, new) == green
    assert assertions(red) == assertions(green)
    assert durations(base) == durations(red) == durations(green)
    assert green[green.index(MATRIX):] == matrix
    red_frozen, red_inputs, red_receipt = verify_frozen('red')
    green_frozen, green_inputs, green_receipt = verify_frozen('green')
    assert [row['path'] for row, previous in zip(green_frozen['files'], red_frozen['files']) if row != previous] == [TEST]
    assert green_receipt['start_unix'] > red_receipt['start_unix'] + red_receipt['seconds']
    failure = BASE / 'a2a-zero-delay-red-qualification-v1'
    first_receipt = load(failure / 'zero-delay.receipt.json')
    first_log = (failure / 'zero-delay.log').read_bytes()
    assert first_receipt['log_sha256'] == sha(first_log)
    assert first_receipt['exit_code'] == 101
    assert b'error: unused import: `std::future::Future`' in first_log
    assert b'running 1 test' not in first_log
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO).decode().strip()
    status = subprocess.check_output(['git', 'status', '--short'], cwd=REPO).decode()
    print(json.dumps({
        'review_status': 'pass', 'standards_actionable_findings': 0,
        'spec_actionable_findings': 0, 'original_assertion_macros': 81,
        'final_assertion_macros': 82, 'original_matrix_tail_sha256': sha(matrix.encode()),
        'matrix_tail_bytes_exact': True, 'duration_sequence_exact': True,
        'candidate_count': 2, 'candidate_paths_each': [TEST],
        'red_source_tree_sha256': red_frozen['source_tree_sha256'],
        'red_compiled_input_sha256': red_inputs['sha256'],
        'green_source_tree_sha256': green_frozen['source_tree_sha256'],
        'green_compiled_input_sha256': green_inputs['sha256'],
        'frozen_rows_each_verified': 933, 'compiled_rows_each_verified': 542,
        'recorded_red_exit': 101, 'recorded_green_exit': 0,
        'red_v1_compile_failure_distinct': True,
        'executed_cargo_rust_db_docker_remote_by_reviewer': False,
        'full_ci_or_original_windows_cause_qualified': False,
        'current_head': head, 'working_tree_status': status,
        'current_head_matches_review_base': head == HEAD,
        'inputs_manifest_sha256': sha((HERE / 'inputs.json').read_bytes()),
    }, indent=2))


if __name__ == '__main__':
    main()
