# Root execution handoff: mandatory logical backup/restore

Authoring only; the author has not executed the runner, tests, Docker, PostgreSQL,
Cargo or network operations. `build.py` is copied byte-for-byte from the reviewed
Native helper (SHA `3412d08c7a0fdcb6df4ad24f0553aeaea0c92ccb2e4757e6afa67c23e48fd067`).
No build is requested by this wrapper. `run-backup-v2-exact.patch` shows all changes
from the reviewed exact runner-v2.

After all four current composed Native full runs have actual terminal receipts,
write a prerequisite JSON using the `source_tree_sha256`,
`compiled_inputs_sha256` and `full_native_runs` structure documented in the PITR
handoff. Four rows cover PostgreSQL16/17 × Store/Runtime. Each row names the
actual absolute `test_receipt` and its SHA-256. Failed terminal prerequisites
remain recorded as failures; the wrapper does not fabricate success.

```sh
python3 .local-verification/2026-10-18/scoped-join-owner-stop-composed-backup-runner-v1/run-backup.py \
  --build-dir .local-verification/2026-10-18/scoped-join-owner-stop-composed-native-v2/build-candidate-runtime-v1 \
  --major 16 --prerequisites ABSOLUTE_REAL_PREREQUISITE_JSON \
  --out .local-verification/2026-10-18/scoped-join-owner-stop-composed-backup-native-v1/pg16
```

For17, change the major and use a new `pg17` directory. The wrapper checks the
exact source936/compiled544, saved Runtime194 binary `6f633…a4e7e`, build receipt,
default features/opt-level1/default stack, fixed task container identity/image,
loopback mapping and unchanged on/on/on durability settings. It creates a fresh
base database under `stateknot_r1_joincomposedbackup_20261018_pg…`; the unchanged
test creates and drops only its original UUID source/target databases. The base
database is preserved. The wrapper does not clean external resources.

The actual case is
`child_admission::ownership::join::backup_restore::consumed_child_join_survives_isolated_backup_restore`.
It is separately recorded as `actual_exact_case`; the Native build summary's
original COMMIT-loss selected case is retained only as build provenance. The
test environment includes mandatory PostgreSQL and backup-restore flags, its
fresh base URL, and `STATEKNOT_TEST_POSTGRES_CONTAINER` set to the exact inspected
container ID. The two mandatory profile flags are1; no PITR environment is set.

The original600-second observation watchdog and1 test thread remain. Actual
test exit/raw digests are saved before source/binary/container/durability/df/cache
observations. Successful qualification requires the exact libtest start,
one strict13-field marker, independent `ok`, 1 passed/193 filtered, real server
major, positive bounded archive size, exact archive digest, isolated source and
restore, schema and durable snapshot checks, cross-tenant refusal and noninitial
replay. This existing consumed-Join restore seam gives no owner-stop-specific
restore, scoped Driver, complete CI or R1 qualification.

After both actual backup receipts are terminal, Root can add their paths/hashes
to a new six-row PITR prerequisite manifest and run PITR16 then17 serially.
