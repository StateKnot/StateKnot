#!/usr/bin/env python3
"""Run existing Runtime194 mandatory logical backup/restore, after full Native terminal receipts."""
import argparse
import hashlib
import json
import os
import re
import signal
import subprocess
import threading
import time
from pathlib import Path
import importlib.util

# Reuse the exact previously executed build helper; do not copy or mutate it.
BUILD_HELPER = Path(__file__).resolve().parent / 'build.py'
assert hashlib.sha256(BUILD_HELPER.read_bytes()).hexdigest() == '3412d08c7a0fdcb6df4ad24f0553aeaea0c92ccb2e4757e6afa67c23e48fd067'
_spec = importlib.util.spec_from_file_location('singlewalk_native_build', BUILD_HELPER)
shared = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(shared)

MAJORS = {
    16: ('stateknot-r1-oct15-pg16', 'cd3def02c3d0888a0d3cf2d73ab6400ce02e80c65d961f7a5186a2017b0fa7ea',
         'sha256:a3b7f434b2dc57ce85a67e171163eb8ab1a1ebcb39d27484661f26b1dfbe30d6', 55416),
    17: ('stateknot-r1-oct15-pg17', '700ced678f1efb67e230785eb4d42d77c0327e64d032f6fd12ed386e46f43127',
         'sha256:f4c66b820c6f974249089d3d16d86a3698eae11e8746eb6644b2271031e91232', 55417),
}
FMT = '{"id":{{json .Id}},"image":{{json .Image}},"labels":{{json .Config.Labels}},"ports":{{json .NetworkSettings.Ports}},"running":{{json .State.Running}}}'
SETTINGS = "SELECT json_build_object('version',version(),'server_version_num',current_setting('server_version_num'),'fsync',current_setting('fsync'),'synchronous_commit',current_setting('synchronous_commit'),'full_page_writes',current_setting('full_page_writes'),'shared_buffers',current_setting('shared_buffers'),'max_connections',current_setting('max_connections'));"
# Existing public CI fixture value. Never print it or the complete URL.
FIXTURE_PASSWORD = 'stateknot_test_password'


BACKUP_CASE = 'child_admission::ownership::join::backup_restore::consumed_child_join_survives_isolated_backup_restore'
SOURCE_SHA = 'e8f3b8a1c93cbbd8ad00fa3622657be032a98fc775ea9580337c27c1d8ad77db'
COMPILED_SHA = 'acc2f7706a60201874a2dec4de5c690fcee4bf7a04409822bf409f72ca7f1c16'
BINARY_SHA = '6f633c5883ccdba9308d7ba408c044653ec4c3a95c9a3c27469ae15e0dda4e7e'


def full_native_prerequisites(path):
    data = shared.obj(path)
    assert data['source_tree_sha256'] == SOURCE_SHA and data['compiled_inputs_sha256'] == COMPILED_SHA
    rows = data['full_native_runs']
    assert len(rows) == 4 and {(r['major'], r['package']) for r in rows} == {
        (major, package) for major in (16, 17) for package in ('store', 'runtime')}
    observed = []
    for row in rows:
        receipt_path = Path(row['test_receipt']).resolve()
        assert receipt_path.is_relative_to(Path(__file__).resolve().parent.parent)
        assert shared.sha(receipt_path) == row['receipt_sha256']
        receipt = shared.obj(receipt_path)
        assert type(receipt.get('exit_code')) is int, 'full Native prerequisite not terminal'
        assert receipt['source_tree'] == SOURCE_SHA and receipt['compiled_inputs_sha256'] == COMPILED_SHA
        assert receipt['database']['port'] == (55416 if row['major'] == 16 else 55417)
        assert receipt['full_inventory_count'] == (267 if row['package'] == 'store' else 194)
        assert receipt['expected_filtered'] == 0
        assert receipt['argv'][1:] == ['--test-threads=1', '--nocapture']
        observed.append({'major': row['major'], 'package': row['package'],
            'test_receipt': str(receipt_path), 'receipt_sha256': row['receipt_sha256'],
            'actual_exit_code': receipt['exit_code'], 'terminal': True})
    return observed


def backup_selected_green(output, case, major):
    marker = 'STATEKNOT_CHILD_JOIN_BACKUP_RESTORE_EVIDENCE='
    try:
        text = output.decode('utf-8')
        prefix = '\nrunning 1 test\ntest ' + case + ' ... \n' + marker
        if text.count(marker) != 1 or not text.startswith(prefix):
            return False
        line, newline, tail = text[len(prefix):].partition('\n')
        if not newline or re.fullmatch(r'ok\n\ntest result: ok\. 1 passed; 0 failed; 0 ignored; 0 measured; 193 filtered out; finished in [0-9]+(?:\.[0-9]+)?s\n\n', tail) is None:
            return False

        def unique_object(pairs):
            result = {}
            for key, value in pairs:
                if key in result:
                    raise ValueError('duplicate backup marker key')
                result[key] = value
            return result

        def invalid_constant(value):
            raise ValueError('non-finite backup marker')

        value = json.loads(line, object_pairs_hook=unique_object, parse_constant=invalid_constant)
        fixed = {'profile': 'child-join-logical-restore-v1', 'source_isolated': True,
            'restore_isolated': True, 'schema_verified': True,
            'exact_durable_snapshot_verified': True, 'cross_tenant_refusal_verified': True,
            'noninitial_replay_verified': True, 'invariants': 'passed',
            'os': 'macos', 'arch': 'aarch64'}
        if type(value) is not dict or set(value) != set(fixed) | {'archive_sha256', 'archive_bytes', 'postgres'} or len(value) != 13:
            return False
        for key, expected in fixed.items():
            if type(value[key]) is not type(expected) or value[key] != expected:
                return False
        return (type(value['archive_sha256']) is str and
                re.fullmatch(r'sha256:[0-9a-f]{64}', value['archive_sha256']) is not None and
                type(value['archive_bytes']) is int and 0 < value['archive_bytes'] < 100 * 1024 * 1024 and
                type(value['postgres']) is str and re.fullmatch(
                    str(major) + r'\.[0-9]+(?:\.[0-9]+)?(?: \([^\r\n]+\))?', value['postgres']) is not None)
    except (UnicodeError, ValueError, TypeError, KeyError):
        return False


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--build-dir', type=Path, required=True)
    p.add_argument('--major', type=int, choices=MAJORS, required=True)
    p.add_argument('--leg', choices=('B',), default='B')
    p.add_argument('--prerequisites', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    a = p.parse_args()
    out = a.out.resolve(); out.mkdir(parents=True, exist_ok=False)
    build_dir = a.build_dir.resolve(); summary = shared.obj(build_dir / 'build-summary.json')
    receipt = shared.obj(build_dir / 'build.receipt.json')
    assert shared.sha(build_dir / 'build.receipt.json') == summary['build_receipt_sha256']
    assert receipt['exit_code'] == 0 and receipt['source_before_after_exact'] is True
    package = 'runtime'
    prerequisite_facts = full_native_prerequisites(a.prerequisites)
    assert summary['package'] == package and summary['role'] == 'candidate'
    assert summary['source_tree'] == SOURCE_SHA and summary['compiled_inputs_sha256'] == COMPILED_SHA
    source = Path(summary['source'])
    m, ci = shared.check_source(source, Path(summary['source_manifest']), Path(summary['compiled_inputs']))
    assert shared.sha(summary['source_manifest']) == receipt['source_manifest_sha256']
    assert shared.sha(summary['compiled_inputs']) == receipt['compiled_manifest_sha256']
    assert m['source_tree_sha256'] == summary['source_tree'] and ci['sha256'] == summary['compiled_inputs_sha256']
    binary = Path(summary['saved_executable'])
    assert binary.resolve().is_relative_to(build_dir / 'binaries') and not binary.is_symlink()
    assert shared.sha(binary) == summary['binary_sha256'] == BINARY_SHA
    env = shared.common_env()
    assert shared.env_allowlist(env) == receipt['environment_allowlist']
    shared.disk(out, 'before')
    for artifact in summary['selected_artifacts_all_fresh_false']:
        profile = artifact['profile']
        assert artifact['fresh'] is False and artifact['features'] == []
        assert profile['opt_level'] == '1' and profile['debuginfo'] == 0
        assert profile['debug_assertions'] is True and profile['overflow_checks'] is True
    assert len(summary['selected_artifacts_all_fresh_false']) == 4

    def command(label, argv, db_env=None):
        started = time.time()
        r = subprocess.run(argv, cwd=source, env=db_env or env, capture_output=True, timeout=30)
        # These inventory/inspect/local-psql commands contain no URL/password.
        assert FIXTURE_PASSWORD.encode() not in r.stdout + r.stderr
        (out / (label + '.stdout')).write_bytes(r.stdout)
        (out / (label + '.stderr')).write_bytes(r.stderr)
        shared.write(out, label + '.receipt.json', {'argv': argv, 'start_unix': started,
            'seconds': time.time() - started, 'exit_code': r.returncode,
            'stdout_sha256': shared.sha(out / (label + '.stdout')),
            'stderr_sha256': shared.sha(out / (label + '.stderr'))})
        assert r.returncode == 0, (label, r.returncode)
        return r.stdout

    name, identity, image, port = MAJORS[a.major]
    observed = json.loads(command('container-before', ['docker', 'inspect', '--format', FMT, name]))
    assert observed['id'] == identity and observed['image'] == image and observed['running'] is True
    assert observed['labels']['stateknot.task'] == 'r1-oct15'
    assert observed['ports']['5432/tcp'] == [{'HostIp': '127.0.0.1', 'HostPort': str(port)}]
    database = 'stateknot_r1_joincomposedbackup_20261018_pg' + str(a.major) + '_' + package + '_' + a.leg.lower()
    assert re.fullmatch('[a-z0-9_]{1,63}', database)

    def sql(label, text, db='postgres'):
        return command(label, ['docker', 'exec', name, 'psql', '-X', '-v', 'ON_ERROR_STOP=1',
                               '-U', 'postgres', '-d', db, '-At', '-c', text])

    server_settings = json.loads(sql('server-settings-before', SETTINGS))
    assert int(server_settings['server_version_num']) // 10000 == a.major
    assert all(server_settings[k] == 'on' for k in ('fsync', 'synchronous_commit', 'full_page_writes'))
    assert sql('database-absent', "SELECT count(*) FROM pg_database WHERE datname='" + database + "';").strip() == b'0'
    command('create-database', ['docker', 'exec', name, 'createdb', '-U', 'postgres',
                               '--template=template0', '--encoding=UTF8', database])
    assert sql('database-created', 'SELECT current_database();', database).strip() == database.encode()
    db_settings = json.loads(sql('database-settings-before', SETTINGS, database))
    assert all(db_settings[k] == 'on' for k in ('fsync', 'synchronous_commit', 'full_page_writes'))
    _, expected_count, original_build_case = shared.CASES[package]
    case = BACKUP_CASE
    assert expected_count == 194
    inventory = command('full-inventory', [str(binary), '--list'])
    names = re.findall(rb'^([^\n]+): test$', inventory, re.M)
    assert len(names) == len(set(names)) == expected_count and case.encode() in names
    assert expected_count == summary['inventory_count'] and original_build_case == summary['exact_case']
    assert original_build_case.encode() in names
    env.update(STATEKNOT_REQUIRE_POSTGRES_TESTS='1',
               STATEKNOT_REQUIRE_BACKUP_RESTORE_TESTS='1', STATEKNOT_TEST_POSTGRES_CONTAINER=identity,
               STATEKNOT_TEST_DATABASE_URL='postgres://postgres:' + FIXTURE_PASSWORD + '@127.0.0.1:' + str(port) + '/' + database)
    assert {k for k in env if k.startswith('STATEKNOT_')} == {
        'STATEKNOT_REQUIRE_POSTGRES_TESTS', 'STATEKNOT_REQUIRE_BACKUP_RESTORE_TESTS',
        'STATEKNOT_TEST_POSTGRES_CONTAINER', 'STATEKNOT_TEST_DATABASE_URL'}
    argv = [str(binary), case, '--exact', '--test-threads=1', '--nocapture']
    started = time.time(); timed_out = False; streams = {}

    def capture(pipe, label):
        raw_hash = hashlib.sha256(); redactions = 0
        with (out / label).open('wb') as saved:
            for line in iter(pipe.readline, b''):
                raw_hash.update(line); redactions += line.count(FIXTURE_PASSWORD.encode())
                saved.write(line.replace(FIXTURE_PASSWORD.encode(), b'[REDACTED_PUBLIC_FIXTURE_PASSWORD]'))
        pipe.close()
        streams[label] = {'raw_sha256': raw_hash.hexdigest(), 'redactions': redactions,
                          'saved_sha256': shared.sha(out / label), 'saved_is_raw': redactions == 0}

    process = subprocess.Popen(argv, cwd=source, env=env, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, start_new_session=True)
    running = {'argv': argv, 'cwd': str(source), 'pid': process.pid, 'runner_pid': os.getpid(),
               'start_unix': started, 'runner_sha256': shared.sha(__file__),
               'shared_build_module_sha256': shared.sha(Path(shared.__file__)),
               'role': summary['role'], 'leg': a.leg, 'case': 'backup_restore_exact',
               'actual_exact_case': case, 'profile': 'mandatory-child-join-logical-restore',
               'original_binary_build_exact_case': original_build_case,
               'mandatory_backup_restore_env_present': True, 'actual_postgres_container_id': identity,
               'full_native_prerequisite_facts': prerequisite_facts,
               'prerequisites_manifest_sha256': shared.sha(a.prerequisites),
               'source_tree': summary['source_tree'], 'compiled_inputs_sha256': summary['compiled_inputs_sha256'],
               'binary_sha256': shared.sha(binary), 'profile_build_receipt_sha256': shared.sha(build_dir / 'build.receipt.json'),
               'environment_allowlist': shared.env_allowlist(env), 'mandatory_database_env_present': True,
               'overrides_present': {k: k in env for k in shared.OVERRIDES},
               'database': {'container_id': identity, 'image_id': image, 'port': port, 'name': database,
                            'URL_credentials_not_logged': True},
               'full_inventory_count': expected_count, 'expected_filtered': expected_count - 1,
               'external_observation_watchdog_seconds': 600, 'original_business_budgets_unchanged': True,
               'expected_future_contract_green': True}
    shared.write(out, 'running.json', running); print(json.dumps(running), flush=True)
    threads = [threading.Thread(target=capture, args=(process.stdout, 'test.stdout')),
               threading.Thread(target=capture, args=(process.stderr, 'test.stderr'))]
    for t in threads:
        t.start()
    try:
        code = process.wait(timeout=600)
    except subprocess.TimeoutExpired:
        timed_out = True; os.killpg(process.pid, signal.SIGTERM)
        try:
            code = process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL); code = process.wait()
    seconds = time.time() - started
    for t in threads:
        t.join()
    assert set(streams) == {'test.stdout', 'test.stderr'}, 'output capture failed'
    test_receipt = {**running, 'exit_code': code, 'seconds': seconds, 'timed_out': timed_out,
                    'output_streams': streams, 'database_preserved_no_cleanup': True}
    shared.write(out, 'test.receipt.json', test_receipt)
    print(json.dumps(test_receipt), flush=True)
    # Save actual process outcome first; a later observation failure never
    # overwrites it or becomes a fabricated product/test failure.
    after_m, after_ci = shared.check_source(source, Path(summary['source_manifest']), Path(summary['compiled_inputs']))
    assert after_m == m and after_ci == ci and shared.sha(binary) == summary['binary_sha256']
    observed_after = json.loads(command('container-after', ['docker', 'inspect', '--format', FMT, name]))
    settings_after = json.loads(sql('database-settings-after', SETTINGS, database))
    server_after = json.loads(sql('server-settings-after', SETTINGS))
    assert observed_after == observed and settings_after == db_settings and server_after == server_settings
    shared.disk(out, 'after')
    output = (out / 'test.stdout').read_bytes()
    error = (out / 'test.stderr').read_bytes()
    matches = re.findall(rb'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', output, re.M)
    expected = [(b'1', b'0', b'0', b'0', str(expected_count - 1).encode())]
    selected = backup_selected_green(output, case, a.major)
    ok = code == 0 and not timed_out and matches == expected and selected
    shared.write(out, 'observations.json', {'mandatory_logical_backup_restore_passed': ok, 'actual_exact_case': case,
        'profile': 'mandatory-child-join-logical-restore',
        'actual_test_exit_code': code, 'source_and_binary_before_after_exact': True,
        'container_and_durability_settings_unchanged': True, 'libtest_summary': [list(map(int, x)) for x in matches],
        'test_receipt_sha256': shared.sha(out / 'test.receipt.json'),
        'selected_consumed_Join_backup_restore_verified': ok,
        'owner_stop_specific_restore_Driver_full_CI_or_R1_qualification': False})
    assert ok, 'mandatory exact logical restore did not qualify; actual original outcome retained'


if __name__ == '__main__':
    main()
