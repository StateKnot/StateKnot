import hashlib,json,subprocess,time
from pathlib import Path
base=Path(__file__).resolve().parent.parent
out=base/'discovery-v1';out.mkdir(exist_ok=False)
argv=['gh','api','--method','GET','repos/StateKnot/StateKnot/actions/workflows/344469785/runs?branch=codex%2Fci-native-compile-lane-20261018-v3&event=workflow_dispatch&per_page=100']
start=time.time();r=subprocess.run(argv,capture_output=True,timeout=50)
(out/'runs.stdout').write_bytes(r.stdout);(out/'runs.stderr').write_bytes(r.stderr)
(out/'receipt.json').write_text(json.dumps({'argv':argv,'actual_exit_code':r.returncode,'seconds':time.time()-start,'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest(),'read_only':True},indent=2)+'\n')
assert r.returncode==0
runs=json.loads(r.stdout);assert runs['total_count']==len(runs['workflow_runs'])==1
row=runs['workflow_runs'][0];assert row['head_sha']=='dc13238b766eef98783f05cabb896e840a723be6' and row['head_branch']=='codex/ci-native-compile-lane-20261018-v3' and row['event']=='workflow_dispatch' and row['run_attempt']==1 and row['workflow_id']==344469785
small={k:row[k] for k in ('id','head_sha','head_branch','status','conclusion','created_at','html_url','run_attempt','event','workflow_id')};(out/'run.json').write_text(json.dumps(small,indent=2)+'\n');print(json.dumps(small))
