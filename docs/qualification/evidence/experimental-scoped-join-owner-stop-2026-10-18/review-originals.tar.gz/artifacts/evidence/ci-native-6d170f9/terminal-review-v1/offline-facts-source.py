#!/usr/bin/env python3
"""Extract bounded observed facts without applying milestone qualification rules."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import shutil

BASE = Path(__file__).resolve().parent.parent
DATA = BASE / 'terminal-or-progress-v5'
OUT = BASE / 'terminal-review-v1'
sha = lambda b: hashlib.sha256(b).hexdigest()
obj = lambda p: json.loads(p.read_bytes())

def small_file(folder, name):
    p = folder / name
    return p.read_text() if p.is_file() else None

def main():
    OUT.mkdir(exist_ok=False)
    shutil.copyfile(__file__, OUT / 'offline-facts-source.py')
    manifest = obj(DATA / 'files.json')
    bad = []
    for row in manifest['files']:
        p = DATA / row['path']
        if not p.is_file() or (p.stat().st_size, sha(p.read_bytes())) != (row['bytes'], row['sha256']):
            bad.append(row['path'])
    run = obj(DATA / 'run.stdout')
    jobs = obj(DATA / 'all-jobs.json')['jobs']
    artifacts = obj(DATA / 'all-artifacts.json')['artifacts']
    api_receipts = [obj(p) for p in sorted(DATA.rglob('*.receipt.json')) if 'argv' in obj(p)]
    archive_checks = []
    native = []
    markers = []
    for artifact in artifacts:
        manifest_path = DATA / 'artifact-files' / (str(artifact['id']) + '.json')
        archive = DATA / 'archives' / (str(artifact['id']) + '.zip')
        item = obj(manifest_path)
        folder = DATA / item['directory']
        archive_checks.append({'artifact_id': artifact['id'], 'name': artifact['name'],
            'api_digest': artifact.get('digest'), 'archive_sha256': sha(archive.read_bytes()),
            'api_digest_matches_archive': artifact.get('digest') == 'sha256:' + sha(archive.read_bytes()),
            'files': [r['path'] for r in item['files']]})
        for row in item['files']:
            p = folder / row['path']
            for number, line in enumerate(p.read_text(errors='replace').splitlines(), 1):
                m = re.fullmatch(r'(STATEKNOT_(?:FRAME_RETURN|SCOPED_WAIT)_COMMIT_LOSS_EVIDENCE=)(\{.*\})', line)
                if m:
                    markers.append({'artifact_id': artifact['id'], 'name': artifact['name'],
                        'file': p.relative_to(DATA).as_posix(), 'line': number,
                        'prefix': m[1], 'value': json.loads(m[2])})
        if artifact['name'].startswith('postgres-native-parallel-'):
            row = {'artifact_id': artifact['id'], 'name': artifact['name'], 'directory': item['directory']}
            for name in ('suite-exits.tsv', 'leader-exits.tsv', 'cleanup.tsv', 'retired.tsv',
                         'retire-requests.tsv', 'pair-started.txt', 'pair-completed.txt'):
                row[name] = small_file(folder, name)
            overlap = obj(folder / 'native-binary-overlap.json')
            row['binary_overlap'] = {'both_actual_binary_processes_alive': overlap.get('both_actual_binary_processes_alive'),
                                    'observed_unix_ns': overlap.get('observed_unix_ns')}
            row['roles'] = {}
            for role in ('store', 'runtime'):
                execution = obj(folder / (role + '-execution.json'))
                build = obj(folder / (role + '-build-exit.json'))
                text = (folder / (role + '.stdout')).read_text()
                owner = folder / (role + '-owner')
                row['roles'][role] = {
                    'inventory_starts': re.findall(r'^running [0-9]+ tests$', text, re.M),
                    'harness_summaries': re.findall(r'^test result: .*$', text, re.M),
                    'build_process_exit_code': build.get('build_process_exit_code'),
                    'build_seconds': build.get('seconds'),
                    'execution': {k: execution.get(k) for k in ('argv', 'binary', 'binary_sha256', 'cwd', 'pid', 'start_ticks', 'started_unix_ns')},
                    'suite_status': small_file(owner, 'suite-status'),
                    'helper_wait_status': small_file(owner, 'helper-wait-status'),
                    'cleanup_reason': small_file(owner, 'cleanup-reason'),
                    'leader_identity': small_file(owner, 'leader-identity'),
                    'cleanup_complete': small_file(owner, 'cleanup-complete'),
                }
            native.append(row)
    annotation_failures = []
    for p in sorted(DATA.glob('annotations-*-page-*.stdout')):
        for row in obj(p):
            if row.get('annotation_level') == 'failure':
                annotation_failures.append({'source': p.name, 'message': row.get('message')})
    pg_steps = []
    for job in jobs:
        if job['name'] in ('PostgreSQL (16)', 'PostgreSQL (17)'):
            pg_steps.append({'id': job['id'], 'name': job['name'], 'conclusion': job['conclusion'],
                'counts': dict(Counter(s['conclusion'] for s in job['steps'])),
                'steps': [{k: s.get(k) for k in ('number', 'name', 'status', 'conclusion', 'started_at', 'completed_at')} for s in job['steps']]})
    report = {
        'source_directory': str(DATA), 'source_manifest_sha256': sha((DATA / 'files.json').read_bytes()),
        'integrity': {'manifest_files': len(manifest['files']), 'manifest_mismatches': bad,
            'collection_receipt': obj(DATA / 'collection.receipt.json'),
            'gh_receipts': len(api_receipts),
            'gh_nonzero_receipts': [r for r in api_receipts if r['actual_exit_code'] != 0],
            'gh_non_GET_receipts': [r for r in api_receipts if r['argv'][:7] != ['gh', 'api', '--hostname', 'github.com', '--method', 'GET', r['argv'][6]]],
            'job_logs': len(list(DATA.glob('job-*-log.log'))),
            'annotation_pages': len(list(DATA.glob('annotations-*-page-*.stdout'))),
            'archive_count': len(archive_checks),
            'archive_digest_mismatches': [a['artifact_id'] for a in archive_checks if not a['api_digest_matches_archive']]},
        'run': {k: run[k] for k in ('id', 'head_sha', 'head_branch', 'workflow_id', 'run_attempt', 'event', 'created_at', 'status', 'conclusion')},
        'job_conclusions': dict(Counter(j['conclusion'] for j in jobs)),
        'postgres_steps': pg_steps, 'native_observed_facts': native,
        'return_wait_artifact_markers': markers, 'annotation_failures': annotation_failures,
        'artifacts': archive_checks,
        'full_CI_or_milestone_qualification_awarded': False,
    }
    raw = (json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode()
    (OUT / 'facts.json').write_bytes(raw)
    (OUT / 'facts.sha256').write_text(sha(raw) + '  facts.json\n')
    print(json.dumps({'output': str(OUT / 'facts.json'), 'integrity': report['integrity'],
          'job_conclusions': report['job_conclusions'],
          'native': [{'name': n['name'], 'suite_exits': n['suite-exits.tsv'],
                      'harness': {k: v['harness_summaries'] for k, v in n['roles'].items()}}
                     for n in native],
          'return_wait_marker_count': len(markers)}, ensure_ascii=False))

if __name__ == '__main__':
    main()
