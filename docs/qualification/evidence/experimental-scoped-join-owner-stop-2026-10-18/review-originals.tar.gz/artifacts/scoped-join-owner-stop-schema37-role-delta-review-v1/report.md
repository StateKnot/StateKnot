# Current role-profile schema pin: independent delta review

The exact current-schema expectation at
`crates/stateknot-runtime/tests/postgres/role_profile.rs:1052` must change from36
to37. `Fixture::create` runs the full public Store Migrator; its included role
profile already requires exactly successful migrations1..37/count37 and the
unchanged54-table inventory. The earlier LOGIN, privilege rejection, drift,
durable-work and populated reapply assertions remain necessary. The later Store
close, fixture cleanup and evidence marker must still execute before a passing
role qualification can be claimed.

Composed-v3 changes exactly that one assertion. All other935 source files are
byte-identical to v2, and the role module equals v2 after this single literal
replacement. No ACL, table allowlist, principal, business assertion, negative
test, reapply, cleanup, marker or deadline changes accompany it.

The scan covered all544 exact compiled inputs. The only migration-current36
assertion found is this role-profile pin. Other36 occurrences are UUID lengths,
unrelated limits/costs, immutable migration0036 and historical schema-reconstruction
reverts; these must retain their original values. In particular, retained-v1
schema36 source fixtures and their36→37 migration evidence must not be relabeled.

This corrects a real full-Native failure. The original v2 runs, actual failure
and unexecuted cleanup/marker remain preserved. Executing earlier LOGIN/ACL
checks does not make the failed whole role test pass. The v3 source, new binary
and subsequent executions require separate real qualification; this read-only
review runs no build, test, database, Docker or network operation.

V3 source936: `21c32c1446377a9691d63d835bb732b8d8cc6259e236c9cd0575dc13369f7a44`.
Compiled544: `30d6c10fd88118297131a28c0e3b78420f51dec17206a718948a348c7424de81`.
Role module: `7944f7e94e56bee736ee9d32c40cf66d19b7119bac30d9cb4514caa3097c9fc7`.
