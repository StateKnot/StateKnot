#!/usr/bin/env python3
"""Strictly offline final 21-job CI analysis. Does not execute any evidence code."""
import sys
sys.dont_write_bytecode = True
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import re
import stat
import zipfile
from common import canonical, decode, gitblob, inside, load, require, saved_get, sha, unique, reject, rows_by_path, verify_index, publication_payloads, verify_full_publication

HERE = Path(__file__).resolve().parent
WORKSPACE = '/home/runner/work/StateKnot/StateKnot'
PROFILE = {'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_DEV_DEBUG': '0',
           'CARGO_PROFILE_TEST_DEBUG': '0', 'CARGO_PROFILE_TEST_OPT_LEVEL': '1',
           'CARGO_PROFILE_TEST_DEBUG_ASSERTIONS': 'true', 'CARGO_PROFILE_TEST_OVERFLOW_CHECKS': 'true',
           'STATEKNOT_REQUIRE_POSTGRES_TESTS': '1'}
SUMMARY = re.compile(r'^test result: ok[.] (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in ([0-9.]+)s$', re.M)
IGNORED_FIXTURE_CONTRACT_SHA256 = '8f922997b97ad373b0d59a590935437c54abd030938ba922dabcdcd7dd7c4f3e'


def verify_ignored_fixture_contracts(base, binding, contracts):
    raw = inside(base, 'inputs/ignored-fixture-harnesses.json').read_bytes()
    require(sha(raw) == IGNORED_FIXTURE_CONTRACT_SHA256, 'frozen three original subprocess fixture contracts changed')
    data = decode(raw)
    require(data['schema'] == 'stateknot-original-subprocess-fixture-harness-contracts-v1' and data['source_tree_sha256'] == binding['source_936_sha256'] and data['compiled_canonical_sha256'] == binding['compiled_canonical_sha256'], 'subprocess contracts selected source binding')
    rows = data['harnesses']
    require(data['count'] == len(rows) == 3 and {r['label'] for r in rows} == {'mcp-compute-worker-qualification.log', 'agent-worker-qualification.log', 'agent-http-qualification.log'}, 'only three exact original ignored-fixture harness labels')
    compiled = {r['path']: r for r in binding['compiled_files']}
    for row in rows:
        source = row['source']
        require(source == compiled[source['path']], 'ignored-fixture source is not the exact compiled V3 input')
        source_raw = inside(base / 'inputs/ignored-fixture-sources', source['path']).read_bytes()
        require((len(source_raw), sha(source_raw)) == (source['bytes'], source['sha256']), 'ignored-fixture original source bytes changed')
        source_text = source_raw.decode('utf-8', errors='strict')
        require(all(fragment in source_text for fragment in row['source_proof_fragments']), 'original explicit ignore/parent exact subprocess launch/evidence checks absent')
        require(row['exact_ignored_line'] == 'test ' + row['ignored_case'] + ' ... ignored, ' + row['ignored_reason'], 'exact ignored fixture line contract')
        required = row['required_original_marker_prefixes']
        available = {s['prefix'] for s in contracts['markers'] if s['job'] == row['job'] and s['log'] == row['label']}
        require(required and set(required) <= available, 'original parent evidence marker contracts missing')
    return {r['label']: r for r in rows}


def tsv(path, width=2):
    rows = [line.split('\t') for line in path.read_text().splitlines()]
    require(all(len(row) == width for row in rows), 'TSV shape: ' + path.name)
    return rows


def pair_map(path):
    rows = tsv(path)
    require(len({r[0] for r in rows}) == len(rows), 'duplicate role: ' + path.name)
    return dict(rows)


def exact_summary(raw, passed, filtered=0):
    text = raw.decode('utf-8', errors='strict')
    summaries = SUMMARY.findall(text)
    require(len(summaries) == 1 and summaries[0][:5] == (str(passed), '0', '0', '0', str(filtered)), 'missing/repeated/inexact complete harness summary')
    require(text.splitlines().count('running ' + str(passed) + (' test' if passed == 1 else ' tests')) == 1, 'exact running count absent/repeated')
    return float(summaries[0][5])


def verify_bundle(base):
    index = verify_index(base, 'manifest.json')
    binding = load(base / 'binding.json')
    require(binding['schema'] == 'stateknot-ci-postgres-shards-binding-v1' and binding['prepare_only'] is True, 'invalid prepared binding schema')
    require(binding['branch'] == 'codex/ci-postgres-shards-20261019-v1' and binding['parent'] == 'e372184fb1c80ffb9903ac0d9feb8380db51253e', 'wrong publication branch/parent')
    official = load(base / 'inputs/official.json')['official']
    api, head, tree = binding['api'], binding['head_sha'], binding['tree']
    run, _ = saved_get(base, official['run'], api + '/actions/runs/' + str(binding['run_id']))
    stable = ('id', 'head_sha', 'head_branch', 'workflow_id', 'run_attempt', 'event', 'created_at')
    expected = tuple(binding[k] for k in ('run_id', 'head_sha', 'branch', 'workflow_id', 'run_attempt', 'event', 'created_at'))
    require(tuple(run[k] for k in stable) == expected, 'frozen official run identity')
    commit, _ = saved_get(base, official['commit'], api + '/git/commits/' + head)
    require(commit['sha'] == head and commit['tree']['sha'] == tree and [p['sha'] for p in commit['parents']] == [binding['parent']], 'frozen official commit')
    ref, _ = saved_get(base, official['ref'], api + '/git/ref/heads/' + binding['branch'])
    require(ref['ref'] == 'refs/heads/' + binding['branch'] and ref['object']['sha'] == head, 'frozen official ref')
    compare, _ = saved_get(base, official['compare'], api + '/compare/' + binding['parent'] + '...' + head)
    require(compare['base_commit']['sha'] == compare['merge_base_commit']['sha'] == binding['parent'] and compare['total_commits'] == 1 and [r['sha'] for r in compare['commits']] == [head], 'frozen official compare')
    finaltree, _ = saved_get(base, official['tree'], api + '/git/trees/' + tree + '?recursive=1')
    require(finaltree['sha'] == tree and finaltree['truncated'] is False, 'complete official recursive final tree')
    prepared, publication_manifest, payloads = publication_payloads(base / 'inputs', binding)
    parenttree, _ = saved_get(base, official['parent_tree'], api + '/git/trees/' + prepared['parent_tree'] + '?recursive=1')
    finalentries, blobs, parentblobs = verify_full_publication(finaltree, parenttree, compare, payloads, prepared['parent_tree'])
    require(binding['publication_payload_files'] == payloads and binding['publication_payload_count'] == 38 and binding['publication_manifest_sha256'] == prepared['input_manifest_sha256'], 'frozen exact38 publication bytes')
    require(binding['complete_official_tree_entries'] == [finalentries[p] for p in sorted(finalentries)] and binding['complete_official_blob_count'] == len(blobs) == 4088 and binding['complete_official_tree_entry_count'] == len(finalentries), 'all4088 full official blob/tree entries changed')
    require(binding['official_parent_tree'] == parenttree['sha'] and binding['all_other_official_blobs_unchanged_from_parent'] is True, 'complete unchanged parent scope')
    expected_files = binding['expected_files']
    require(len(expected_files) == len({r['path'] for r in expected_files}) == binding['selected_with_CI_byte_verified_count'] == 940 and binding['selected_pre_CI_source_count'] == 936, '936 selected source plus four added CI helper byte inventory')
    for row in expected_files:
        officialrow = blobs[row['path']]
        require((officialrow['sha'], officialrow['size'], officialrow['mode']) == (row['blob_sha1'], row['bytes'], row['git_mode']), 'selected source/CI official blob identity')
    source = load(base / 'inputs/source-manifest.json')
    compiled = load(base / 'inputs/compiled-inputs.json')
    require(source['count'] == len(source['files']) == 936 and source['source_tree_sha256'] == sha(canonical(source['files'])) == binding['source_936_sha256'] == '21c32c1446377a9691d63d835bb732b8d8cc6259e236c9cd0575dc13369f7a44', 'frozen V3 source936')
    require(compiled['count'] == len(compiled['files']) == 544 and compiled['sha256'] == sha(canonical(compiled['files'])) == binding['compiled_canonical_sha256'] == '30d6c10fd88118297131a28c0e3b78420f51dec17206a718948a348c7424de81', 'frozen V3 compiled544')
    require(compiled['files'] == binding['compiled_files'] and sha(json.dumps(compiled['files'], sort_keys=True).encode()) == binding['native_source_manifest_sha256'], 'native source JSON-format digest')
    finalrows = {r['path']: r for r in expected_files}
    cifiles = load(base / 'inputs/candidate-manifest.json')['candidate_files']
    require(cifiles == binding['ci_files'] and len(cifiles) == 5, 'exact five frozen CI payloads')
    for row in source['files']:
        final = finalrows[row['path']]
        if row['path'] not in {r['path'] for r in cifiles}:
            require((row['bytes'], row['sha256']) == (final['bytes'], final['sha256']), 'final tree changed frozen V3 source')
    for row in cifiles:
        data = inside(base / 'inputs/payload', row['path']).read_bytes()
        require((len(data), sha(data)) == (row['bytes'], row['sha256']) and gitblob(data) == finalrows[row['path']]['blob_sha1'], 'five CI bytes/official blob binding')
    for row in compiled['files']:
        require((row['bytes'], row['sha256']) == (finalrows[row['path']]['bytes'], finalrows[row['path']]['sha256']), 'final compiled source changed')
    mapping = load(base / 'inputs/workflow-step-map.json')['mapping']
    require(len(mapping) == 60 and [r['source_index'] for r in mapping] == list(range(1, 61)), 'all60 workflow mappings required')
    contracts = load(base / 'inputs/contracts.json')
    require(sum(len(j['names']) for j in contracts['jobs'].values()) == 21, 'contract21 job inventory')
    contracts['ignored_fixture_harnesses'] = verify_ignored_fixture_contracts(base, binding, contracts)
    return binding, contracts, mapping, {'bundle_manifest_sha256': sha((base / 'manifest.json').read_bytes()), 'files': index['count'], 'exact_selected936_source_and_544_compiled_and_five_CI': True, 'all4088_official_blobs_and_exact38_publication_payloads': True}


def verify_collection(raw, binding, contracts, bundle_facts):
    index = verify_index(raw)
    collection = load(raw / 'collection.receipt.json')
    require(collection['collection_complete'] is True and collection['terminal'] is True and collection['errors'] == [] and collection['read_only'] is True, 'incomplete/nonterminal collection')
    reference = load(raw / 'binding-reference.json')
    require(reference['bundle_manifest_sha256'] == bundle_facts['bundle_manifest_sha256'] and (reference['run_id'], reference['head_sha']) == (binding['run_id'], binding['head_sha']), 'collector bundle binding')
    api, runid, head = binding['api'], binding['run_id'], binding['head_sha']
    receipts = {}
    for path in sorted(raw.rglob('*.receipt.json')):
        if path.parent not in (raw, raw / 'archives') or path.name == 'collection.receipt.json':
            continue
        receipt = load(path)
        require(receipt['read_only'] is True, 'non-read-only collection receipt')
        relative = path.relative_to(raw).as_posix().removesuffix('.receipt.json')
        require(relative not in receipts, 'duplicate receipt label')
        _, endpoint = saved_get(raw, {'stdout': receipt['stdout_path'], 'receipt': path.relative_to(raw).as_posix(), 'stderr': relative + '.stderr'}) if receipt['stdout_path'].endswith('.stdout') else (None, receipt['argv'][6])
        if not receipt['stdout_path'].endswith('.stdout'):
            argv = receipt['argv']
            require(len(argv) == 7 and argv[:6] == ['gh', 'api', '--hostname', 'github.com', '--method', 'GET'] and receipt['actual_exit_code'] == 0, 'log/archive official GET')
            data = inside(raw, receipt['stdout_path']).read_bytes()
            err = inside(raw, relative + '.stderr').read_bytes()
            require((len(data), sha(data)) == (receipt['stdout_bytes'], receipt['stdout_sha256']) and (len(err), sha(err)) == (receipt['stderr_bytes'], receipt['stderr_sha256']), 'log/archive receipt bytes')
        require(endpoint.startswith(api + '/'), 'foreign API receipt')
        receipts[relative] = endpoint
    used = set()
    def endpoint(label, expected):
        require(receipts.get(label) == expected, 'missing/wrong GET: ' + label)
        used.add(label)
    endpoint('run', api + '/actions/runs/' + str(runid))
    run = load(raw / 'run.stdout')
    keys = ('id', 'head_sha', 'head_branch', 'workflow_id', 'run_attempt', 'event', 'created_at')
    require(tuple(run[k] for k in keys) == tuple(binding[k] for k in ('run_id', 'head_sha', 'branch', 'workflow_id', 'run_attempt', 'event', 'created_at')) and run['status'] == 'completed', 'terminal official run identity')
    require(run['repository']['full_name'] == run['head_repository']['full_name'] == binding['repository'], 'terminal repository identity')
    def paged(label, key):
        merged = load(raw / ('all-' + label + '.json'))
        rows, page = [], 1
        total = merged['total_count']
        while True:
            endpoint(label + '-page-' + str(page), api + '/actions/runs/' + str(runid) + '/' + label + '?per_page=100&page=' + str(page))
            data = load(raw / (label + '-page-' + str(page) + '.stdout'))
            require(data['total_count'] == total and len(data[key]) <= 100, 'pagination totals changed')
            rows += data[key]
            if len(rows) == total:
                break
            require(len(rows) < total and len(data[key]) == 100 and page < 1000, 'incomplete pagination')
            page += 1
        require(rows == merged[key] and len({r['id'] for r in rows}) == len(rows), 'merged pagination/unique IDs')
        return rows
    jobs = paged('jobs', 'jobs')
    names = {n for j in contracts['jobs'].values() for n in j['names']}
    require(len(jobs) == len(names) == 21 and {j['name'] for j in jobs} == names, 'all21 exact official job names')
    joblogs = {}
    for job in jobs:
        require((job['run_id'], job['head_sha'], job['run_attempt'], job['status']) == (runid, head, binding['run_attempt'], 'completed'), 'job terminal/run identity')
        ident = str(job['id'])
        endpoint('job-' + ident + '-log', api + '/actions/jobs/' + ident + '/logs')
        joblogs[job['name']] = re.sub(r'^\d{4}-\d{2}-\d{2}T[0-9:.]+Z ', '', inside(raw, 'job-' + ident + '-log.log').read_text(), flags=re.M)
        check = job['check_run_url']
        require(check.startswith('https://api.github.com/' + api + '/check-runs/'), 'wrong official check run URL')
        page = 1
        while True:
            label = 'annotations-' + ident + '-page-' + str(page)
            endpoint(label, check.removeprefix('https://api.github.com/') + '/annotations?per_page=100&page=' + str(page))
            annotations = load(raw / (label + '.stdout'))
            require(type(annotations) is list and len(annotations) <= 100, 'annotations page shape')
            if len(annotations) < 100:
                break
            page += 1
            require(page < 1000, 'unbounded annotations pagination')
    artifacts = paged('artifacts', 'artifacts')
    require(len({a['name'] for a in artifacts}) == len(artifacts), 'duplicate artifact names')
    mapped = {}
    for artifact in artifacts:
        ident = str(artifact['id'])
        endpoint('archives/' + ident, api + '/actions/artifacts/' + ident + '/zip')
        require(artifact['workflow_run']['id'] == runid and artifact['workflow_run']['head_sha'] == head and artifact['expired'] is False, 'artifact wrong/expired run binding')
        item = load(raw / ('artifact-files/' + ident + '.json'))
        archive = inside(raw, 'archives/' + ident + '.zip')
        require((item['artifact_id'], item['name']) == (artifact['id'], artifact['name']), 'artifact file index identity')
        require(artifact['digest'] == item['api_digest'] == 'sha256:' + sha(archive.read_bytes()) and item['archive_sha256'] == sha(archive.read_bytes()), 'official artifact ZIP digest')
        directory = raw / item['directory']
        require(directory.resolve().is_relative_to((raw / 'artifacts').resolve()), 'artifact extraction outside root')
        listed = rows_by_path(item['files'])
        with zipfile.ZipFile(archive) as z:
            members = z.infolist()
            files = [m for m in members if not m.is_dir()]
            require(len(files) == len(listed) and {m.filename for m in files} == set(listed), 'ZIP member full inventory')
            require(len({m.filename.rstrip('/') for m in members}) == len(members), 'duplicate ZIP members')
            for member in files:
                require(stat.S_IFMT(member.external_attr >> 16) in (0, stat.S_IFREG), 'nonregular ZIP member')
                data = z.read(member)
                require((len(data), sha(data)) == listed[member.filename] and inside(directory, member.filename).read_bytes() == data, 'ZIP member/extraction binding')
        actual = {p.relative_to(directory).as_posix() for p in directory.rglob('*') if p.is_file()}
        require(actual == set(listed) and not any(p.is_symlink() for p in directory.rglob('*')), 'unindexed/symlink artifact files')
        require(not any(p.name == 'SYNTHETIC-SCOPE.txt' for p in directory.rglob('*')), 'synthetic controls cannot qualify CI')
        mapped[artifact['name']] = directory
    require(len(list((raw / 'artifact-files').glob('*.json'))) == len(artifacts), 'extra artifact file indexes')
    require(set(receipts) == used, 'extra/unverified official collection receipts')
    return run, jobs, mapped, joblogs, {'all_indexed_files': index['count'], 'all_archive_digests': len(artifacts), 'all_official_GETs': len(receipts), 'terminal_index_sha256': sha((raw / 'files.json').read_bytes())}
def verify_native(folder, major, expected):
    require(pair_map(folder / 'profile.tsv') == PROFILE, 'six variable profile/mandatory DB mode')
    overrides = tsv(folder / 'override-presence.tsv', 3)
    require({r[0] for r in overrides} == {'CARGO_TARGET_DIR', 'RUSTFLAGS', 'RUSTDOCFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUST_MIN_STACK', 'RUSTC', 'RUSTC_BOOTSTRAP', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER'} and all(r[1] in ('0', '1') and r[2] == '0' for r in overrides), 'unexpected runtime/build override')
    require((folder / 'cold-target.txt').read_text() in ('absent\n', 'empty\n'), 'not a cold target')
    require(re.fullmatch(r'[0-9a-f]{64} true\n', (folder / 'service.txt').read_text()), 'service container binding')
    settings = (folder / 'settings-before.tsv').read_text()
    require(settings == (folder / 'settings-after.tsv').read_text(), 'durability settings changed')
    fields = settings.strip().split('|')
    require(len(fields) == 4 and int(fields[0]) // 10000 == major and fields[1:] == ['on', 'on', 'on'], 'wrong PostgreSQL/durability settings')
    require((folder / 'created-databases.txt').read_text() == 'stateknot_store_native\nstateknot_runtime_native\n', 'independent fresh DB names')
    pids = pair_map(folder / 'pids.tsv')
    require(set(pids) == {'store', 'runtime'} and len(set(pids.values())) == 2 and all(x.isdigit() and int(x) > 1 for x in pids.values()), 'two owned leader identities')
    require(pair_map(folder / 'suite-exits.tsv') == {'store': '0', 'runtime': '0'}, 'actual native suite exits')
    require(pair_map(folder / 'leader-exits.tsv') == dict.fromkeys(pids, '0'), 'actual two leader waits')
    require((folder / 'cleanup.tsv').read_text() == 'monitor_exit\t0\n', 'monitor cleanup did not succeed')
    require(pair_map(folder / 'retire-requests.tsv') == dict.fromkeys(pids, 'suite-complete'), 'two suite-complete retire requests')
    retired = tsv(folder / 'retired.tsv', 3)
    require(len(retired) == 2 and {r[0]: r[1] for r in retired} == pids and all(r[2] == '0' for r in retired), 'two group-empty retirement receipts')
    helpers = []
    for role, pid in pids.items():
        owner = folder / (role + '-owner')
        identity = (owner / 'leader-identity').read_text()
        require(re.fullmatch(re.escape(pid) + r' [0-9]+\n', identity), 'leader start identity')
        require((owner / 'cleanup-complete').read_text() == identity and (owner / 'cleanup-reason').read_text() == 'parent-cleanup\n', 'live leader cleanup/identity')
        require((owner / 'helper-wait-status').read_text() == '0\n' and (owner / 'suite-status').read_text() == '0\n', 'helper true wait/status')
        require(not (owner / 'forced-kill').exists() and not (owner / 'control').exists(), 'forced kill or retained FIFO')
        helper = (owner / 'helper-pid').read_text().strip()
        require(helper.isdigit() and int(helper) > 1 and helper not in pids.values(), 'owned helper identity')
        helpers.append(helper)
    require(len(set(helpers)) == 2, 'distinct owned helper children')
    require(not (folder / 'ownership-errors.tsv').exists() or (folder / 'ownership-errors.tsv').stat().st_size == 0, 'ownership failure')
    overlap = load(folder / 'native-binary-overlap.json')
    require(overlap['both_actual_binary_processes_alive'] is True and type(overlap['observed_unix_ns']) is int, 'actual native binary overlap absent')
    roles, bindings, execution_pids = {}, {}, []
    for role, package, count in [('store', 'stateknot-store-postgres', 267), ('runtime', 'stateknot-runtime', 194)]:
        receipt = load(folder / (role + '-binary.json'))
        require(receipt['role'] == role and receipt['inventory_count'] == receipt['expected_inventory'] == count and receipt['validated_no_run_build_exit_code'] == 0, 'native role/inventory/build validation')
        source = receipt['source']
        require(source['head'] == expected['head_sha'] and source['files'] == expected['compiled_files'] and source['manifest_sha256'] == expected['native_source_manifest_sha256'], 'all544 exact frozen V3 inputs/head')
        require(sha(json.dumps(source['files'], sort_keys=True).encode()) == source['manifest_sha256'], 'source manifest hash')
        binary = receipt['binary']
        require(re.fullmatch(re.escape(WORKSPACE) + r'/target/debug/deps/postgres-[0-9a-f]{16}', binary), 'original binary path')
        artifact = receipt['selected_artifact']
        require(artifact['fresh'] is False and artifact['features'] == [] and artifact['executable'] == binary and artifact['filenames'] == [binary], 'cold original default-feature artifact')
        profile = artifact['profile']
        require(profile['opt_level'] == '1' and type(profile['debuginfo']) is int and profile['debuginfo'] == 0 and profile['debug_assertions'] is True and profile['overflow_checks'] is True and profile['test'] is True, 'native profile')
        require(artifact['target']['kind'] == ['test'] and artifact['target']['crate_types'] == ['bin'] and artifact['target']['name'] == 'postgres' and artifact['target']['src_path'] == WORKSPACE + '/crates/' + package + '/tests/postgres.rs', 'native target identity')
        build = load(folder / (role + '-build-exit.json'))
        require(build['build_process_exit_code'] == 0 and build['argv'] == ['cargo', 'test', '-p', package, '--test', 'postgres', '--locked', '--no-run', '--message-format=json'], 'actual Cargo no-run command/exit')
        cargo = [json.loads(line, object_pairs_hook=unique, parse_constant=reject) for line in (folder / (role + '-build.jsonl')).read_bytes().splitlines()]
        require(cargo[-1] == {'reason': 'build-finished', 'success': True} and sum(r.get('reason') == 'build-finished' for r in cargo) == 1, 'actual terminal Cargo build-finished')
        require(sum(row == artifact for row in cargo) == 1, 'selected native artifact in actual Cargo stream')
        toolchain = receipt['toolchain']
        require(toolchain == load(folder / (role + '-toolchain.json')) and toolchain['cargo_version'].startswith('cargo 1.88.0 ') and toolchain['rustc_verbose'].startswith('rustc 1.88.0 '), 'pinned toolchain')
        for suffix, key in [('build.jsonl', 'build_stdout_sha256'), ('build.stderr', 'build_stderr_sha256'), ('inventory.stdout', 'inventory_stdout_sha256'), ('inventory.stderr', 'inventory_stderr_sha256')]:
            require(sha((folder / (role + '-' + suffix)).read_bytes()) == receipt[key], 'native build/inventory log digest')
        inventory = (folder / (role + '-inventory.stdout')).read_text().splitlines()
        names = [line[:-6] for line in inventory if line.endswith(': test')]
        require(len(names) == len(set(names)) == count and len(inventory) == count + 2 and inventory[-1] == str(count) + ' tests, 0 benchmarks', 'actual full unique binary inventory')
        execution = load(folder / (role + '-execution.json'))
        require(execution == overlap['processes'][role] and execution['binary'] == binary and execution['binary_sha256'] == receipt['binary_sha256'] and execution['argv'] == [binary, '--test-threads=1'], 'actual original exec/overlap binding')
        require(execution['cwd'] == WORKSPACE + '/crates/' + package and execution['started_unix_ns'] <= overlap['observed_unix_ns'] and 'RUST_MIN_STACK' not in execution['runtime_environment'], 'default stack/source execution context')
        require(execution['runtime_environment']['CARGO_MANIFEST_PATH'] == receipt['package']['manifest_path'] and execution['runtime_environment']['LD_LIBRARY_PATH'].split(':')[:len(receipt['dynamic_library_prefix'])] == receipt['dynamic_library_prefix'], 'Cargo runtime environment')
        execution_pids.append(execution['pid'])
        roles[role] = {'passed': count, 'suite_exit': 0, 'test_seconds': exact_summary((folder / (role + '.stdout')).read_bytes(), count), 'build_seconds': build['seconds'], 'binary_sha256': receipt['binary_sha256']}
        bindings[role] = {k: receipt[k] for k in ('binary', 'binary_sha256', 'binary_bytes', 'source')}
    require(len(set(execution_pids)) == 2 and set(overlap['processes']) == {'store', 'runtime'}, 'two distinct actual native binaries')
    for role in ('store', 'runtime'):
        require((folder / (role + '-command.txt')).read_text() == 'python3 .github/scripts/postgres-native-binaries.py run ' + role + '\n', 'fixed owned command')
    require(not any(p.name.startswith('compile') for p in folder.iterdir()), 'unexpected third compile owner/lane')
    log_hashes = (folder / 'log-sha256.txt').read_text().splitlines()
    require(len(log_hashes) == 4, 'four final native output hashes')
    for name in ('store.stdout', 'store.stderr', 'runtime.stdout', 'runtime.stderr'):
        require(log_hashes.count(sha((folder / name).read_bytes()) + '  postgres-native-parallel/' + name) == 1, 'final native log digest')
    return {'roles': roles, 'actual_native_overlap': True, 'both_live_owners_retired': True, 'monitor_exit': 0, 'default_features_stack_profile': True, 'all544_inputs_exact': True}



def verify_markers(folder, major, kind, official):
    wait = kind == 'scoped-wait'
    stem = 'scoped-wait-commit-loss' if wait else 'frame-return-commit-loss'
    prefix = 'STATEKNOT_SCOPED_WAIT_COMMIT_LOSS_EVIDENCE=' if wait else 'STATEKNOT_FRAME_RETURN_COMMIT_LOSS_EVIDENCE='
    case = ('nested_driver::frame_wait_process_faults::scoped_wait_commit_loss_survives_real_kill_authorized_resolution_and_cold_driver' if wait else
            'nested_driver::frame_return_process_faults::frame_return_commit_loss_survives_real_kill_and_cold_higher_fence_driver')
    raw = (folder / (stem + '.log')).read_bytes()
    seconds = exact_summary(raw, 1, 193)
    lines = raw.decode('utf-8').splitlines()
    require(sum(line.startswith('test ' + case + ' ...') for line in lines) == 1, 'exact Return/Wait test start')
    encoded = [line[len(prefix):] for line in lines if line.startswith(prefix)]
    require(len(encoded) == 2, 'exactly two real cut markers required')
    require(all(official.splitlines().count(prefix + row) == 1 for row in encoded), 'Return/Wait actual marker missing/repeated in official process job log')
    cuts = {}
    for text in encoded:
        row = json.loads(text, object_pairs_hook=unique, parse_constant=reject)
        cut = row['cut']
        require(cut in ('commit_not_forwarded', 'commit_response_withheld') and cut not in cuts, 'unknown/repeated COMMIT cut')
        committed = cut == 'commit_response_withheld'
        expected = {'profile': 'scoped-wait-commit-loss-v1' if wait else 'frame-return-commit-loss-v1', 'cut': cut,
                    'commit_forwarded': committed, 'commit_response_forwarded': False, 'writer_killed_and_reaped': True,
                    'invariants': 'passed', 'termination': 'SIGKILL', 'os': 'linux', 'arch': 'x86_64',
                    'original_wait_recovered' if wait else 'original_return_recovered': committed,
                    'parent_application_calls': 1}
        if wait:
            expected.update({'cold_driver_after_authorized_resolution': True, 'condition_count': 2, 'snapshot_tables': 22,
                             'wait_application_redispatches': 0, 'scoped_successor_calls': 1,
                             'fresh_old_fence_wait_refused': None if committed else True,
                             'original_request_ack_after_return_verified': committed})
        else:
            expected.update({'cold_higher_fence_driver_verified': True, 'leaf_application_redispatches': 0})
        require(set(row) == set(expected) | {'postgres'}, 'closed Return/Wait marker key set')
        for key, value in expected.items():
            require(type(row[key]) is type(value) and row[key] == value, 'Return/Wait marker field: ' + key)
        require(type(row['postgres']) is str and re.fullmatch(str(major) + r'[.][0-9]+(?:[ .(].*)?', row['postgres']), 'marker PostgreSQL version')
        cuts[cut] = row
    require(len({r['postgres'] for r in cuts.values()}) == 1, 'mixed cut server versions')
    saved = load(folder / (stem + '-validation.json'))
    ordered = [cuts[k] for k in ('commit_not_forwarded', 'commit_response_withheld')]
    require(saved['cuts'] == ordered and saved['log_sha256'] == sha(raw) and saved['status'] == 'passed' and saved['exact_case'] == case and saved['full_runtime_inventory'] == 194 and saved['selected_passed'] == 1 and saved['filtered_out'] == 193 and saved['marker_count'] == 2 and saved['postgres_major'] == str(major) and saved['runner_os'] == 'linux' and saved['runner_arch'] == 'x86_64', 'saved Return/Wait validation binding')
    return {'cut_count': 2, 'seconds': seconds, 'log_sha256': sha(raw), 'linux_x86_64_actual_marker_fields_verified': True}



def resolved_name(template, binding, major=None):
    value = template.replace('${{ github.run_id }}', str(binding['run_id'])).replace('${{ github.sha }}', binding['head_sha'])
    if major is not None:
        value = value.replace('${{ matrix.version }}', str(major))
    require('${{' not in value, 'unresolved artifact template')
    return value


def job_name(contracts, jid, major):
    values = contracts['jobs'][jid]['names']
    require(len(values) == 2, 'expected dual-major job')
    return next(n for n in values if n.endswith('(' + str(major) + ')'))


def artifact_log(artifacts, contracts, binding, jid, major, log):
    matches = []
    for template, spec in contracts['artifact_templates'].items():
        if spec['job'] != jid:
            continue
        name = resolved_name(template, binding, major)
        folder = artifacts[name]
        files = [p for p in folder.rglob(log) if p.is_file()]
        require(len(files) <= 1, 'ambiguous artifact log path')
        matches += files
    require(len(matches) == 1, 'missing/duplicated required artifact log: ' + log)
    return matches[0]


def parent_fixture_test_succeeded(text, case):
    headers = list(re.finditer(r'^test ([^\r\n]+?) \.\.\.', text, re.M))
    matches = [h for h in headers if h.group(1) == case]
    require(len(matches) == 1, 'real subprocess parent test absent/repeated: ' + case)
    start = matches[0]
    ends = [h.start() for h in headers if h.start() > start.start()]
    summary = re.search(r'^test result:', text[start.end():], re.M)
    if summary:
        ends.append(start.end() + summary.start())
    end = min(ends) if ends else len(text)
    body = [line.strip() for line in text[start.end():end].splitlines() if line.strip()]
    require(body and body[-1] == 'ok', 'real subprocess parent test did not finish successfully: ' + case)
    return {'case': case, 'actual_parent_success': True}


def all_ok_summaries(text, label, expected_count=None, fixture=None):
    summaries = SUMMARY.findall(text)
    require(summaries and (expected_count is None or len(summaries) == expected_count), 'missing/extra harness summary: ' + label)
    require(not re.search(r'^test result: (?:FAILED|ignored)', text, re.M), 'failed harness: ' + label)
    ignored_lines = re.findall(r'^test [^\r\n]+ \.\.\. ignored(?:,[^\r\n]*)?$', text, re.M)
    parents = []
    if fixture is None:
        require(all(int(row[0]) > 0 and row[1:4] == ('0', '0', '0') for row in summaries) and not ignored_lines, 'failed/ignored/empty harness outside exact original subprocess fixture contracts: ' + label)
    else:
        require(fixture['label'] == label and len(summaries) == 1, 'original subprocess contract only applies to one exact named harness')
        counts = fixture['summary']
        expected = tuple(str(counts[k]) for k in ('passed', 'failed', 'ignored', 'measured', 'filtered_out'))
        require(summaries[0][:5] == expected and counts['passed'] > 0 and counts['failed'] == counts['measured'] == 0 and counts['ignored'] == 1, 'exact original subprocess harness counts differ: ' + label)
        require(ignored_lines == [fixture['exact_ignored_line']], 'unknown/missing/repeated ignored test or changed reason: ' + label)
        require(fixture['running'] == counts['passed'] + counts['ignored'] and text.splitlines().count('running ' + str(fixture['running']) + ' tests') == 1, 'original subprocess harness exact running count')
        parents = [parent_fixture_test_succeeded(text, case) for case in fixture['parent_cases']]
    result = [{'passed': int(row[0]), 'failed': int(row[1]), 'ignored': int(row[2]), 'measured': int(row[3]), 'filtered_out': int(row[4]), 'seconds': float(row[5])} for row in summaries]
    if fixture is not None:
        result[0]['explicit_ignored_subprocess_fixture'] = {'case': fixture['ignored_case'], 'reason': fixture['ignored_reason'], 'exact_ignored_line': fixture['exact_ignored_line'], 'source': fixture['source'], 'parent_tests': parents, 'parent_execution_is_verified_by_original_markers': True}
    return result


def verify_step_states(jobs, contracts, mapping):
    by_name = {j['name']: j for j in jobs}
    report, mapped = {}, []
    for major in (16, 17):
        for role in ('native', 'process', 'protocol', 'host'):
            jid = 'postgres-' + role
            job = by_name[job_name(contracts, jid, major)]
            names = contracts['jobs'][jid]['steps']
            named = [s for s in job['steps'] if s['name'] in names]
            require([s['name'] for s in named] == names, 'missing/reordered/duplicate shard named steps: ' + job['name'])
            report[job['name']] = {'id': job['id'], 'conclusion': job['conclusion'], 'all_steps': job['steps'], 'workflow_named_steps': named,
                                   'non_success_named_steps': [s for s in named if s['status'] != 'completed' or s['conclusion'] != 'success']}
            for row in mapping:
                if row['shard'] == role:
                    actual = named[row['candidate_index']]
                    require(actual['name'] == row['name'], '60-step mapping does not match frozen candidate index')
                    mapped.append({'postgres_major': major, 'source_index': row['source_index'], 'source_name': row['name'], 'shard': role,
                                   'job_id': job['id'], 'number': actual['number'], 'status': actual['status'], 'conclusion': actual['conclusion']})
        aggregate = by_name[job_name(contracts, 'postgres', major)]
        chosen = [s for s in aggregate['steps'] if s['name'] == 'Require every PostgreSQL shard on both majors']
        require(len(chosen) == 1, 'missing strict actual aggregate step')
        report[aggregate['name']] = {'id': aggregate['id'], 'conclusion': aggregate['conclusion'], 'all_steps': aggregate['steps'], 'guard': chosen[0]}
    require(len(mapped) == 120 and all(sorted(r['source_index'] for r in mapped if r['postgres_major'] == m) == list(range(1, 61)) for m in (16, 17)), 'all60 on both majors mapped exactly once')
    succeeded = all(row['status'] == 'completed' and row['conclusion'] == 'success' for row in mapped)
    succeeded &= all(not row.get('non_success_named_steps', []) for row in report.values())
    succeeded &= all(row['guard']['status'] == 'completed' and row['guard']['conclusion'] == 'success' for row in report.values() if 'guard' in row)
    return {'all60_source_steps_per_major': sorted(mapped, key=lambda r: (r['postgres_major'], r['source_index'])), 'all_shard_and_aggregate_steps': report, 'all_required_steps_succeeded': succeeded}


def verify_artifact_inventory(artifacts, contracts, binding):
    expected = set()
    for template in contracts['artifact_templates']:
        for major in ((16, 17) if '${{ matrix.version }}' in template else (None,)):
            expected.add(resolved_name(template, binding, major))
    require(set(artifacts) == expected, 'missing or unexpected artifacts from complete frozen workflow: ' + str({'missing': sorted(expected - set(artifacts)), 'extra': sorted(set(artifacts) - expected)}))
    retained = []
    expectedrows = {r['path']: r for r in binding['expected_files']}
    for template, spec in contracts['artifact_templates'].items():
        if not spec['job'].startswith('postgres'):
            continue
        for major in (16, 17):
            name = resolved_name(template, binding, major)
            folder = artifacts[name]
            required_files = []
            for line in spec['path'].splitlines():
                if line.startswith('!') or not line or line.endswith('/'):
                    continue
                require(not line.startswith('/') and '..' not in Path(line).parts, 'unsafe upload file rule')
                matches = sorted(p for p in folder.glob(line) if p.is_file())
                require(matches, 'frozen upload file/glob matched no retained file: ' + name + ':' + line)
                if line == 'failure-close-process-*.log':
                    require({p.relative_to(folder).as_posix() for p in matches} == {'failure-close-process-qualification.log', 'failure-close-process-environment.log'}, 'complete frozen failure-close process glob requires exact qualification/environment logs')
                required_files += matches
            require(len(required_files) == len(set(required_files)), 'overlapping frozen upload file rules')
            for path in required_files:
                line = path.relative_to(folder).as_posix()
                raw = inside(folder, line).read_bytes()
                retained.append({'artifact': name, 'path': line, 'bytes': len(raw), 'sha256': sha(raw)})
                if line.endswith('-environment.log'):
                    text = raw.decode()
                    if line == 'reduced-host-qualification-environment.log':
                        required = ['STATEKNOT_QUALIFICATION_SOURCE_COMMIT=' + binding['head_sha'], 'STATEKNOT_QUALIFICATION_SOURCE_TREE=' + binding['tree'], 'STATEKNOT_QUALIFICATION_CARGO_LOCK_SHA256=' + expectedrows['Cargo.lock']['sha256'], 'STATEKNOT_QUALIFICATION_POSTGRES_MAJOR=' + str(major)]
                        require(all(text.splitlines().count(v) == 1 for v in required), 'reduced environment source/major binding')
                    else:
                        require(text.splitlines().count(binding['head_sha']) == text.splitlines().count(binding['tree']) == 1 and expectedrows['Cargo.lock']['sha256'] + '  Cargo.lock' in text, 'environment actual head/tree/lock binding')
                        require('rustc 1.88.0 ' in text and 'Linux ' in text and 'x86_64' in text, 'environment pinned Linux toolchain')
    return {'complete_workflow_artifact_count': len(expected), 'all_required_PG_raw_files': retained}


def verify_reduced(row, binding, major):
    require(set(row) == {'schema_version', 'report', 'report_sha256'} and row['schema_version'] == 1, 'reduced integrity envelope schema')
    report = row['report']
    require(sha(canonical(report)) == row['report_sha256'], 'reduced report canonical integrity digest')
    require(report['schema_version'] == 1 and report['profile'] == 'ci_reduced' and report['evidence_valid'] is True and report['release_qualified'] is False, 'reduced report scope/evidence')
    src = report['environment']['source']
    require(src['source_commit'] == binding['head_sha'] and src['source_tree'] == binding['tree'], 'reduced report actual source binding')
    expected = {r['path']: r for r in binding['expected_files']}
    require(src['cargo_lock_sha256'] == expected['Cargo.lock']['sha256'] and src['dataset_sha256'] == expected['docs/scenarios/README.md']['sha256'], 'reduced report actual input hashes')
    require(report['environment']['postgres']['major_version'] == major and report['environment']['postgres']['synchronous_commit'] is True, 'reduced actual PostgreSQL major/durability')
    require(report['counters']['unexpected_failures'] == 0 and all(report['counters'][key] == 0 for key in ('lost_acknowledged_records', 'accepted_stale_writes', 'cross_tenant_disclosures', 'duplicate_external_effects')), 'reduced report safety counters')
    require(report['objectives'] and all(v['status'] != 'fail' for v in report['objectives']), 'reduced report objective failures')
    require(report['finished_at_unix_millis'] > report['started_at_unix_millis'], 'reduced report actual interval')



def validate_marker_matrix(prefix, records):
    phases = {
        'STATEKNOT_PROCESS_KILL_EVIDENCE=': ['source', 'delivery', 'child_terminal', 'settlement', 'close', 'replay'],
        'STATEKNOT_CHILD_JOIN_PROCESS_EVIDENCE=': ['admission', 'join', 'child_terminal', 'settlement', 'publication', 'takeover', 'parent_resume', 'replay'],
        'STATEKNOT_DEADLINE_JOIN_PROCESS_EVIDENCE=': ['admission', 'join', 'deadline', 'child_cancel', 'child_terminal', 'settlement', 'takeover', 'parent_terminal', 'replay'],
    }
    if prefix in phases:
        require([r['phase'] for r in records] == phases[prefix], 'incomplete/reordered actual committed process boundary matrix')
    if records and type(records[0]) is dict and 'cut' in records[0]:
        cuts = ['commit_not_forwarded', 'commit_response_withheld']
        if prefix == 'STATEKNOT_JOIN_DEADLINE_COMMIT_LOSS_EVIDENCE=':
            require([(r['operation'], r['cut']) for r in records] == [(op, cut) for op in ('join_registration', 'join_publication', 'deadline_cancellation') for cut in cuts], 'incomplete Join/deadline operation/cut matrix')
        else:
            require([r['cut'] for r in records] == cuts, 'incomplete two-cut COMMIT matrix')


def verify_marker_logs(artifacts, contracts, binding, joblogs, major):
    rows, checked_logs = [], {}
    for spec in contracts['markers']:
        jid, prefix, log = spec['job'], spec['prefix'], spec['log']
        path = artifact_log(artifacts, contracts, binding, jid, major, log)
        raw = path.read_bytes()
        text = raw.decode('utf-8', errors='strict')
        official = joblogs[job_name(contracts, jid, major)]
        found = [line for line in text.splitlines() if line.startswith(prefix)]
        require(len(found) == spec['count'], 'exact actual marker count: ' + prefix)
        require(all(official.splitlines().count(line) == 1 for line in found), 'artifact marker not present once in its official job log')
        require(len(set(found)) == len(found), 'duplicate actual marker record')
        semantics = contracts['source_marker_constants'].get(prefix[:-1], [])
        plaintext = contracts.get('source_plain_markers', {}).get(prefix[:-1])
        records = []
        for line in found:
            payload = line[len(prefix):]
            if plaintext is not None:
                require(payload == plaintext, 'plain marker differs from exact frozen Rust source')
                records.append(payload)
                continue
            row = decode(payload)
            require(type(row) is dict and row, 'marker JSON object required')
            if prefix == 'STATEKNOT_HOST_QUALIFICATION_REPORT=':
                verify_reduced(row, binding, major)
            else:
                require(semantics, 'no frozen source semantic contract: ' + prefix)
                def matches(item):
                    constants = item['constants']
                    return set(row) == set(constants if item['closed_literal'] else item['keys']) and all(k in row and type(row[k]) is type(v) and row[k] == v for k, v in constants.items())
                require(any(matches(item) for item in semantics), 'marker semantic fields differ from frozen source: ' + prefix)
                for key, value in (('os', 'linux'), ('arch', 'x86_64'), ('invariants', 'passed')):
                    if key in row:
                        require(row[key] == value, 'actual marker platform/invariants: ' + prefix)
                if 'termination' in row:
                    require(row['termination'] == 'SIGKILL', 'actual Linux process was not killed by SIGKILL')
                if 'forced_exit' in row:
                    require(row['forced_exit'] is True, 'process boundary exited normally')
                if 'cut' in row:
                    require(row['cut'] in ('commit_not_forwarded', 'commit_response_withheld') and row['commit_forwarded'] is (row['cut'] == 'commit_response_withheld'), 'actual COMMIT forwarding/cut relationship')
                if 'expired_fence_rejection_verified' in row:
                    require(row['expired_fence_rejection_verified'] is (row['cut'] == 'commit_not_forwarded'), 'expired-fence branch relation')
                if 'original_event_recovered' in row:
                    require(row['original_event_recovered'] is (row['cut'] == 'commit_response_withheld'), 'original event recovery branch relation')
                if 'postgres' in row:
                    require(type(row['postgres']) is str and re.fullmatch(str(major) + r'[.][0-9]+(?:[ .(].*)?', row['postgres']), 'actual marker PostgreSQL version')
                if prefix == 'STATEKNOT_ROLE_PROFILE_EVIDENCE=':
                    require(type(row['schema']) is int and row['schema'] == 37, 'current trusted role schema37 required')
                if prefix == 'STATEKNOT_CHILD_JOIN_BACKUP_RESTORE_EVIDENCE=':
                    require(re.fullmatch('sha256:[0-9a-f]{64}', row['archive_sha256']) and type(row['archive_bytes']) is int and row['archive_bytes'] > 0, 'real logical backup archive digest/size')
                if prefix == 'STATEKNOT_CHILD_JOIN_PITR_EVIDENCE=':
                    require(re.fullmatch('[0-9a-f]{64}', row['manifest_sha256']) and re.fullmatch('[0-9A-F]{24}', row['wal_segment_archived']) and re.fullmatch('[0-9a-f]{32}', row['resource_identity']) and row['named_restore_point'] == 'stateknot_child_join_before_late_write', 'physical base backup/WAL/named restore/resource identity')
            records.append(row)
        validate_marker_matrix(prefix, records)
        if (jid, log) not in checked_logs:
            fixture = contracts['ignored_fixture_harnesses'].get(log)
            if fixture is not None:
                require(fixture['job'] == jid and official.splitlines().count(fixture['exact_ignored_line']) == 1, 'original ignored fixture artifact/official job mismatch')
                for case in fixture['parent_cases']:
                    parent_fixture_test_succeeded(official, case)
            checked_logs[(jid, log)] = {'log': log, 'sha256': sha(raw), 'harnesses': all_ok_summaries(text, log, fixture=fixture)}
        rows.append({'step': spec['step'], 'log': log, 'prefix': prefix, 'expected_count': spec['count'], 'actual_count': len(found), 'actual_records': records, 'raw_log_sha256': sha(raw), 'frozen_semantics_verified': True})
    # The mandatory 15-case ingress has an intentionally plain fixed marker.
    jid, log = 'postgres-protocol', 'mcp-bound-state-qualification.log'
    text = artifact_log(artifacts, contracts, binding, jid, major, log).read_text()
    marker = 'STATEKNOT_MCP_BOUND_STATE_POSTGRES: consumers=3 positive_commits=6 refused_rebinds=12 tenant_ledgers=2 complete_journals=true'
    require(text.splitlines().count(marker) == 1 and 'STATEKNOT_MCP_BOUND_STATE_POSTGRES_SKIPPED:' not in text, 'mandatory actual MCP bound-state marker/no skip')
    require(joblogs[job_name(contracts, jid, major)].splitlines().count(marker) == 1, 'bound-state artifact/official log mismatch')
    exact_summary(text.encode(), 15)
    # Identity's fixed shell fixture itself prints the actual immutable source.
    identity = artifact_log(artifacts, contracts, binding, 'postgres-host', major, 'agent-identity-qualification.log').read_text()
    require(identity.splitlines().count('STATEKNOT_IDENTITY_IMAGE=quay.io/keycloak/keycloak@sha256:29be7252db0a106f1cd2ac17b9a56ff2668073da645638a38b9fc67deeb2d6c4') == 1 and identity.splitlines().count(binding['head_sha']) == identity.splitlines().count(binding['tree']) == 1, 'actual pinned real TLS fixture/source identity')
    all_ok_summaries(identity, 'real TLS identity', 2)
    return {'all_workflow_marker_contracts': rows, 'all_raw_harness_logs': list(checked_logs.values()), 'mandatory_bound_state15': True, 'actual_real_TLS_pinned_identity': True}


def verify_original_protocol_harnesses(binding, contracts, joblogs, major):
    text = joblogs[job_name(contracts, 'postgres-protocol', major)]
    result = []
    for name, command, count in [
        ('provider_native_postgres', 'cargo test -p stateknot-integrations --test provider_native_postgres --locked -- --test-threads=1', 2),
        ('deepseek_agent', 'cargo test -p stateknot --example deepseek_agent --locked -- --test-threads=1', 1),
    ]:
        header = '##[group]Run ' + command + '\n'
        require(text.count(header) == 1, 'actual original protocol command header absent/repeated')
        tail = text.split(header, 1)[1]
        end = re.search(r'^##\[group\]Run ', tail, re.M)
        section = tail[:end.start()] if end else tail
        seconds = exact_summary(section.encode(), count)
        result.append({'target': name, 'actual_passed': count, 'actual_test_seconds': seconds})
    return {'harnesses': result, 'compilation_does_not_substitute_for_execution': True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bundle', type=Path, default=HERE)
    parser.add_argument('--raw', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    require(not args.out.exists(), 'output exists; preserve old evidence and choose a new version')
    require(not args.out.resolve().is_relative_to(args.raw.resolve()) and not args.out.resolve().is_relative_to(args.bundle.resolve()), 'analysis output must be outside immutable inputs')
    args.out.mkdir(parents=True)
    report = {'schema': 'stateknot-postgres-shards-terminal-analysis-v1', 'analysis_errors': [], 'components': {}, 'full_CI_success_verified': False,
              'full_CI_qualification': False, 'PR14_or_R1_closed': False, 'milestone_or_release_qualified': False,
              'old_local_V3_sleep_failure_does_not_qualify': True, 'synthetic32_aggregate_controls_do_not_qualify': True,
              'network_DB_Docker_Cargo_Git_executed_by_analyzer': False}
    def component(name, function):
        try:
            report['components'][name] = {'verified': True, **function()}
        except Exception as error:
            report['components'][name] = {'verified': False, 'error': str(error)}
            report['analysis_errors'].append(name + ': ' + str(error))
    try:
        binding, contracts, mapping, facts = verify_bundle(args.bundle)
        report.update({k: binding[k] for k in ('run_id', 'head_sha', 'tree', 'branch', 'parent', 'source_936_sha256', 'compiled_canonical_sha256')})
        report['bundle_verification'] = facts
        # Keep every API job state even when later raw evidence validation fails.
        preliminary = load(args.raw / 'all-jobs.json')['jobs']
        report['all_observed_job_states'] = [{'id': j['id'], 'name': j['name'], 'status': j['status'], 'conclusion': j['conclusion'], 'all_steps': j.get('steps', [])} for j in preliminary]
        report['observed_job_states_verified'] = False
        run, jobs, artifacts, joblogs, verified = verify_collection(args.raw, binding, contracts, facts)
        report.update({'run_status': run['status'], 'run_conclusion': run['conclusion'], 'observed_job_states_verified': True, 'terminal_raw_verification': verified})
        component('all60_step_states_on_both_majors', lambda: verify_step_states(jobs, contracts, mapping))
        component('all_workflow_artifacts_and_raw_files', lambda: verify_artifact_inventory(artifacts, contracts, binding))
        for major in (16, 17):
            component('pg' + str(major) + '_native267_194_two_live_owners', lambda m=major: verify_native(artifacts['postgres-native-parallel-' + str(m) + '-' + str(binding['run_id'])], m, binding))
            for kind, artifact in (('return', 'frame-return-commit-loss-postgres'), ('scoped-wait', 'scoped-wait-commit-loss-postgres')):
                component('pg' + str(major) + '_' + kind + '_two_real_cuts194_193', lambda m=major, k=kind, a=artifact: verify_markers(artifacts[a + '-' + str(m) + '-' + str(binding['run_id'])], m, k, joblogs[job_name(contracts, 'postgres-process', m)]))
            component('pg' + str(major) + '_all_process_host_protocol_TLS_backup_PITR_markers', lambda m=major: verify_marker_logs(artifacts, contracts, binding, joblogs, m))
            component('pg' + str(major) + '_actual_original_protocol_harnesses', lambda m=major: verify_original_protocol_harnesses(binding, contracts, joblogs, m))
        step_success = report['components']['all60_step_states_on_both_majors'].get('all_required_steps_succeeded') is True
        report['full_CI_success_verified'] = run['conclusion'] == 'success' and len(jobs) == 21 and all(j['status'] == 'completed' and j['conclusion'] == 'success' for j in jobs) and step_success and not report['analysis_errors']
        report['full_CI_qualification'] = report['full_CI_success_verified']
    except Exception as error:
        report['analysis_errors'].append('input/terminal binding: ' + str(error))
    report['analyzer_sha256'] = sha(Path(__file__).read_bytes())
    report['observed_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (args.out / 'receipt.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'receipt': str(args.out / 'receipt.json'), 'run_conclusion': report.get('run_conclusion'), 'full_CI_success_verified': report['full_CI_success_verified'], 'analysis_errors': report['analysis_errors']}))
    return 1 if report['analysis_errors'] else 0


if __name__ == '__main__':
    raise SystemExit(main())
