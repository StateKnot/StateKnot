# Spec review

Fixed point: `e372184fb1c80ffb9903ac0d9feb8380db51253e`. Reviewed the immutable
936-file composed source (`dae0ca2b4a5bfd901c647e80e1e881e63cad52cf24ec3f06072697a54334d909`)
and its 29-path patch (`cdaaf10531840b77f8947e0724717775e7625379657f2808154fe55157bc22c2`).

**Actionable findings: 0. Worst issue: none identified.**

The selected RFC-0022 contract requires the “actual cancellation decision,” the
“exact complete ownership-key set,” and preservation of the original Executing
owner. Writer and cold-reader paths retain complete Root/frame/ordinary-history
authentication, bind the unique latest current-leaf owner to the exact unpublished
Join registration/request/fence, authenticate all account settlements at the saved
observation, and retain ordinary completion/result and Join-consumption absence.
Fresh all-account terminal-child locks and re-reads precede writing; complete
deferred guards and post-guard owning verification remain inside the transaction.
SQL37 exempts only the authenticated stopped attempt. V1 wire/domains/schema and
strict failure-close behavior remain distinct; original ACK authentication still
precedes fresh candidate validation.

The new staged-settlement test exercises legal live-child and terminal-unsettled
states through public Store APIs, verifies complete tenant no-write snapshots on
both refusals, and accepts closure only after real settlement. It retains the
owner/Join/accounting facts and complete measured DIRECT.

The new Runtime-package process tracer exercises public Store APIs only. The
unchanged CommitProxy withholds actual COMMIT CommandComplete and idle ReadyForQuery;
an independent reader proves the committed closure before an owned live writer is
killed/reaped. A separately spawned cold process recovers the same bytes and
Existing ACK from stale candidate fields, with complete tenant snapshot equality.
Its module text and evidence marker correctly say `driver_exercised=false`.

Scope remains experimental Store-only: the three Driver guards are unchanged.
Published Join, later owner, Root terminal, broader negative/fault/compatibility
matrices and milestone acceptance remain open. Three qualification documents are
explicitly pending Root delivery; this read-only review does not award compilation,
267/194 Native inventories, execution, six gates, full CI, migration qualification
or R1 completion. No build, database, Docker, network or frozen/main edits occurred.
