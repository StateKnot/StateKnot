from pathlib import Path
import json,subprocess,sys,time
out=Path(__file__).resolve().parent
rows=[]
for gate in ('fmt','clippy','workspace','doctests','rustdoc','nightly'):
 start=time.time();r=subprocess.run([sys.executable,str(out/'run-gate.py'),gate])
 rows.append({'gate':gate,'actual_exit_code':r.returncode,'seconds':time.time()-start})
 (out/'all-gates.execution.json').write_text(json.dumps({'rows':rows,'complete':len(rows)==6,'all_zero':len(rows)==6 and all(x['actual_exit_code']==0 for x in rows)},indent=2)+'\n')
 if r.returncode:sys.exit(r.returncode)
