# Qualification fact-update authoring handoff

This source-only draft is for Root's next documentation version. It does not edit
primary Markdown/JSON, publish evidence, refresh CI or award qualification.

- `update-checklist.zh-CN.md`: Chinese corrections, exact bindings/outcomes,
  delivery gaps, JSON update plan and proposed milestone paragraph.
- `update-checklist.md`: matching English checklist and proposed paragraph.
- `facts.json`: versioned source/binary/gate/Native/recovery/CI/F2 observations.
- `evidence-read-index.json`:96 original evidence paths and byte hashes; the raw
  files remain at their original saved locations.

The current three primary qualification documents and the38-payload measurement
commit retain their historical V2 pending snapshot. A later document update must
preserve that historical provenance and use actual terminal CI receipts if they
have become available. The saved official GET read here is in-progress, not a
current terminal claim.

Root should first finish the versioned terminal collector/analyzer, then assemble
a new portable evidence package with complete raw index and both passing/failing
history. Update both language documents, their JSON and the milestone/ledger
references together. Do not merge the separate next-slice F2 RED source or any
future ignored green authoring into this current V3 source/CI qualification.

Still missing or outside scope: successful full local V3 Runtime qualification;
actual complete final CI; delivered portable V3 evidence at the planned repository
path; owner-stop-specific closure-v2 backup/PITR; published-but-unconsumed Join,
spawn-before-registration and later resumed-owner cases; complete deferred/fault
and published compatibility coverage; all three scoped Driver guard removals and
complete Driver profile; Root ConfirmCancellation; R1/R6, production capacity,
independent security, deployment and release. A successful CI run can close only
its own exact gate, preserving actual older local failures and these other gaps.

Binary hashes are read from saved actual build/execution metadata. This authoring
task did not run the binaries or independently replay those executions. It
verified the six existing gate log bytes against their saved receipt digests and
extracted complete successful/failed libtest summaries without running tests.
