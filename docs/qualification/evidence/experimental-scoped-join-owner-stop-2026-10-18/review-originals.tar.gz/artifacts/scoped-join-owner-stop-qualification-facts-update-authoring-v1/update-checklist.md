# Next scoped Join owner-stop qualification update: author checklist

This directory prepares the next English/Chinese qualification, machine JSON and milestone update for Root. It changes no primary file and grants no new execution qualification. `facts.json` retains the concrete saved observations; `evidence-read-index.json` identifies96 read-only evidence inputs and their current hashes. The author did not refresh CI status or execute Cargo, databases, Docker, CI, collectors or analyzers.

## Correct the historical snapshot before adding results

- The current English/Chinese `experimental-scoped-join-owner-stop-2026-10-18` and JSON describe **composed-v2 at2026-10-18 11:26 UTC**. Their pending full-Native statement, V2 source table and V2 gate list must not be presented as V3 outcomes.
- The actual38 payloads published in `bbd9dcf833a3446b822e8e1398c53d19cf3b9a72` include these three historical pending-V2 documents. Their presence in that measurement commit does not certify V3 Native or21-job CI. Publish the next document version separately and retain the old snapshot's provenance.
- The next opening paragraph should state that the selected public-Store boundary remains experimental: V3 local six gates and four targeted existing consumed-Join restores passed; V2 Store suites passed; all actual V2/V3 Runtime failures remain failures; final-source Linux CI awaits terminal evidence. Scoped Driver Join, Root ConfirmCancellation, R1, R6, RFC-0022 acceptance and Supported status remain open.

## Keep the source domains distinct

| Domain | Exact value and claim |
| --- | --- |
| Publication parent | `e372184fb1c80ffb9903ac0d9feb8380db51253e` |
| Published measurement head / Git tree | `bbd9dcf833a3446b822e8e1398c53d19cf3b9a72` / `126d95b5a80c703b781e270a157c5b81a4a3ad39` |
| Complete official recursive tree | 4088 blobs /4604 recursive entries; preserve all paths/types/modes/Git SHA1s/sizes and reconstruct the root/subtree SHA1s |
| Exact publication delta | 38 actual payloads checked against frozen prepared request bytes, length, SHA256, Git blob SHA1 and mode; every other4050 final blob equals the official parent in path/type/mode/SHA1/size, without deletion or unlisted changes |
| V3 selected pre-CI product source | 936 files / `21c32c1446377a9691d63d835bb732b8d8cc6259e236c9cd0575dc13369f7a44`; this selected inventory is **not the entire repository tree** |
| Five CI files | Independently bound exact bytes; ci.yml replaces one selected path and four helpers are additions outside936, yielding940 final selected byte bindings |
| V3 compilation supply inputs | 544 files / canonical SHA256 `30d6c10fd88118297131a28c0e3b78420f51dec17206a718948a348c7424de81` |
| Cargo.lock | `fc36c3966dc2abf990fae6a01b633459d95fedae0fd7f77c429b5f04447b2e94` |
| Separate V2 source | 936 / `e8f3b8a1c93cbbd8ad00fa3622657be032a98fc775ea9580337c27c1d8ad77db`;544 / `acc2f7706a60201874a2dec4de5c690fcee4bf7a04409822bf409f72ca7f1c16` |

Claim content SHA256 only for actual bytes read and verified: selected source, five CI files and38 payloads. The other inherited blobs have the checked Git SHA1/mode/type/size; do not claim newly computed content SHA256 for unread bytes.

Retain each local binary separately: V2 Store `c7c5daf1e2c9606d57f2fdf5c4791b2eacffc65e37b7b50c50de60465a63d474` /267; V2 Runtime `6f633c5883ccdba9308d7ba408c044653ec4c3a95c9a3c27469ae15e0dda4e7e` /194; V3 Runtime `b28ccd6c3c158453cfe2af995802a3dc042e23f47dfbc0e965cba34f4cd72354` /194. V2 Store results do not become V3 or Linux CI executions. Preserve default features, opt1/debug0/incremental0, enabled assertions/overflow checks, default stack, toolchain, exact `fresh=false` artifact scope, inventory/build stream, before/after source/binary/container/durability bindings. `fresh=false` does not mean all dependencies were cold.

## Preserve the complete Native outcomes side by side

| Source and full suite | PG16 | PG17 |
| --- | --- | --- |
| V2 Store267 | actual0;267 passed/0 failed/0 ignored; libtest476.90s; outer476.9529s | actual0;267/0/0; libtest471.67s; outer471.7179s |
| V2 Runtime194 | actual101;193 passed/1 failed; libtest858.74s | actual101;193/1; libtest858.45s |
| V3 Runtime194 | actual101;183 passed/11 failed; libtest912.54s; outer20993.4189s; not timed out | actual101;182 passed/12 failed; libtest859.25s; outer19557.5203s; not timed out |

The sole V2 failure is the old role-profile pin: actual schema37, expected36. V3 changes only that literal in `role_profile.rs`, with935 other selected files unchanged. Its static delta review preserves ACL/LOGIN/54-table/business/cleanup/budget checks and grants no complete V3 Runtime pass. Both failing V3 suites emit the full schema37 role marker and complete that subcase; preserve this limited positive fact without hiding the11/12 other failures. Include every failing test name and original stderr, not only totals.

The old observer's `libtest_summary=[]` reflects an `ok`-only parser, not absence of a real terminal summary. The retained stdout's `FAILED` summary supplies these counts. Keep the original observer booleans and outputs unchanged.

The bounded local power log covers19:47:02 through next-day01:36:56, with120 event rows,30 sleeps and one clamshell event. This correlates with the large outer-wall/libtest discrepancy. There is no controlled awake same-source successful rerun establishing causality. Do not state that all failures were solely caused by sleep, can be discarded, were fixed or already passed. Retain actual101, non-timeout status, all failed cases and source/binary/settings receipts. These durations are not capacity or performance evidence.

## Record V3's actual six local gates

Use the V3 receipts in `scoped-join-owner-stop-composed-gates-v4`; the older `composed-six-gates-root-v1` summarizes V2.

- fmt, strict workspace Clippy, workspace tests, doctests, warning-denying Rustdoc and pinned `nightly-2026-10-07` check each exited0 with exact before/after source.
- Workspace:100 successful harness summaries,2128 passed/0 failed/6 existing ignored. Doctests:10 harness summaries and48 passed.
- These all-feature/test-opt0 local gates have no mandatory PostgreSQL environment. They certify no Native/default dependency graph/Linux Runtime/CI run. Retain the previous V1 Clippy101, V2 sandbox-workspace101 and their separate resolutions.

## Four actual V3 existing consumed-Join restore passes

All four use V3 Runtime binary `b28ccd6c…`, actual0 and1 passed/193 filtered. The directory suffixes `backup-native-v2`/`pitr-native-v2` do not identify composed-v2 source.

| Exact scope | PG16 | PG17 |
| --- | --- | --- |
| Mandatory logical backup/restore | PostgreSQL16.15; outer5.1009517s | PostgreSQL17.11; outer2.7248530s |
| Physical base backup, archived WAL, named restore point | PostgreSQL16.14; outer7.5308442s | PostgreSQL17.11; outer7.3319151s |

Retain archive size and exact `sha256:<64hex>` Digest string, source/restore isolation, exact snapshot, cross-tenant refusal and noninitial replay. PITR additionally retains its unprefixed64-hex manifest, actual WAL segment/named restore point, cleanup confirmation for the original UUID's two containers/three volumes and absence of wrapper cleanup. The host markers are macos/aarch64 with fixed Linux database containers; they do not certify Linux Runtime. These cases cover existing **consumed child Join** restore, not stopped-owner closure-v2-specific restore, Driver, Root ConfirmCancellation, full Runtime, R6 replication failover/recovery windows or production disaster recovery.

## Keep current21-job CI pending until actual terminal evidence

Actual single dispatch: branch `codex/ci-postgres-shards-20261019-v1`, run [39185847363](https://github.com/StateKnot/StateKnot/actions/runs/39185847363), attempt1, created2026-10-19T01:32:53Z. The author's saved official GET says `in_progress`, conclusion null; this is a historical observation, not terminal status or continuing monitoring. `complete_CI` remains false.

The four dual-major shard matrices preserve the original30-minute budget, default-feature commands, stack/profile/images and mandatory steps. The original PostgreSQL contexts are strict `always()` aggregation jobs; the other11 actual jobs remain. The total is21, with all60 original PG steps mapped exactly once per major. Do not reuse13-job/53-step constants. Terminal evidence must retain all21 job/step states, all raw job logs and annotation pages, complete artifact pagination, official ZIP digests and every extracted file, including Native267/194/two live owners, Return/Wait194/193/two cuts, role37 and every TLS/host/backup/PITR marker.

Only this actual run's21 terminal successes, successful mandatory steps and complete verified evidence can establish full CI for this head. Even then, retain the old local failures and keep Driver/Root/R1/R6/Supported open. Historical dc13238's11-success/2-cancelled e372 measurement remains separate.

## Deliver evidence before changing delivery claims

The audited checkout lacks `docs/qualification/evidence/experimental-scoped-join-owner-stop-2026-10-18/`. The machine record remains `PENDING_ROOT_ASSEMBLY` with null portable index. The old ignored `evidence-assembly-v1` is not complete V3 delivery. Create a new portable package and full hash index, then replace planned links with actual paths and the actual index digest.

The package needs V2/V3 source and binary/profile/build/inventory bindings; complete V2 Store success and Runtime failure bytes; both V3 Runtime failures and original observers plus correlated power logs; all six V3 gates; all four restore runs/markers/resource audits; the exact role-pin delta review and original Standards/Spec scopes;38 payloads and official parent/final trees/commit/ref/compare/run GETs; and, once terminal, the entire CI ZIP/log/file index and offline analysis receipt. Huge binary bodies need not be archived where the record permits hashes, but actual hash/size/profile/build/execution provenance must remain.

Machine JSON should split `execution_sources` by V2/V3 and add/rework `six_local_gates_v3`, `native_by_source_and_major` with failures, `suspension_correlation` with `causality_proven:false`, `existing_consumed_join_recovery_v3`, `published_measurement_binding` with separate38/4088/936/940/544 domains, pending `final_CI`, `raw_evidence_delivery` and precise open scopes. Keep V2 selected cases, wrapper false negatives, historical migration/consumer/schema and old CI under their own sources.

## Keep next-slice F2 RED outside this V3 record

The separate ignored F2 RED source is `64707ce3781e9efe9887394c9212124b46523f78cfb6e97e4ab36e55892f3a80`, compiled inputs `45b11a8c8512d1bc833c69201ca1ade0cf31026d4e710f960ac706bb471a2338`, binary `a3885ab31c28b91535190919d7aa9aaae2e236c7cbb2d512e95a4ec154bad6a8`. Each major exits101 with1 failed/194 filtered: the future handoff expectation fails naturally after the preceding cleanup/business invariants are reached. It makes no product implementation change and remains `Green=false`. It is outside the current V3 measurement commit and194-entry suite, removes no three Driver guards and closes no Root/R1 scope.

## Suggested milestone fact paragraph, pending Root adoption

> 2026-10-19: The next scoped Join owner-stop V3 changes only the current schema37 test pin. Its six local gates and dual-major targeted existing consumed-Join logical/physical restores passed. Full V2 Store267 passed on both majors; V2 Runtime193/1 pin failures and V3 Runtime183/11 and182/12 actual failures remain preserved, with sleep logs supplying correlation only. Published head bbd9dcf8 runs four dual-major shards and21 total jobs in actual CI39185847363, awaiting complete terminal/raw-evidence verification. The selected936 source,544 compilation inputs,38 publication payloads and4088 complete Git blobs are bound separately. This experimental public-Store boundary enables no scoped Driver Join; Root ConfirmCancellation, full fault/compatibility coverage, portable delivery, R1, R6 and RFC-0022/Supported remain open. New F2 dual-major RED is an independent next slice and is not included in this V3 qualification.
