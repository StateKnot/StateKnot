# scoped Join owner-stop 下一版验收事实更新清单（作者草案）

本目录仅供 Root 编写和复核下一版中英 qualification / JSON / 里程碑增量，不修改主仓，不构成新的执行验收。事实来自已保存回执、原始 stdout/stderr、冻结清单与官方 GET；具体机器数据见 `facts.json`，96份只读证据引用及当前字节摘要见 `evidence-read-index.json`。CI 状态只采用现有官方 GET 的历史观察，不在作者侧刷新。

## 必须先改正的快照语义

- 当前中英 `experimental-scoped-join-owner-stop-2026-10-18` 与 JSON 仍描述 **2026-10-18 11:26 UTC 的 composed-v2**；其中“完整 Native 待执行”“最终执行源码 V2”“六门禁 V2”不能直接延伸为当前 V3 结果。
- `bbd9dcf833a3446b822e8e1398c53d19cf3b9a72` 的38份实际发布 payload 包含这三份历史 pending-V2 文档。它们的旧文字是历史快照，不证明 V3 完整 Native 或21-job CI 已通过。下一版须用新文件版本/新文档提交更新，并保留原历史来源。
- 下一版开头须直接写：选中的 public Store owner-stop 边界保持实验性；V3 六项本机门禁通过，四次既有 consumed-Join 恢复定向执行通过；V2 Store 完整套件双版通过，V2/V3 Runtime 的真实失败全部保留；当前最终源码的 Linux 完整 CI 待终态证据。Driver scoped Join、Root ConfirmCancellation、R1、R6、RFC-0022 接受与 Supported 均开放。

## 来源必须分域，不能把936写成全仓文件数

| 域 | 必须记录的值与范围 |
| --- | --- |
| 发布父提交 | `e372184fb1c80ffb9903ac0d9feb8380db51253e` |
| 已发布量测 head / Git tree | `bbd9dcf833a3446b822e8e1398c53d19cf3b9a72` / `126d95b5a80c703b781e270a157c5b81a4a3ad39` |
| 官方完整递归树 | 4088个 blob、4604条递归 entry；完整保留 path/type/mode/Git SHA1/size，并从全部 entry 重建根及子树 SHA1 |
| 精确发布增量 | 38份实际 payload；逐字节验证大小、SHA256、Git blob SHA1、mode 与 prepared tree request；其他4050个 final blob 与官方 parent 的 path/type/mode/SHA1/size 完全一致，无额外删除或变更 |
| V3 CI 前选定产品输入 | 936文件；`21c32c1446377a9691d63d835bb732b8d8cc6259e236c9cd0575dc13369f7a44`；这是选定来源清单，**不是完整仓库树** |
| 5份 CI overlay | 独立逐字节绑定；ci.yml 替换936中的一路，4份 helper 新增在936之外；合并后的选定 final byte 绑定共940路 |
| V3 编译供应输入 | 544文件；canonical SHA256 `30d6c10fd88118297131a28c0e3b78420f51dec17206a718948a348c7424de81` |
| 锁文件 | `fc36c3966dc2abf990fae6a01b633459d95fedae0fd7f77c429b5f04447b2e94` |
| V2 独立来源 | 936 / `e8f3b8a1c93cbbd8ad00fa3622657be032a98fc775ea9580337c27c1d8ad77db`；544 / `acc2f7706a60201874a2dec4de5c690fcee4bf7a04409822bf409f72ca7f1c16` |

内容 SHA256 只覆盖实际读取并核验的936选定源、独立5CI和38 payload 字节；其余官方 inherited blob 只有本次验证的 Git SHA1/mode/type/size，不能声称重新读取并计算了内容 SHA256。

本机 binary 必须按各自来源分别保留：V2 Store `c7c5daf1e2c9606d57f2fdf5c4791b2eacffc65e37b7b50c50de60465a63d474` /267；V2 Runtime `6f633c5883ccdba9308d7ba408c044653ec4c3a95c9a3c27469ae15e0dda4e7e` /194；V3 Runtime `b28ccd6c3c158453cfe2af995802a3dc042e23f47dfbc0e965cba34f4cd72354` /194。不得将 V2 Store binary 的全套结果改写成 V3 或 Linux CI 执行。保留 default features、opt1、debug0/incremental0、debug assertions/overflow checks/default stack、工具链、`fresh=false` 的确切 artifact 范围、原始 inventory、build stream 和运行前后 source/binary/container/durability 绑定。`fresh=false` 不等于所有依赖冷缓存。

## 必须原样并列的 Native 结果

| 来源与套件 | PG16 | PG17 |
| --- | --- | --- |
| V2 Store267完整 | actual0；267 passed/0 failed/0 ignored；libtest476.90s，outer476.9529s | actual0；267/0/0；libtest471.67s，outer471.7179s |
| V2 Runtime194完整 | actual101；193 passed/1 failed；libtest858.74s | actual101；193/1；libtest858.45s |
| V3 Runtime194完整 | actual101；183 passed/11 failed；libtest912.54s；outer20993.4189s；非timeout | actual101；182 passed/12 failed；libtest859.25s；outer19557.5203s；非timeout |

V2 唯一失败是 `trusted_sql_role_profile_enforces_privileges_and_runs_durable_work` 的旧 schema pin：实际37、断言36。V3 仅把 `role_profile.rs` 该字面值36→37，其余935份选定源不变；独立 delta review 只证明范围与原 ACL/LOGIN/54表/业务/cleanup/budget 不变，不授予 V3 Runtime 全套通过。V3 两份失败全套中均观察到 schema37 的完整 role marker 和该子用例正常完成；这是一项限定子用例正向事实，不能覆盖其余11/12项失败。失败名字和 raw stderr 均须完整附入，不只摘要失败总数。

**观察器缺陷也须保留。** 旧 `observations.json` 的 `libtest_summary=[]` 仅因旧观察器只识别 `ok`，不表示缺少真实终态；原 stdout 的 `FAILED` 摘要是本清单计数依据。原 observer 布尔值不修改、不把 false 改写成 green。

睡眠诊断仅作为相关证据：本地19:47:02至次日01:36:56的有界 power log 有120条事件行、30次 sleep、1次 clamshell。它与异常 outer wall/libtest 时间差重合，但没有受控的同源持续唤醒成功复验；不能写成已证明全部失败仅由睡眠造成、可忽略、已修复或已经重跑成功。保留 actual101、非timeout、完整11/12失败及 source/binary/settings 原件。不能把这些耗时写成容量或性能认证。

## V3 六项本机门禁

使用 `scoped-join-owner-stop-composed-gates-v4` 的六份 V3 回执，不能用旧 `composed-six-gates-root-v1` 的 V2 汇总替代。

- fmt、strict workspace Clippy、workspace tests、doctests、warning-denying Rustdoc、固定 `nightly-2026-10-07` check 均 actual0；各自 `source_before_after_exact=true`。
- workspace：100份成功 harness，2128 passed、0 failed、6个既有 ignored；doctests：10份 harness、48 passed。
- 这些是 all-features/test opt0、无 mandatory PostgreSQL 环境的本机门禁；不能视为 Native、默认依赖图、Linux Runtime 或 CI 验收。原 V1 Clippy101、V2 sandbox workspace101 及对应修正历史均保留。

## V3 既有 consumed-Join 恢复：四次实际通过的精确范围

四次均绑定 V3 Runtime binary `b28ccd6c…`，actual0、1 passed/193 filtered；不把目录后缀 `backup-native-v2`/`pitr-native-v2` 误写成来源 composed-v2。

| 用例 | PG16 | PG17 |
| --- | --- | --- |
| 强制逻辑备份恢复 | PostgreSQL16.15；outer5.1009517s | PostgreSQL17.11；outer2.7248530s |
| 物理 base backup + archived WAL + named restore point | PostgreSQL16.14；outer7.5308442s | PostgreSQL17.11；outer7.3319151s |

保留 archive大小与 `sha256:<64hex>` Digest 字符串、源/恢复数据库隔离、精确 snapshot、跨租户拒绝、非初始重放；PITR 另保留无前缀64hex manifest、真实 WAL segment、named restore point、原 UUID 两容器/三卷不存在的清理确认及无 wrapper 代清理事实。宿主 marker 为 macos/aarch64、数据库为固定 Linux 容器；不能称 Linux Runtime 已通过。四次只验证既有“已消费 child Join”恢复，不覆盖 stopped-owner closure-v2 专属恢复、Driver、Root ConfirmCancellation、完整 Runtime、R6 复制故障切换/恢复窗口或生产灾难恢复。

## 当前21-job CI只能按真实终态回执更新

已真实发布并单次 dispatch：branch `codex/ci-postgres-shards-20261019-v1`，run [39185847363](https://github.com/StateKnot/StateKnot/actions/runs/39185847363)，attempt1，创建于2026-10-19T01:32:53Z。作者读取的保存 GET 为 `in_progress` / conclusion null；这不是终态或持续监控。当前 `complete_CI=false`。

四个独立双major shard保留原30分钟预算、原 default-feature命令、默认stack/profile/镜像与必须步骤，原 PostgreSQL context 成为严格 `always()` 聚合；其他11个实际job保留。实际总数21，各major原60步骤一项不丢，不沿用旧53步骤/13job常量。最终须完整保存全部21job真实状态、各步状态、全部job raw logs/annotations、全部artifact分页、官方ZIP digest及每个解包文件；Native267/194双live owner、Return/Wait的194/193与双cut、role37、所有真实TLS/host/backup/PITR markers均须独立复核。

只有该实际run终态全部21success、全部必需步骤成功且完整证据可验后，才能更新该head的完整CI事实。即使通过，也不撤销旧本机失败、不授予Driver/Root/R1/R6/Supported。历史dc13238的11success/2cancelled保留为独立e372产品量测，不转授。

## Portable evidence 与 machine JSON 必改项

当前 checkout 不存在 `docs/qualification/evidence/experimental-scoped-join-owner-stop-2026-10-18/`；主JSON仍为 `PENDING_ROOT_ASSEMBLY` / index null。已有ignored `evidence-assembly-v1`不是完整V3交付。必须先产出新版本可交付包与完整hash index，再把引用改成真实相对路径和实际index摘要；不能只把状态文字改成“已交付”。

新包至少包含：V2/V3来源清单和实际binary/profile/build/inventory绑定；V2完整Store正向与Runtime失败原件；V3两套Runtime所有失败/观察器原件和相关power日志；V3全部六门禁；四次恢复原件/marker/资源核对；精确角色delta review及原Standards/Spec范围；38payload/官方parent/final树/commit/ref/compare/runGET；最终CI若已终态则完整全部raw ZIP/log索引与离线验证回执。可不归档巨型binary本体，但真实hash/大小/profile/编译与运行绑定不可丢。

Machine JSON应新增或重组：`execution_sources`（V2/V3分列）、`six_local_gates_v3`、`native_by_source_and_major`（含所有失败）、`suspension_correlation`（`causality_proven:false`）、`existing_consumed_join_recovery_v3`、`published_measurement_binding`（38/4088/936/940/544分开）、`final_CI`（当前pending）、`raw_evidence_delivery`及精确未关闭scope。旧V2选中用例、wrapper假阴性、历史迁移/consumer/schema与旧CI均保留自身来源。

## 下一切片F2必须独立

新的 ignored F2 RED 来源为 `64707ce3781e9efe9887394c9212124b46523f78cfb6e97e4ab36e55892f3a80` / compiled `45b11a8c8512d1bc833c69201ca1ade0cf31026d4e710f960ac706bb471a2338`，binary `a3885ab31c28b91535190919d7aa9aaae2e236c7cbb2d512e95a4ec154bad6a8`。双major各 actual101/1 failed/194 filtered，限定证明前置清理/业务不变量到达后，未来handoff期望自然失败；没有产品实现改变，`Green=false`。它不是当前V3 measurement commit、不是V3 Runtime194库存的新通过项，也不移除3处Driver guard或关闭Root/R1。

## 里程碑建议追加文字（仍待Root采用）

> 2026-10-19：scoped Join owner-stop 的后续V3仅更新真实schema37测试pin；六项本机门禁和双版既有consumed-Join逻辑/物理恢复定向执行通过。V2完整Store267双版通过；V2Runtime193/1的旧pin失败与V3Runtime183/11、182/12的真实失败均保留，睡眠日志只提供相关证据。已发布commit bbd9dcf8的四shard/双major共21job CI实际run39185847363仍待完整终态与raw证据核验；936选定源、544编译输入、38发布payload与4088完整Git blob各自绑定。实验性public Store边界不启用scoped Driver Join；Root ConfirmCancellation、完整故障/兼容、portable证据交付、R1、R6及RFC-0022/Supported均继续开放。F2新双版RED仅为独立下一切片，不并入本V3资格。
