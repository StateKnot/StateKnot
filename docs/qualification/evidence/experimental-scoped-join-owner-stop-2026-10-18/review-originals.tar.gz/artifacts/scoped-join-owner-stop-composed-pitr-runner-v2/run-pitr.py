#!/usr/bin/env python3
"""Run one existing composed-v3 Runtime binary's exact mandatory PITR case.

Root runs PG16 then PG17, after four full Native and two backup-restore runs
are terminal. No Cargo invocation, source modification, pull or external cleanup.
Only image inspect is issued by this wrapper; the unchanged test owns its UUID
containers/volumes and performs its original verified cleanup.
"""

import argparse
import hashlib
import importlib.util
import json
import os
import re
import subprocess
import sys
import threading
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
DAY = HERE.parent
REPO = HERE.parents[2]
SOURCE = DAY / "scoped-join-owner-stop-composed-source-v3"
QUALIFICATION = DAY / "scoped-join-owner-stop-composed-qualification-v3"
BUILD = DAY / "scoped-join-owner-stop-composed-native-v3/build-candidate-runtime-v1"
BUILD_RECEIPT_SHA = "d130836d05156c28c2c90adee97ca786aa473224c140b49c96ff19d14b36f9a2"
HELPER = DAY / "scoped-join-owner-stop-composed-native-runner-v1/build.py"
HELPER_SHA = "3412d08c7a0fdcb6df4ad24f0553aeaea0c92ccb2e4757e6afa67c23e48fd067"
SOURCE_SHA = "21c32c1446377a9691d63d835bb732b8d8cc6259e236c9cd0575dc13369f7a44"
COMPILED_SHA = "30d6c10fd88118297131a28c0e3b78420f51dec17206a718948a348c7424de81"
BINARY_SHA = "b28ccd6c3c158453cfe2af995802a3dc042e23f47dfbc0e965cba34f4cd72354"
CASE = "child_admission::ownership::join::pitr::consumed_child_join_survives_named_point_in_time_recovery"
BACKUP_CASE = "child_admission::ownership::join::backup_restore::consumed_child_join_survives_isolated_backup_restore"
PREREQUISITE_SOURCES = {
    "e8f3b8a1c93cbbd8ad00fa3622657be032a98fc775ea9580337c27c1d8ad77db": ("composed-v2", "acc2f7706a60201874a2dec4de5c690fcee4bf7a04409822bf409f72ca7f1c16"),
    SOURCE_SHA: ("composed-v3", COMPILED_SHA),
}
MARKER = "STATEKNOT_CHILD_JOIN_PITR_EVIDENCE="
IMAGES = {
    16: "postgres@sha256:fe03a7605299a34ddf5e4f285dff78c3d7190a576b3c6b46f2fcff69f4bffd54",
    17: "postgres@sha256:67f41722b7a8cbdb868a44a4995c846eddfdc2973bccb291ce937dce88ad5675",
}
IMAGE_FORMAT = '{"id":{{json .Id}},"repo_digests":{{json .RepoDigests}},"os":{{json .Os}},"architecture":{{json .Architecture}}}'
PASSWORDS = (b"stateknot_pitr_disposable_password", b"stateknot_test_password")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "duplicate JSON key")
        result[key] = value
    return result


def no_constant(value):
    raise ValueError("non-finite JSON constant")


def obj(path):
    return json.loads(Path(path).read_bytes(), object_pairs_hook=unique_object, parse_constant=no_constant)


def write(out, name, value):
    (out / name).write_text(json.dumps(value, indent=2) + "\n")


def prerequisites(path):
    data = obj(path)
    require(data["source_tree_sha256"] == SOURCE_SHA and data["compiled_inputs_sha256"] == COMPILED_SHA, "prerequisite source/input binding")
    full = data["full_native_runs"]
    backup = data["backup_restore_runs"]
    require(len(full) == 4 and {(row["major"], row["package"]) for row in full} == {(major, package) for major in (16, 17) for package in ("store", "runtime")}, "four full Native prerequisites")
    require(len(backup) == 2 and {row["major"] for row in backup} == {16, 17}, "two backup-restore prerequisites")
    facts = []
    for row in full + backup:
        receipt_path = Path(row["test_receipt"]).resolve()
        require(receipt_path.is_relative_to(DAY) and not receipt_path.is_symlink(), "prerequisite receipt path")
        require(sha(receipt_path) == row["receipt_sha256"], "prerequisite receipt SHA")
        receipt = obj(receipt_path)
        require(type(receipt.get("exit_code")) is int, "prerequisite must have an actual terminal test exit")
        prior_source = receipt["source_tree"]
        require(prior_source in PREREQUISITE_SOURCES, "unknown prerequisite source")
        prior_version, prior_inputs = PREREQUISITE_SOURCES[prior_source]
        require(receipt["compiled_inputs_sha256"] == prior_inputs, "prerequisite input/source mismatch")
        require(receipt["database"]["port"] == (55416 if row["major"] == 16 else 55417), "prerequisite actual database major binding")
        if row in full:
            count = 267 if row["package"] == "store" else 194
            require(receipt["full_inventory_count"] == count and receipt["expected_filtered"] == 0, "prerequisite full inventory")
            require(receipt["argv"][1:] == ["--test-threads=1", "--nocapture"], "prerequisite must be unfiltered full Native")
        else:
            require(prior_source == SOURCE_SHA, "backup prerequisite must execute composed-v3")
            require(receipt["binary_sha256"] == BINARY_SHA and receipt["full_inventory_count"] == 194, "backup prerequisite Native binding")
            require(len(receipt["argv"]) == 5 and receipt["argv"][1] == BACKUP_CASE and set(receipt["argv"][2:]) == {"--exact", "--nocapture", "--test-threads=1"}, "backup prerequisite exact selected case")
        facts.append({"major": row["major"], "package": row.get("package", "runtime"),
            "kind": "full_native" if row in full else "mandatory_backup_restore",
            "test_receipt": str(receipt_path), "receipt_sha256": row["receipt_sha256"],
            "actual_exit_code": receipt["exit_code"], "terminal": True,
            "source_version": prior_version, "source_tree_sha256": prior_source,
            "compiled_inputs_sha256": prior_inputs, "passing": receipt["exit_code"] == 0,
            "prior_source_failure_preserved": prior_version == "composed-v2" and receipt["exit_code"] != 0,
            "qualification_transferred_to_composed_v3": False})
    return facts


def parse_marker(raw, major):
    text = raw.decode("utf-8")
    require(text.count(MARKER) == 1, "require exactly one PITR marker")
    prefix = "\nrunning 1 test\ntest " + CASE + " ... \n" + MARKER
    require(text.startswith(prefix), "exact PITR test start/marker placement")
    line, newline, tail = text[len(prefix):].partition("\n")
    require(newline and re.fullmatch(r"ok\n\ntest result: ok\. 1 passed; 0 failed; 0 ignored; 0 measured; 193 filtered out; finished in [0-9]+(?:\.[0-9]+)?s\n\n", tail), "exact PITR result and only summary")
    marker = json.loads(line, object_pairs_hook=unique_object, parse_constant=no_constant)
    fixed = {"profile": "child-join-named-pitr-v1", "base_backup_verified": True,
        "named_restore_point": "stateknot_child_join_before_late_write", "post_target_write_excluded": True,
        "exact_durable_snapshot_verified": True, "noninitial_replay_verified": True,
        "cross_tenant_refusal_verified": True, "resource_cleanup_verified": True,
        "invariants": "passed", "os": "macos", "arch": "aarch64"}
    require(type(marker) is dict and set(marker) == set(fixed) | {"manifest_sha256", "wal_segment_archived", "resource_identity", "postgres"} and len(marker) == 15, "exact fifteen PITR fields")
    for key, expected in fixed.items():
        require(type(marker[key]) is type(expected) and marker[key] == expected, "PITR field: " + key)
    for key, pattern in [("manifest_sha256", r"[0-9a-f]{64}"), ("wal_segment_archived", r"[0-9A-F]{24}"), ("resource_identity", r"[0-9a-f]{12}7[0-9a-f]{3}[89ab][0-9a-f]{15}")]:
        require(type(marker[key]) is str and re.fullmatch(pattern, marker[key]), "PITR identity: " + key)
    require(type(marker["postgres"]) is str and re.fullmatch(str(major) + r"\.[0-9]+(?:\.[0-9]+)?(?: \([^\r\n]+\))?", marker["postgres"]), "actual restored server major")
    return marker


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--major", type=int, choices=(16, 17), required=True)
    parser.add_argument("--prerequisites", type=Path, required=True)
    parser.add_argument("--previous-pg16-receipt", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    out = args.out.resolve()
    require(out.is_relative_to(DAY) and out != HERE and out != DAY, "new task output directory required")
    out.mkdir(parents=True, exist_ok=False)
    preflight = {"runner_sha256": sha(__file__), "major": args.major, "preflight_completed": False,
        "actual_test_started": False, "Cargo_or_wrapper_external_cleanup_executed": False}
    try:
        require(sha(HELPER) == HELPER_SHA, "shared source/profile helper SHA")
        spec = importlib.util.spec_from_file_location("composed_native_profile", HELPER)
        shared = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(shared)
        shared.disk(out, "before")
        prior_facts = prerequisites(args.prerequisites)
        if args.major == 17:
            require(args.previous_pg16_receipt is not None, "PG17 requires the actual prior PG16 terminal receipt")
            pg16 = obj(args.previous_pg16_receipt)
            require(pg16["major"] == 16 and type(pg16["actual_test_exit_code"]) is int and pg16["source_tree_sha256"] == SOURCE_SHA and pg16["binary_sha256"] == BINARY_SHA, "previous PG16 terminal source/binary binding")
        else:
            require(args.previous_pg16_receipt is None, "PG16 has no previous PITR prerequisite")
        manifest_path = QUALIFICATION / "frozen-source-manifest.json"
        compiled_path = QUALIFICATION / "compiled-inputs.json"
        manifest, compiled = shared.check_source(SOURCE, manifest_path, compiled_path)
        require(manifest["source_tree_sha256"] == SOURCE_SHA and compiled["sha256"] == COMPILED_SHA, "frozen composed source SHA")
        build = obj(BUILD / "build-summary.json")
        build_receipt = obj(BUILD / "build.receipt.json")
        require(sha(BUILD / "build.receipt.json") == build["build_receipt_sha256"] == BUILD_RECEIPT_SHA, "actual composed-v3 build receipt SHA")
        require(build_receipt["exit_code"] == 0 and build_receipt["source_before_after_exact"] is True, "actual successful Native build")
        require(build["source"] == str(SOURCE) and build["source_tree"] == SOURCE_SHA and build["compiled_inputs_sha256"] == COMPILED_SHA, "build source/input binding")
        require(build_receipt["source_manifest_sha256"] == sha(manifest_path) and build_receipt["compiled_manifest_sha256"] == sha(compiled_path), "build frozen manifest SHA")
        binary = BUILD / "binaries/runtime-postgres"
        require(Path(build["saved_executable"]) == binary and not binary.is_symlink() and sha(binary) == build["binary_sha256"] == BINARY_SHA, "saved b28ccd Runtime binary")
        require(build["inventory_count"] == 194, "Runtime194 build inventory")
        selected = build["selected_artifacts_all_fresh_false"]
        require(len(selected) == 4, "four Native artifacts")
        for artifact in selected:
            profile = artifact["profile"]
            require(artifact["fresh"] is False and artifact["features"] == [] and profile["opt_level"] == "1" and profile["debuginfo"] == 0 and profile["debug_assertions"] is True and profile["overflow_checks"] is True, "Native original profile/default features")
        env = shared.common_env()
        require(shared.env_allowlist(env) == build_receipt["environment_allowlist"], "Native build profile/environment binding")
        for key in list(env):
            if key.startswith(("STATEKNOT_", "PG", "POSTGRES_", "POSTGRESQL_", "DATABASE_", "SQLX_")) or key == "DATABASE_URL" or key.endswith("_DATABASE_URL"):
                env.pop(key)
        image = IMAGES[args.major]
        workflow = (SOURCE / ".github/workflows/ci.yml").read_text()
        require(image in workflow, "image absent from exact frozen workflow")
        env.update(STATEKNOT_REQUIRE_PITR_TESTS="1", STATEKNOT_PITR_POSTGRES_IMAGE=image)
        require({key: value for key, value in env.items() if key.startswith("STATEKNOT_")} == {"STATEKNOT_REQUIRE_PITR_TESTS": "1", "STATEKNOT_PITR_POSTGRES_IMAGE": image}, "PITR environment isolation")
        image_argv = ["docker", "image", "inspect", "--format", IMAGE_FORMAT, image]
        checked = subprocess.run(image_argv, capture_output=True, env=env, timeout=30)
        (out / "image-inspect.stdout").write_bytes(checked.stdout)
        (out / "image-inspect.stderr").write_bytes(checked.stderr)
        write(out, "image-inspect.receipt.json", {"argv": image_argv, "exit_code": checked.returncode, "stdout_sha256": sha(out / "image-inspect.stdout"), "stderr_sha256": sha(out / "image-inspect.stderr")})
        require(checked.returncode == 0, "pinned local image missing; no automatic pull permitted by wrapper")
        image_info = json.loads(checked.stdout, object_pairs_hook=unique_object, parse_constant=no_constant)
        require(image in image_info["repo_digests"] and image_info["os"] == "linux" and image_info["architecture"] == "arm64", "actual pinned local image identity/architecture")
        inventory_argv = [str(binary), "--list"]
        listed = subprocess.run(inventory_argv, cwd=SOURCE, env=env, capture_output=True, timeout=30)
        (out / "inventory.stdout").write_bytes(listed.stdout)
        (out / "inventory.stderr").write_bytes(listed.stderr)
        names = re.findall(rb"^([^\n]+): test$", listed.stdout, re.M)
        require(listed.returncode == 0 and len(names) == len(set(names)) == 194 and names.count(CASE.encode()) == 1, "actual Runtime194 selected PITR inventory")
        write(out, "inventory.receipt.json", {"argv": inventory_argv, "exit_code": listed.returncode, "count": len(names), "stdout_sha256": sha(out / "inventory.stdout"), "stderr_sha256": sha(out / "inventory.stderr")})
        preflight.update(preflight_completed=True, source_tree_sha256=SOURCE_SHA, compiled_inputs_sha256=COMPILED_SHA,
            source_count=936, compiled_count=544, binary_sha256=BINARY_SHA,
            build_receipt_sha256=sha(BUILD / "build.receipt.json"), prerequisite_facts=prior_facts,
            prerequisites_manifest_sha256=sha(args.prerequisites), image=image, image_identity=image_info,
            no_external_database_environment=True, STATEKNOT_environment={"STATEKNOT_REQUIRE_PITR_TESTS": "1", "STATEKNOT_PITR_POSTGRES_IMAGE": image},
            original_test_limits_and_default_stack=True, original_UUID_owned_cleanup_only=True,
            external_wrapper_watchdog_seconds=None)
        write(out, "preflight.receipt.json", preflight)
    except Exception as error:
        preflight.update(actual_exit_code=1, error_type=type(error).__name__, error=str(error))
        write(out, "preflight.receipt.json", preflight)
        print(json.dumps({"major": args.major, "preflight_failed": True, "actual_test_started": False}), flush=True)
        return 1

    argv = [str(binary), CASE, "--exact", "--nocapture", "--test-threads=1"]
    streams = {}

    def capture(pipe, label):
        raw_sha = hashlib.sha256()
        redactions = 0
        with (out / label).open("wb") as saved:
            for line in iter(pipe.readline, b""):
                raw_sha.update(line)
                for password in PASSWORDS:
                    redactions += line.count(password)
                    line = line.replace(password, b"[REDACTED_PUBLIC_FIXTURE_PASSWORD]")
                saved.write(line)
        pipe.close()
        streams[label] = {"raw_sha256": raw_sha.hexdigest(), "redactions": redactions, "saved_sha256": sha(out / label), "saved_is_raw": redactions == 0}

    started = time.time()
    process = subprocess.Popen(argv, cwd=SOURCE, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    running = {**preflight, "argv": argv, "pid": process.pid, "runner_pid": os.getpid(), "start_unix": started, "actual_test_started": True}
    write(out, "running.json", running)
    print(json.dumps({"major": args.major, "pid": process.pid, "exact_case": CASE, "source_tree_sha256": SOURCE_SHA, "binary_sha256": BINARY_SHA}), flush=True)
    threads = [threading.Thread(target=capture, args=(process.stdout, "test.stdout")), threading.Thread(target=capture, args=(process.stderr, "test.stderr"))]
    for thread in threads:
        thread.start()
    code = process.wait()
    for thread in threads:
        thread.join()
    actual = {**running, "actual_test_exit_code": code, "seconds": time.time() - started, "output_streams": streams,
        "actual_test_result_saved_before_observation": True}
    write(out, "test.receipt.json", actual)
    print(json.dumps({"major": args.major, "actual_test_exit_code": code, "seconds": actual["seconds"]}), flush=True)
    result = {"major": args.major, "actual_test_exit_code": code, "source_tree_sha256": SOURCE_SHA,
        "binary_sha256": BINARY_SHA, "test_receipt_sha256": sha(out / "test.receipt.json"), "qualified": False,
        "Driver_scoped_Join_Root_ConfirmCancellation_full_CI_R1_qualified": False}
    post_errors = []
    try:
        after_manifest, after_compiled = shared.check_source(SOURCE, manifest_path, compiled_path)
        require(after_manifest == manifest and after_compiled == compiled and sha(binary) == BINARY_SHA, "PITR changed frozen source/binary")
        result["source_binary_before_after_exact"] = True
    except Exception as error:
        post_errors.append({"check": "source_and_binary", "error_type": type(error).__name__, "error": str(error)})
    try:
        shared.disk(out, "after")
        result["post_df_and_owned_cache_check_passed"] = True
    except Exception as error:
        post_errors.append({"check": "disk_and_owned_cache", "error_type": type(error).__name__, "error": str(error)})
    result["post_execution_audit_errors"] = post_errors
    try:
        require(not post_errors, "post-execution resource/source audit failed")
        require(set(streams) == {"test.stdout", "test.stderr"}, "capture stream completeness")
        require(code == 0, "actual PITR test did not succeed")
        require(all(value["redactions"] == 0 and value["saved_is_raw"] is True for value in streams.values()), "PITR raw capture not byte-identical")
        require((out / "test.stderr").read_bytes() == b"", "unexpected PITR test stderr")
        marker = parse_marker((out / "test.stdout").read_bytes(), args.major)
        result.update(qualified=True, observer_exit_code=0, source_binary_before_after_exact=True,
            marker_field_count=15, marker=marker, exact_libtest_summary=[1, 0, 0, 0, 193],
            original_UUID_cleanup_verified=marker["resource_cleanup_verified"], no_wrapper_cleanup_performed=True,
            prerequisite_runs_terminal_before_resources=True, PostgreSQL16_then17_serial=True,
            actual_server_major=args.major, actual_server_version=marker["postgres"],
            scope="existing consumed child Join physical base-backup/WAL named restore point; no owner-stop-specific or Driver qualification")
    except Exception as error:
        result.update(observer_exit_code=1, error_type=type(error).__name__, error=str(error), original_actual_test_exit_retained=True)
    write(out, "observation.receipt.json", result)
    print(json.dumps({"major": args.major, "actual_test_exit_code": code, "observer_exit_code": result["observer_exit_code"], "qualified": result["qualified"]}), flush=True)
    return result["observer_exit_code"]


if __name__ == "__main__":
    sys.exit(main())
