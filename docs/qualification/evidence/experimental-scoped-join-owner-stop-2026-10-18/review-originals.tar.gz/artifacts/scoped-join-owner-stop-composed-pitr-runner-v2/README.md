# Root handoff: composed-v3 mandatory PITR

New version; v1 is preserved unchanged. Authoring only and not executed by the
author. `v2-v1.patch` contains the complete delta. No Cargo/build, source write,
pull or wrapper cleanup is introduced.

The exact target is composed-v3 source936 `21c32c…f7a44`, compiled544
`30d6c1…4de81`, Runtime194 binary `b28ccd…72354` and actual build receipt
`d13083…f9a2`. The v3 role-profile expected-schema correction has no qualification
effect on original failed v2 runs. New execution retains its own source/binary
identity.

Use the v1 six-row prerequisite structure with top-level source/input hashes set
to the exact v3 values. The four full Native rows may be actual v2 or v3 terminal
runs; the two mandatory logical-restore rows must use v3/b28ccd. Every row records
its actual source/input pair, terminal exit and pass/failure separately. A v2
failure remains failed; no prerequisite transfers qualification to v3.

```sh
python3 .local-verification/2026-10-18/scoped-join-owner-stop-composed-pitr-runner-v2/run-pitr.py \
  --major 16 --prerequisites ABSOLUTE_REAL_SIX_ROW_V3_TARGET_JSON \
  --out .local-verification/2026-10-18/scoped-join-owner-stop-composed-pitr-native-v2/pg16
```

Then run17 with the same prerequisite JSON, a new `pg17` output directory and
`--previous-pg16-receipt` pointing to the actual16 `test.receipt.json` from this
v2 runner. This binds the same v3 source/binary and forces serial resource runs.

The original strict15-field marker, exact1-pass/193-filtered result, workflow
image digests, no inherited database/other STATEKNOT environment, read-only image
inspection, original test operation limits/default stack, actual-exit-first raw
capture and post-run source/binary/df/cache checks remain unchanged. The wrapper
performs no external resource cleanup. The test alone owns/cleans its original
UUID resources and must attest manifest/WAL/named restore point, exclusion of a
later write, durable snapshot, replay, tenancy and cleanup. This existing consumed
Join PITR seam grants no owner-stop-specific restore, Driver, full CI or R1 status.
