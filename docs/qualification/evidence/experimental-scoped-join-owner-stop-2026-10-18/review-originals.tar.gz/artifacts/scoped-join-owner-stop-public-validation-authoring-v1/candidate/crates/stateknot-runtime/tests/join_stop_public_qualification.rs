// Copyright 2026 StateKnot contributors
// SPDX-License-Identifier: Apache-2.0

//! Opt-in external consumer of previously committed, independently seeded facts.
//! The runner supplies a fresh schema36 clone for upgrade and a completed v2
//! tracer database for schema validation. Neither test manufactures those facts.

use std::{path::PathBuf, time::Duration};

use serde_json::{Map, Value, json};
use sqlx_core::{query_as::query_as, query_scalar::query_scalar};
use sqlx_postgres::{PgConnectOptions, PgPool, PgPoolOptions, PgSslMode};
use stateknot_core::{Digest, GraphSchemaValidationError, SchemaReference};
use stateknot_runtime::{JsonSchemaRegistry, JsonSchemaRegistryBuilder};
use stateknot_store_postgres::{PostgresStore, PostgresStoreOptions, PostgresTransportSecurity};

const TABLES: &str = "SELECT quote_ident(c.relname) FROM pg_catalog.pg_class c JOIN pg_catalog.pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='stateknot' AND c.relkind IN ('r','p') ORDER BY c.relname";
const MIGRATIONS: &str = "SELECT COALESCE(jsonb_agg(to_jsonb(m) ORDER BY version),'[]'::jsonb)::text FROM public._sqlx_migrations m WHERE version<=$1";
const CLOSURES: &str = "SELECT tenant_id,run_id::text,closure_bytes,'sha256:'||encode(intent_digest,'hex') FROM stateknot.graph_frame_closures WHERE convert_from(closure_bytes,'UTF8')::jsonb->>'version'=$1 ORDER BY tenant_id,run_id";
const ROOTS: &str = "SELECT COALESCE(jsonb_agg(jsonb_build_object('tenant_id',c.tenant_id,'run_id',c.run_id::text,'closure_root_checkpoint_id',c.root_checkpoint_id::text,'run_checkpoint_id',r.checkpoint_id::text,'run_checkpoint_superstep',r.checkpoint_superstep,'run_checkpoint_digest',encode(r.checkpoint_digest,'hex'),'root_checkpoint_bytes',encode(p.checkpoint_bytes,'hex')) ORDER BY c.tenant_id,c.run_id),'[]'::jsonb)::text FROM stateknot.graph_frame_closures c JOIN stateknot.runs r ON r.tenant_id=c.tenant_id AND r.run_id=c.run_id JOIN stateknot.run_checkpoints p ON p.tenant_id=c.tenant_id AND p.run_id=c.run_id AND p.checkpoint_id=c.root_checkpoint_id";
type Closure = (String, String, Vec<u8>, String);

fn options() -> PostgresStoreOptions {
    PostgresStoreOptions::default()
        .with_transport_security(PostgresTransportSecurity::Disabled)
        .with_pool_size(1, 4)
        .with_transaction_timeouts(Duration::from_secs(5), Duration::from_secs(20))
}

fn input(name: &str) -> String {
    std::env::var(name).unwrap_or_else(|_| panic!("required qualification input {name} is absent"))
}

fn evidence(case: &str) -> PathBuf {
    let root = PathBuf::from(input("STATEKNOT_JOIN_STOP_EVIDENCE_DIR"));
    assert!(
        root.is_absolute(),
        "qualification evidence path must be absolute"
    );
    std::fs::create_dir_all(&root).unwrap();
    let path = root.join(case);
    std::fs::create_dir(&path).expect("use a fresh evidence directory for each execution");
    std::fs::write(
        path.join("queries.sql"),
        format!("-- table inventory\n{TABLES};\n-- full migration rows through bound version\n{MIGRATIONS};\n-- retained closure bytes at bound wire version\n{CLOSURES};\n-- exact Root pointer and checkpoint bytes\n{ROOTS};\n-- for each catalog-returned quoted table name\nSELECT COALESCE(jsonb_agg(to_jsonb(t) ORDER BY to_jsonb(t)::text),'[]'::jsonb)::text FROM stateknot.<quoted_table> t;\n"),
    )
    .unwrap();
    path
}

fn save(path: &std::path::Path, name: &str, value: &Value) {
    std::fs::write(path.join(name), serde_json::to_vec_pretty(value).unwrap()).unwrap();
}

async fn pool(url: &str) -> PgPool {
    let connect: PgConnectOptions = url
        .parse()
        .expect("qualification PostgreSQL URL must parse");
    assert!(matches!(
        connect.get_host(),
        "localhost" | "127.0.0.1" | "::1"
    ));
    PgPoolOptions::new()
        .max_connections(1)
        .connect_with(connect.ssl_mode(PgSslMode::Disable))
        .await
        .unwrap()
}

async fn migrations(pool: &PgPool, maximum: i64) -> Value {
    let raw: String = query_scalar(MIGRATIONS)
        .bind(maximum)
        .fetch_one(pool)
        .await
        .unwrap();
    serde_json::from_str(&raw).unwrap()
}

fn assert_migrations(value: &Value, maximum: i64) {
    let rows = value.as_array().unwrap();
    assert_eq!(rows.len(), usize::try_from(maximum).unwrap());
    for (row, version) in rows.iter().zip(1..=maximum) {
        assert_eq!(row["version"], json!(version));
        assert_eq!(row["success"], json!(true));
    }
}

async fn snapshot(pool: &PgPool) -> Value {
    let tables: Vec<String> = query_scalar(TABLES).fetch_all(pool).await.unwrap();
    assert!(!tables.is_empty(), "business table inventory is absent");
    let mut business = Map::new();
    let mut queries = Vec::new();
    for table in tables {
        // Each identifier is quote_ident output from this database's catalog.
        let sql = format!(
            "SELECT COALESCE(jsonb_agg(to_jsonb(t) ORDER BY to_jsonb(t)::text),'[]'::jsonb)::text FROM stateknot.{table} t"
        );
        let raw: String = query_scalar(&sql).fetch_one(pool).await.unwrap();
        let rows: Value = serde_json::from_str(&raw).unwrap();
        queries.push(sql);
        business.insert(
            table,
            json!({"row_count":rows.as_array().unwrap().len(),"rows":rows}),
        );
    }
    let roots: String = query_scalar(ROOTS).fetch_one(pool).await.unwrap();
    json!({"business_table_count":business.len(),"business_queries":queries,"business_tables":business,"roots":serde_json::from_str::<Value>(&roots).unwrap()})
}

fn registry(path: &std::path::Path) -> (SchemaReference, SchemaReference, JsonSchemaRegistry) {
    let legacy: Value =
        serde_json::from_str(include_str!("fixtures/join_stop_closure_schema_v1.json")).unwrap();
    let current: Value =
        serde_json::from_str(include_str!("fixtures/join_stop_closure_schema_v2.json")).unwrap();
    let (v1, v1_document) = PostgresStore::graph_frame_closure_event_schema().unwrap();
    let (v2, v2_document) = PostgresStore::graph_frame_join_stop_event_schema().unwrap();
    assert_eq!(v1_document, legacy);
    assert_eq!(v2_document, current);
    assert_eq!(
        v1.digest().to_string(),
        "sha256:453045e205133eb10d3cd58f0242ee2ebbd26dd78051b0888cd6a95f8a53e520"
    );
    assert_eq!(
        v2.digest().to_string(),
        "sha256:aec9b96de74a4185f288e1425a59a7fb8d8eb4363378bbd5522b2500a261ea5f"
    );
    for (reference, document, version) in [(&v1, &legacy, 1), (&v2, &current, 2)] {
        assert_eq!(
            reference.id().as_str(),
            format!("https://stknot.com/schemas/store/graph-frame-closure-event/{version}.0.0")
        );
        assert_eq!(
            reference.version(),
            stateknot_core::Version::new(version, 0, 0)
        );
        assert_eq!(
            reference.digest(),
            Digest::sha256(serde_json_canonicalizer::to_vec(document).unwrap())
        );
    }
    save(
        path,
        "public-schemas.json",
        &json!({"v1":{"reference":v1,"document":v1_document},"v2":{"reference":v2,"document":v2_document}}),
    );
    let mut builder = JsonSchemaRegistryBuilder::with_default_limits();
    builder.register(v1.clone(), legacy).unwrap();
    builder.register(v2.clone(), current).unwrap();
    (v1, v2, builder.build().unwrap())
}

async fn closures(pool: &PgPool, version: &str) -> Vec<Closure> {
    let records: Vec<Closure> = query_as(CLOSURES)
        .bind(version)
        .fetch_all(pool)
        .await
        .unwrap();
    assert_eq!(
        records.len(),
        1,
        "the exact seeded fixture closure is required"
    );
    records
}

async fn cold_read(
    url: &str,
    records: &[Closure],
    version: u8,
    reference: &SchemaReference,
    other: &SchemaReference,
    registry: &JsonSchemaRegistry,
) -> Vec<Value> {
    let store = PostgresStore::connect(url, options()).await.unwrap();
    let mut loaded = Vec::new();
    for (tenant, run, bytes, intent_digest) in records {
        let tenant = tenant.parse().unwrap();
        let run = run.parse().unwrap();
        let wire: Value = serde_json::from_slice(bytes).unwrap();
        assert_eq!(wire["version"], json!(version));
        assert_eq!(wire["intent"]["version"], json!(version));
        let closed = Box::pin(store.load_graph_frame_closure(&tenant, run))
            .await
            .unwrap()
            .expect("cold public owning reader must recover the seeded closure");
        let payload = closed.event().payload();
        assert_eq!(payload.schema(), reference);
        assert_eq!(
            payload.data().as_value()["intent_digest"],
            json!(intent_digest)
        );
        assert_eq!(
            payload.data().as_value()["frame_count"],
            json!(closed.completions().len())
        );
        registry
            .validate_bounded(reference, payload.data())
            .unwrap();
        assert!(matches!(
            registry.validate_bounded(other, payload.data()),
            Err(GraphSchemaValidationError::Rejected)
        ));
        assert_eq!(serde_json::to_value(closed.event()).unwrap(), wire["event"]);
        let checkpoint = Box::pin(store.load_current_checkpoint(&tenant, run))
            .await
            .unwrap()
            .expect("retained Root checkpoint is required");
        assert_eq!(
            serde_json::to_value(checkpoint.head()).unwrap(),
            wire["intent"]["root"]
        );
        assert!(
            Box::pin(store.load_active_graph_frame(&tenant, run))
                .await
                .unwrap()
                .is_none()
        );
        loaded.push(json!({"tenant_id":tenant,"run_id":run,"event":closed.event(),"compound_digest":closed.digest(),"root":checkpoint,"validated_payload":payload.data(),"closure_bytes_sha256":Digest::sha256(bytes)}));
    }
    store.close().await;
    loaded
}

#[tokio::test]
async fn persisted_v2_event_uses_the_public_offline_schema_and_cold_owning_reader() {
    let url = input("STATEKNOT_JOIN_STOP_V2_DATABASE_URL");
    let path = evidence("v2-schema");
    let pool = pool(&url).await;
    let before = snapshot(&pool).await;
    let ledger = migrations(&pool, i64::MAX).await;
    save(
        &path,
        "before.json",
        &json!({"snapshot":before,"migrations":ledger}),
    );
    assert_migrations(&ledger, 37);
    let records = closures(&pool, "2").await;
    let (v1, v2, registry) = registry(&path);
    let loaded = cold_read(&url, &records, 2, &v2, &v1, &registry).await;
    save(&path, "public-cold-read.json", &json!(loaded));
    let after = snapshot(&pool).await;
    let after_ledger = migrations(&pool, i64::MAX).await;
    save(
        &path,
        "after.json",
        &json!({"snapshot":after,"migrations":after_ledger}),
    );
    assert_eq!(before, after);
    assert_eq!(ledger, after_ledger);
    assert_eq!(closures(&pool, "2").await, records);
    pool.close().await;
}

#[tokio::test]
async fn sqlx_migrator37_preserves_retained_v1_bytes_and_cold_root_reads() {
    let url = input("STATEKNOT_JOIN_STOP_V1_UPGRADE_DATABASE_URL");
    let connect: PgConnectOptions = url
        .parse()
        .expect("qualification PostgreSQL URL must parse");
    assert!(
        connect
            .get_database()
            .is_some_and(|name| name.starts_with("stateknot_r1_joinstop37_upgrade_20261018_pg")),
        "upgrade requires a disposable task clone, never the retained schema36 seed"
    );
    let path = evidence("v1-upgrade");
    let pool = pool(&url).await;
    let before = snapshot(&pool).await;
    let ledger = migrations(&pool, i64::MAX).await;
    save(
        &path,
        "before.json",
        &json!({"snapshot":before,"migrations":ledger}),
    );
    assert_migrations(&ledger, 36);
    let records = closures(&pool, "1").await;
    assert_eq!(before["roots"].as_array().unwrap().len(), records.len());
    pool.close().await;

    // The public production method runs its embedded checksum-pinned SQLx
    // MIGRATOR, including exact post-migration schema verification.
    let migrated = PostgresStore::migrate_database(&url, options()).await;
    let pool = self::pool(&url).await;
    let after_migration = snapshot(&pool).await;
    let after_ledger = migrations(&pool, i64::MAX).await;
    save(
        &path,
        "after-migration.json",
        &json!({"snapshot":after_migration,"migrations":after_ledger,"migration_succeeded":migrated.is_ok()}),
    );
    migrated.expect("actual public SQLx MIGRATOR37 upgrade must succeed");
    assert_migrations(&after_ledger, 37);
    assert_eq!(migrations(&pool, 36).await, ledger);
    assert_eq!(before, after_migration);
    assert_eq!(closures(&pool, "1").await, records);
    let (v1, v2, registry) = registry(&path);
    let loaded = cold_read(&url, &records, 1, &v1, &v2, &registry).await;
    save(&path, "public-cold-read.json", &json!(loaded));
    let after_cold = snapshot(&pool).await;
    save(
        &path,
        "after-cold-read.json",
        &json!({"snapshot":after_cold,"migrations":migrations(&pool,i64::MAX).await}),
    );
    assert_eq!(before, after_cold);
    assert_eq!(closures(&pool, "1").await, records);
    assert_eq!(migrations(&pool, i64::MAX).await, after_ledger);
    pool.close().await;
}
