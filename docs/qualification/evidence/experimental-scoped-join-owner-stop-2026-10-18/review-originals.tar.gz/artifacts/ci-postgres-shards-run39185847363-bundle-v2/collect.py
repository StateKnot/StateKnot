#!/usr/bin/env python3
"""Root-only read-only collection from a prepare-bound run; no qualification."""
import sys
sys.dont_write_bytecode = True
import argparse
import concurrent.futures
import datetime
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import time
import zipfile

HERE = Path(__file__).resolve().parent
REPO = Path('/Users/jiawy/Documents/RustAgentFramework')
API = RUN = HEAD = BRANCH = CREATED = WORKFLOW_ID = None
sha = lambda b: hashlib.sha256(b).hexdigest()
utc = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()

def write(out, name, obj):
    p = out / name
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('x') as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
        f.write('\n')

def request(out, label, endpoint, suffix='.stdout'):
    if not endpoint.startswith(API + '/'):
        raise ValueError('unexpected endpoint')
    argv = ['gh', 'api', '--hostname', 'github.com', '--method', 'GET', endpoint]
    start, timer = utc(), time.monotonic()
    try:
        r = subprocess.run(argv, capture_output=True, timeout=55)
        code, raw, err = r.returncode, r.stdout, r.stderr
    except subprocess.TimeoutExpired as e:
        code, raw, err = 124, e.stdout or b'', e.stderr or b''
    p = out / (label + suffix)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('xb') as f:
        f.write(raw)
    with (out / (label + '.stderr')).open('xb') as f:
        f.write(err)
    write(out, label + '.receipt.json', {
        'argv': argv, 'actual_exit_code': code, 'started_utc': start,
        'observed_utc': utc(), 'seconds': time.monotonic() - timer,
        'stdout_path': p.relative_to(out).as_posix(), 'stdout_bytes': len(raw),
        'stdout_sha256': sha(raw), 'stderr_bytes': len(err), 'stderr_sha256': sha(err),
        'read_only': True,
    })
    if code:
        raise RuntimeError(f'{label}: gh exit {code}; inspect preserved stderr/stdout')
    return json.loads(raw) if suffix == '.stdout' else p

def paged(out, label, endpoint, key):
    rows, page, total = [], 1, None
    while True:
        data = request(out, f'{label}-page-{page}', endpoint + f'?per_page=100&page={page}')
        if total is None:
            total = data['total_count']
        if total != data['total_count']:
            raise ValueError(f'{label} total changed during pagination')
        rows.extend(data[key])
        if len(rows) == total:
            break
        if len(rows) > total or len(data[key]) != 100:
            raise ValueError(f'{label} incomplete pagination')
        page += 1
    if len({r['id'] for r in rows}) != len(rows):
        raise ValueError(f'{label} duplicate IDs')
    write(out, 'all-' + label + '.json', {'total_count': total, key: rows})
    return rows

def annotations(out, job):
    url = job['check_run_url']
    prefix = 'https://api.github.com/' + API + '/check-runs/'
    if not url.startswith(prefix):
        raise ValueError('unexpected check run URL')
    endpoint = url.removeprefix('https://api.github.com/') + '/annotations'
    page = 1
    while True:
        rows = request(out, f'annotations-{job["id"]}-page-{page}', endpoint + f'?per_page=100&page={page}')
        if len(rows) < 100:
            return
        page += 1

def extract(out, artifact, archive):
    digest = sha(archive.read_bytes())
    if artifact.get('digest') != 'sha256:' + digest:
        raise ValueError(f'artifact {artifact["id"]}: API/archive digest differs')
    folder = out / 'artifacts' / (str(artifact['id']) + '-' + re.sub(r'[^A-Za-z0-9_.-]', '_', artifact['name']))
    rows, seen = [], set()
    with zipfile.ZipFile(archive) as src:
        members = src.infolist()
        if sum(m.file_size for m in members) > 8 * 1024**3:
            raise ValueError('archive exceeds 8 GiB extraction limit')
        for m in members:
            p = PurePosixPath(m.filename)
            canonical = p.as_posix().rstrip('/')
            kind = stat.S_IFMT(m.external_attr >> 16)
            if (not p.parts or p.is_absolute() or '..' in p.parts or '\\' in m.filename or
                '\0' in m.filename or canonical in seen or kind not in (0, stat.S_IFREG, stat.S_IFDIR)):
                raise ValueError(f'unsafe archive member: {m.filename!r}')
            seen.add(canonical)
        folder.mkdir(parents=True, exist_ok=False)
        for m in members:
            target = folder.joinpath(*PurePosixPath(m.filename).parts)
            if m.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            data = src.read(m)
            with target.open('xb') as f:
                f.write(data)
            rows.append({'path': m.filename, 'bytes': len(data), 'sha256': sha(data)})
    write(out, 'artifact-files/' + str(artifact['id']) + '.json', {
        'artifact_id': artifact['id'], 'name': artifact['name'],
        'archive_sha256': digest, 'api_digest': artifact.get('digest'),
        'directory': folder.relative_to(out).as_posix(), 'files': rows,
    })

def download(out, artifact):
    binding = artifact['workflow_run']
    if (binding['id'], binding['head_sha']) != (RUN, HEAD) or artifact['expired']:
        raise ValueError('wrong or expired artifact binding')
    ident = str(artifact['id'])
    archive = request(out, 'archives/' + ident, API + '/actions/artifacts/' + ident + '/zip', '.zip')
    extract(out, artifact, archive)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bundle', type=Path, default=HERE)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    from common import load, verify_index, require
    verify_index(args.bundle, 'manifest.json')
    binding = load(args.bundle / 'binding.json')
    global API, RUN, HEAD, BRANCH, CREATED, WORKFLOW_ID
    API, RUN, HEAD, BRANCH, CREATED, WORKFLOW_ID = (binding[key] for key in
        ('api', 'run_id', 'head_sha', 'branch', 'created_at', 'workflow_id'))
    require(not args.out.exists(), 'collector output exists; preserve raw evidence and use a new version')
    require(not args.out.resolve().is_relative_to(args.bundle.resolve()), 'raw collection must be outside frozen bundle')
    out = args.out
    out.mkdir(parents=True, exist_ok=False)
    shutil.copyfile(__file__, out / 'collector-source.py')
    write(out, 'binding-reference.json', {'bundle_manifest_sha256': sha((args.bundle / 'manifest.json').read_bytes()),
          'binding_sha256': sha((args.bundle / 'binding.json').read_bytes()), 'run_id': RUN, 'head_sha': HEAD})
    errors = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        futures = {
            'run': pool.submit(request, out, 'run', API + '/actions/runs/' + str(RUN)),
            'jobs': pool.submit(paged, out, 'jobs', API + '/actions/runs/' + str(RUN) + '/jobs', 'jobs'),
            'artifacts': pool.submit(paged, out, 'artifacts', API + '/actions/runs/' + str(RUN) + '/artifacts', 'artifacts'),
        }
        result = {}
        for label, future in futures.items():
            try:
                result[label] = future.result()
            except Exception as e:
                errors.append(f'{label}: {e!r}')
    if errors:
        write(out, 'collection.receipt.json', {'collection_complete': False, 'errors': errors, 'observed_utc': utc()})
        print(json.dumps({'errors': errors, 'output': str(out)}), flush=True)
        return 1
    run, jobs, artifacts = result['run'], result['jobs'], result['artifacts']
    identity = (run['id'], run['head_sha'], run['head_branch'], run['workflow_id'], run['run_attempt'], run['event'], run['created_at'])
    expected = (RUN, HEAD, BRANCH, WORKFLOW_ID, 1, 'workflow_dispatch', CREATED)
    if identity != expected:
        raise ValueError(f'run identity mismatch: {identity!r}')
    for job in jobs:
        if (job['run_id'], job['head_sha'], job['run_attempt']) != (RUN, HEAD, 1):
            raise ValueError('job identity mismatch')
    summary = {
        'run_id': RUN, 'head_sha': HEAD, 'head_branch': BRANCH, 'run_attempt': 1,
        'observed_utc': utc(), 'run_status': run['status'], 'run_conclusion': run['conclusion'],
        'jobs': [{'id': j['id'], 'name': j['name'], 'status': j['status'], 'conclusion': j['conclusion'],
                  'started_at': j['started_at'], 'completed_at': j['completed_at'],
                  'failed_steps': [s['name'] for s in j.get('steps', []) if s['conclusion'] == 'failure']}
                 for j in jobs],
        'artifacts': [{'id': a['id'], 'name': a['name'], 'size_in_bytes': a['size_in_bytes'], 'digest': a.get('digest')} for a in artifacts],
    }
    require(len(jobs) == 21, 'exact full twenty-one job inventory required')
    terminal = run['status'] == 'completed' and all(j['status'] == 'completed' for j in jobs)
    print(json.dumps({'snapshot': {'run_id': RUN, 'head_sha': HEAD,
          'observed_utc': summary['observed_utc'], 'status': run['status'],
          'conclusion': run['conclusion'], 'job_count': len(jobs),
          'failed_jobs': [j for j in summary['jobs'] if j['conclusion'] == 'failure'],
          'completed_jobs': len([j for j in jobs if j['status'] == 'completed']),
          'artifact_count': len(artifacts)}, 'output': str(out)}, ensure_ascii=False), flush=True)
    if terminal:
        (out / 'before-download.df').write_bytes(subprocess.check_output(['df', '-k', str(REPO)]))
        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
            tasks = []
            for job in jobs:
                tasks.append(pool.submit(annotations, out, job))
                tasks.append(pool.submit(request, out, 'job-' + str(job['id']) + '-log', API + '/actions/jobs/' + str(job['id']) + '/logs', '.log'))
            for task in concurrent.futures.as_completed(tasks):
                try:
                    task.result()
                except Exception as e:
                    errors.append(repr(e))
        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
            tasks = {pool.submit(download, out, a): a for a in artifacts}
            for task in concurrent.futures.as_completed(tasks):
                try:
                    task.result()
                except Exception as e:
                    errors.append(f'artifact {tasks[task]["id"]}: {e!r}')
        (out / 'after-download.df').write_bytes(subprocess.check_output(['df', '-k', str(REPO)]))
    write(out, 'facts.json', summary)
    write(out, 'collection.receipt.json', {
        'run_id': RUN, 'head_sha': HEAD, 'observed_utc': utc(),
        'observed_status': run['status'], 'observed_conclusion': run['conclusion'],
        'job_count': len(jobs), 'artifact_index_count': len(artifacts), 'terminal': terminal,
        'collection_complete': not errors, 'errors': errors, 'read_only': True,
        'qualification_awarded': False,
    })
    files = [{'path': p.relative_to(out).as_posix(), 'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}
             for p in sorted(out.rglob('*')) if p.is_file()]
    write(out, 'files.json', {'count': len(files), 'files': files})
    print(json.dumps({**summary, 'collection_errors': errors, 'output': str(out)}, ensure_ascii=False), flush=True)
    return 1 if errors else 0

if __name__ == '__main__':
    raise SystemExit(main())
