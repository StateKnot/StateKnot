<!--
Copyright 2026 StateKnot contributors
SPDX-License-Identifier: Apache-2.0
-->

# 独立状态可恢复子 Run：事务存储与剩余运行时工作

状态：已实现核心契约、图内固定声明、只读准入准备，以及 PostgreSQL 原子归属/准入、预算预留、终态结算、带有界运行时协调器的可在中断后继续的取消传播和专用 Join 注册/发布/消费事务边界。
已接入显式启用的 Graph Driver 自动挂起/恢复、有界 Join 发布器和
[数据库时间驱动的到期取消](agent-deadlines.zh-CN.md)。
直接证据已结清的 Active 父级已支持[失败关闭](failure-close.zh-CN.md)。**完整配置验收仍未完成**；这里是可信宿主集成说明，不代表通用子 Run 服务已启用。完整设计与未决项见
[RFC-0004](rfcs/0004-durable-child-runs.md)。现有可用能力仍是
[共享状态静态子图](graph-composition.zh-CN.md)。另见
[英文说明](durable-child-runs.md)。

## 实验性的帧内独立子 Run

[RFC-0022](rfcs/0022-namespaced-graph-frames.md) 仍为 Draft。Core 使用完整恢复的
`GraphFrameCheckpoint` 调用 `ChildRunAdmissionIntent::for_frame` 和
`validate_for_frame`；Root 构造器及校验器继续拒绝 scoped 输入。准备结果不授予派发
或实际准入权限。

Store 的子准入和 Join 注册认证真实活动叶帧及其 ready 输入。Schema 预检查在同一个
一致快照中恢复作用域，回调在写事务之外执行；写入在既有树协调锁和祖先锁下重复
完整作用域、不可变父准入、声明目标、物理 Start、日志和有效 fence 校验。归属写入
及读取将现有 `parent_graph_namespace` 列绑定到该确切作用域；旧 Root 记录保留空
namespace 及原有规范编码。
新准入在完整归属读取之后先执行延迟组件约束，再复核原有效 Worker、父/子
截止时间和预留容量。约束校验期间租约或子级较窄的截止时间到期时，子 Run、归属、
预算预留和父日志一起回滚；父租约仍有效也不能绕过子级截止时间。

父 Run 的取消请求为精确的帧内子级 key 创建队列项。发现按租户隔离，投递保留
原父级观察和不可变子级回执。子级实际进入 Cancelled 后，相同 key 的重复投递仍
返回首次回执；旧子日志和新的候选事件/原因不会改写它，也不推进双方日志、帧、
Root checkpoint 或共享预留。投递表示请求取消；真实清理、终态计费和一次结算
仍由各自的步骤完成。

已准入 Root 必须具有子拓扑策略，叶帧只能收窄其三个上限；后代准入还保留每条原始
归属边的拓扑策略。各帧共享 Root 绑定的 `ChildRunBudgetAccount`，
`reserve_for_frame` 不创建新账户或重置生命周期计数。完整 DIRECT 排除子树消耗，
预留和结算只计费一次。历史归属在 Return 或关闭之后仍认证原始帧 lineage；丢失
ACK 时，原提交恢复先于新叶帧、fence 和 deadline 检查。Return 后恢复原 spawn
保留已结算账户和当前 Worker fence，不推进日志或重新预留。

Scoped Join 封闭该 activation 的完整子集，并原子释放 Run 租约。完整注册读取及
延迟约束之后，在同一个 Run 锁下再次核对原 epoch、原租约有效期和 Agent 截止时间；
到期则注册、日志和租约释放一起回滚。排他检查只排除
完整 stack 认证的挂起 framework caller，未完成的普通 sibling 仍会阻止注册。
发布要求真实的子 Run 终态结算；新 fence 下的 scoped 物理尝试必须将该精确 Join
绑定到不可变结果。发布和消费重试保留原身份，子树只结算一次；帧返回后仍能读取
原子 Run 归属及 Join。已释放的原 fence 不授予执行权限。

实验性 schema37 Store 可关闭这样一个已请求取消的帧栈：唯一最新的当前叶普通
owner 精确对应已注册、未发布的 Join，且整个 Root 绑定子账户中的子级均已终态并结算。
原物理尝试仍为 Executing，冻结完整已定价 DIRECT，并只累计一次已结算子树用量；
不创建普通结果/完成或 Join 发布/消费。完整 owning reader 认证 v2 stop proof，
并在 fresh 候选检查之前恢复原已提交决定。Fresh quarantine、未解决的 Tool/Model、
未定价用量、未结算子级或第二个未完成普通 owner 仍拒绝关闭；失败关闭继续使用
原有严格的未完成工作检查。

消费两版关闭事件时，须将 `PostgresStore::graph_frame_join_stop_event_schema()` 返回的
v2 reference/document 与原 `graph_frame_closure_event_schema()` 的 v1 文档一起注册到
离线 schema registry。部署须完成迁移37并使用匹配的 schema37 reader/writer 与
54表角色配置；既有 v1 字节和 digest domain 保留。
[选中 Store 资格记录](qualification/experimental-scoped-join-owner-stop-2026-10-18.zh-CN.md)
绑定实际源码、执行用例和剩余门禁。其他取消/失败分支、Root ConfirmCancellation、
嵌套 Driver 集成及完整故障/兼容/CI 验收仍须分别完成后才可声明 Supported；
在集成完成前 Driver 继续拒绝可达的 scoped 子 Run 声明。

## PostgreSQL 事务存储（迁移 20）

这是可信存储层构件，不是自动子 Run 协调器。调用前必须完成调用方认证，以及
对具体声明槽位的委派授权。数据库连接池属于可信服务端；事务自定义设置用于
阻止旧版本 Worker 绕过新约束，**不是对不可信 SQL 用户的安全隔离**。

`PostgresStore::admit_child_run` 接收准备好的意图、父节点确切的物理开始记录、
父级 Worker 日志（`child-run-admitted`）、独立子准入日志/初始 Checkpoint，
以及与父级当前日志头一致的**直接消耗绝对累计值**。Schema 回调在写事务之前执行；
事务内部按以下顺序完成：

1. 串行化整棵树的派生/结算，再按根到父的顺序锁定祖先 Run。
2. 重验当前 Checkpoint、就绪激活、未完成的物理开始记录、不可变准入/声明、
   活租约、所有祖先的 Active 状态、深度/活跃后代上限及累计预算。
3. 一次提交新的子准入、初始 Checkpoint、不可变归属和审计事实、预算预留及父日志头。

不能接管或挂接已经存在的独立 Run。同一归属和派生摘要的重试先恢复原始身份，
再决定是否需要新准入检查；不同业务意图冲突。最多保留 256 个生命周期子项，
深度最多 32；已终态但尚未结算的后代仍占用活跃容量。这些不是吞吐指标。

首个存储配置将父级外部调用与受管子工作串行化：未完成的父级 Model/Tool 调用
阻止派生；未结算子项阻止父级新的 Model/Tool 修订。结算后允许恢复直接调用。
`InvocationBudgetProvider` 必须返回只扣除父直接消耗的余额；执行器再扣减已结算
子树消耗，并将确切账户摘要带入开始事务。旧的底层开始接口不能绕过这一步。
响应丢失后的恢复不会重新派发或重复计费。

所有终态写入都经过统一的子级账务校验。新成功/失败/取消路径的
`GraphLifecycleEvidenceProvider` 返回**直接消耗**，生命周期协调器只加一次子树消耗。
底层终态写入者必须提供完整子树总额，或先对可信直接消耗调用 `include_child_usage`。
日志头 CAS 与最终事务会再次验证；子级的局部拓扑峰值不会累加到祖先。

子级进入终态时，在它自己的事务中保存不可变生命周期、确切终态日志锚点和持久化通知，
**不锁父级或祖先 Run**。后续审计日志不会替换此锚点。`settle_child_run` 按
“树 → 父 → 子”锁定，一次替换预算预留、提交父结算日志（`child-run-settled`）并消费通知。
重试恢复原始结算事件；已确认超额照实记录，价格不明则继续保留预留，不能记为零。

`pending_child_settlements` 返回第一页，最多 16 个有界 Key；
`pending_child_settlements_after` 用上一页最后的 Key 继续，游标在该子项结算后仍可用。
应跳过暂时无法定价的项继续扫描，完整一轮后从头重扫：事务提交顺序不保证等于事件时间。
不能把时间戳当作永久投递水位。`load_child_run` 与 `load_child_budget_account`
会核对规范编码、归属、父/图 Pin、物理节点、Checkpoint/日志锚点以及结算绑定。

任何未结算子项都会阻止父 Run 进入终态或推进 Checkpoint。这不会伪造 Join、
计时器或用户中断。祖先取消后禁止继续派生，迁移 21 与下述协调器负责可在中断后继续的取消投递。
迁移 22 提供下文的专用 Join 存储边界，运行时挂起/恢复现已显式接入；不能仅把存储接口暴露为完整的子 Run 执行服务。

升级时先通过现有 `PostgresStore::migrate_database` 流程执行迁移，再启动兼容 Worker。
迁移 20 会为已存在的、声明子级能力的准入回填版本 1，新准入同样受保护；
旧 Worker 无法更新这些 Run，普通根 Run 保持兼容。启动核对迁移校验和、
约束/索引/触发器以及实际守卫函数体。有子数据后的回退方式是停止新派生，
由兼容 Worker 完成取消/恢复/结算；不能删除迁移、归属、预留或禁用守卫。

## 取消请求持久化与有界协调（迁移 21）

父级每次进入 `CancellationRequested` 时，在**同一事务**内为每个未结算直属子项保存
不可变的取消队列证据。派生与取消争用父 Run 锁：子项先提交就必须进入取消队列，
取消先提交就拒绝派生。迁移 21 同时回填升级前已请求取消、仍有未结算子项的父级；
回填可以锚定后续审计日志，但不会把它谎称为原始取消事件。
迁移 20 的能力版本仍为 1，不改已有生命周期或 Checkpoint 编码；启动额外核对取消守卫与函数体。

`deliver_child_cancellation` 按“树 → 父 → 子”锁定，一次提交子级取消请求、
全部真实等待的清理、下一级后代通知及不可变回执，不递归锁整棵树。
同归属重试即使使用新候选事件 ID 或旧日志头，也恢复第一份回执。
子级已经请求取消或进入终态时，保留原始原因、结果和日志头。
投递**不等于外部操作已经停止**，不会直接确认子级终态或补造用量；
执行 Worker 仍须协作清理，外部效果不确定时保留未解决状态，等待真实证据。

尚有未结算子项的取消中父级，不进入可运行列表，也不能领取新的租约；
直接领取、强制接管和旧二进制同样受数据库守卫约束。
已持有的租约仍可续期、恢复丢失的领取回执以完成清理。
最后一个子项结算后，父级重新可领取，由正常取消流程确认终态。
这避免父级反复占用子级需要的执行槽位，**不是成功结果的 Join**。

每个已授权租户应在执行 Worker 之外运行 `DurableChildReconciler`。
在冻结部署 Schema 注册表之前，调用 `register_standard_child_reconciliation_event_schema`。
审计 Schema 内嵌、字段封闭、固定摘要且只离线加载；其 URL 是身份标识，不要求在线获取文档。
审计载荷只记录操作与归属摘要，不复制父级私密诊断。可编译调用示例见运行时类型的 Rust 文档，
用 `cargo test -p stateknot-runtime --doc --locked` 验证。

每次 `tick(tenant, cursor, shutdown)` 最多处理 **16 个取消项和 16 个结算项**。
必须检查所有 `items()` 的结果，并保留 `cursor()` 供下一次继续，单项出错也不例外。
失败、未定价或隔离项继续保留为待处理，但扫描会越过它们，让后面的正常项推进。
两条扫描各自在完整一轮后从头开始；协调器对象重建不丢可恢复工作。
进程重启后从 `None` 开始，不能把事件时间当永久水位；游标仅是租户绑定的进程内续扫位置。

重试有界，默认最多 3 次、初始退避 25 ms、单次退避最多 1 秒，
仅重试暂时性数据库错误及日志/生命周期 CAS 冲突。
停机可能发生在提交结果不确定时，后续读取恢复原始回执/结算，不重复收费。
队列发现失败会使整次 tick 返回错误，单项错误则逐项返回。
整次失败后从保留游标重试即可，之前已提交的事实不会丢失。
宿主负责调用频率、租户公平性、错误告警、最老待处理时长监控与经过认证的运维修复；
tick 之间不持有事务或租约。有界页大小不是吞吐量或恢复时延承诺。

验证覆盖 PostgreSQL 16/17、重复投递/派生取消竞争、回执末端失败回滚、真实定时等待清理、
三级逐级取消与自叶到根结算、重建/续扫越过整页未定价项、有数据的 v20 升级、
证据不可变以及守卫被替换/禁用后的启动拒绝。
自动到期取消已由独立维护器提供，见[接入指南](agent-deadlines.zh-CN.md)。
完整子 Run 执行配置仍需组合恢复、角色隔离和容量验收；失败关闭见[接入指南](failure-close.zh-CN.md)。
不得绕过守卫或把未知成本置零来强行关闭。

## 专用 Join 事务边界（迁移 22）

本节说明可信宿主的存储 API；下节说明已接入的 Driver 自动执行路径。
现有 `DurableChildReconciler` 仍只负责取消传播和预算结算，不会自动发布 Join。
使用低层接口的宿主必须安排发布扫描，注册后停止父级执行，校验子输出 Schema，
并把发布证据绑定到父结果。显式启用的 Driver 与独立 `DurableChildJoinPublisher` 现已负责这些操作。

`ChildRunJoinRequest::new` 固定同一逻辑激活的完整归属集合：非空、最多 64 个子级，
按大小写敏感的槽位顺序排序，不按完成时间排序。恢复时校验版本 1、激活摘要、
独立域摘要，拒绝重复、跨激活和非规范顺序。请求/绑定的规范编码上限为 4 MiB，
不复制子级输出。

1. `register_child_join(request, physical_start, worker_append)` 校验**全部已准入子级**、
   当前 Checkpoint、未完成的物理节点开始记录和有效租约，并排除同一租约下其他未完成
   节点及未结算的直接外部调用。按树 → 父 → 子加锁，将 `child-join-registered`、
   集合封存与父租约释放一次提交。此激活以后不能增加新子槽位。保留原物理尝试，
   不伪造失败、零用量完成、定时器或用户中断；调用方随后必须停止使用该租约执行。
2. 父级生命周期仍为 `Active`，另有专用 Join 等待条件。候选扫描和直接抢租约都会
   排除尚未发布的父级；子级使用各自租约。终态与完整定价结算沿用迁移 20/21，
   结算不等于 Join 发布或消费。
3. `pending_child_joins_after(tenant, cursor)` 每次最多返回 16 个成员全部结算的、
   未隔离且仍 Active 的父级。单项发布失败也应保留最后请求继续扫描；扫完或重启后
   从 `None` 重扫。完成行保留，因此游标在发布后仍有效。未知价格不会唤醒父级，
   被隔离或已取消的父级不发布。宿主负责有限重试、租户公平、逐项错误处理和周期；
   扫描不占有条目，并发发布者应处理幂等返回。
4. `publish_child_join(request, control_plane_append)` 按规范槽位顺序核实每个子级的
   准入、不可变终态生命周期/日志以及结算，将 `child-join-published`、完整绑定和
   调度唤醒一次提交。无论子级先完成还是父级先注册，都使用同一持久化条件；没有会
   丢信号的破坏性出队。发布不追加费用、不合并私有输出，不跨 Run 比较日志序号。
5. 宿主取得新租约并恢复逻辑激活后，用 `load_child_join` 读取证据，按固定 Schema
   校验子输出，计算自己的状态贡献；通过 `PendingNodeResultIntent::with_child_join`
   绑定确切的 `record.head()`。`succeed_node_attempt` 核实绑定并原子提交父结果、
   物理完成记录和唯一消费证据。缺失或替换绑定会被拒绝；丢失 ACK 的重试恢复原记录。
   读取、发布本身不消费父结果。

尚未消费的 Join 阻止 Checkpoint 推进和父级成功关闭，旧版本/低层写入也不能绕过。
取消可以越过成功等待条件，但仍必须排空并结算子级后才能确认；失败或取消的父级保留
未消费 Join 历史，不伪造成功消费。直接证据已结清时支持[失败关闭](failure-close.zh-CN.md)；到期取消与失败收口均由宿主独立调度维护器。

普通结果未带 `child_join` 时，既有编码和摘要不变；携带时该证据进入结果语义摘要。
已发布迁移 1–21 不变，迁移 22 不会把既有子级或结算自动转换为 Join 注册。
独立事务能力标志阻止旧二进制修改已注册 Join 的父级；启动校验精确字段、约束、
有效索引、启用的触发器和函数体。这些仍是可信连接池的混合版本守卫，不是 SQL 用户认证。

验证覆盖完整成员集合、兄弟逆序完成、并发注册/发布、终态与注册竞争、三处最终写入回滚、
丢失 ACK 恢复、独立租约下的真实子图成功、取消不伪造消费、跨未定价前缀的分页、
有数据的 v21 升级、目录/守卫篡改检测，以及重建注册表后复用已提交 Join 结果推进
非初始 Checkpoint。下述运行时测试进一步验证了执行器自动挂起与恢复。

## 显式启用 Graph Driver Join 与发布 Worker

冻结 Schema 注册表前调用 `register_standard_child_join_event_schema`。
内置 `child-join-event/1.0.0` 独立于已有 Driver/协调器 v1 协议，URL 只是离线身份；
审计只包含操作名和请求摘要，不包含子任务输出。

节点实现 `GraphNodeExecutor::supports_child_join() == true` 后启用 Join。
启动校验要求已声明的子槽位、精确 Join Schema 和 `Exclusive` 调度。
所有声明子级的执行器都必须独占，即使未启用 Join，也不能在兄弟节点仍执行时释放整条 Run 的租约。

首次派发时，可信节点按上文契约完成原子子准入，再返回
`GraphNodeExecution::child_join(ChildRunJoinRequest::new(keys)?)`。
Driver 原子封存成员和释放父租约，返回 `GraphDriveOutcome::ChildJoin` 或
`AgentLoopOutcome::ChildJoin` 后立即停止派发；原物理尝试仍未完成。
这不是 `NodeControl::Wait`，也不会生成失败或零消耗完成。ACK 丢失后用同一逻辑 Key
和不可变意图恢复原始子身份，不能因此再创建一个子 Run。

独立租约的执行 Worker 旁边要运行**两种**维护 Worker：
`DurableChildReconciler` 投递取消并完成定价结算；
`DurableChildJoinPublisher::tick(tenant, cursor, shutdown)` 每次发布最多 16 个已就绪 Join。
发布器复用有限重试配置（默认 3 次、25 ms 起步、1 s 上限），单项出错继续后续项，
完整一轮后自动重置租户绑定游标；保留返回游标，进程重启则从 `None` 重扫。
每个 item 的错误都必须检查。宿主负责租户认证、调度公平、告警和修复；
未知价格保持未结算，两种维护 Worker 都不猜用量、不执行节点或 Provider。
发布与取消由数据库事务协调。

发布后，更高 Fence 恢复同一逻辑激活。Driver 在派发前逐个验证所有终态绑定，
并按固定子图/Agent Schema 校验成功输出，不一次保留全部输出。
验证受租约续期、取消和节点执行截止时间共同约束；若派发前超时，返回
`ChildJoinPreparationIncomplete` 并保留未完成尝试，不伪造节点失败或消耗。

恢复时 `context.child_join()` 存在：`binding()` 保持规范槽位顺序；
`load_child(slot).await` 每次加载并重验一个已封存槽位，返回类型化 `RunLifecycle`，
保留成功 Agent 结果、失败或取消事实，不能读取未封存槽位或已隔离的子级。
新消费在父级之后锁定已终态的封存子项，与管理员隔离串行化；历史重放仍可读取。
上下文只保留紧凑证据，不建立 64 份输出缓存；单份输出遵循既有 Run 上限，调用方控制保留量。
读取错误必须按真实证据处理，不能变成成功的空结果。节点显式决定自己的状态贡献和常规控制，
没有自动合并子状态。

Driver 自动将精确发布头绑定到父 Pending Result，节点完成与唯一消费一次提交。
读取不消费；已发布 Join 再注册会被拒绝。完成前崩溃可能重新执行**父节点**，
因此外部副作用仍需使用现有持久化调用账本；完成后崩溃则复用已提交结果，不再执行节点。
生命周期提供直接消耗证据，存储层对子树费用只累计一次。

Pre-alpha 源码兼容性：`GraphNodeExecution::new(...)` 仍构造普通完成；
类型现为 `Completed { state_change, control, bindings, usage } | ChildJoin(...)` 枚举。
原来无条件的 getter 和 `into_parts()` 改用显式 match。此运行时接入不改变核心序列化结果、
已发布 Schema 或迁移 1–22。

真实数据库 `join::driver` 测试覆盖独立子级执行、连接/注册表重建、父成功与单次计费、
失败子级读取、重复 Join 拒绝、注册回滚后复用原派生、取消排空而不消费、发布错误/分页/重启，
预检后隔离同时阻止读取和新消费，以及证据读取阻塞不伪造节点完成。执行器与生命周期证据是确定性测试夹具，
**不是实时模型供应商或生产容量验收**。在隔离数据库配置
`STATEKNOT_REQUIRE_POSTGRES_TESTS=1` 和 `STATEKNOT_TEST_DATABASE_URL` 后运行：

```console
cargo test -p stateknot-runtime --test postgres --all-features --locked join::driver -- --test-threads=1
```

## 已实现的核心原语

运行离线示例：

```console
cargo run -p stateknot-core --example child_run_contracts --locked
```

示例验证合成 Checkpoint，构造并往返序列化 `ChildRunKey`，计算两个候选
分配后的剩余 Token，并拒绝超限的第三个分配。不会访问数据库或启动 Agent。

- `ChildRunSlot` 使用与 `NodeId` 相同的大小写敏感、最多 128 字节的语法。
  语法正确不等于已经在可执行图中声明。
- `ChildRunKey` 绑定完整父激活和槽位；更换物理尝试或租约不改变身份。
  反序列化拒绝未知字段并重新校验摘要。摘要不是授权证明或签名。
- `CumulativeBudgetReservation` 投影有限预算的全部累计维度，包括费用
  币种和 Token/调用子集。深度、并发、fan-out 等峰值及未知价格不得混入。
- `check_capacity` 校验“已结算用量 + 全部未结算分配 + 当前候选”，最多
  接受 256 项；重复项重复计入。该上限仅约束计算量，不是子 Run 派生上限。
  过期、未知费用、不受支持的币种及整数/金额溢出均拒绝继续。

上述核心原语是纯计算；下文 PostgreSQL 存储事务同时约束
父级直接开销与所有子级分配，绑定唯一归属、读取完整预留集合，并按真实
终态证据结算一次。绝不能把预留额写成已消费用量；子截止时间、权限、
祖先深度、活跃并发和 fan-out 仍需单独校验。

核心测试已覆盖身份和输入漂移、篡改、重试/接管稳定性、全部累计维度与
子集上限、费用未知、超限、溢出及顺序无关性。固定测试摘要为
`sha256:21da0ea8e1d1e20c7745a8a4f1794bffc6f42f7d62c24145db141c2dfb855a48`。
事务适配器已增加迁移 20；没有启用官网上的完整子 Run 能力声明。

## 已实现的预算账户状态转移

`ChildRunBudgetAccount` 是不可变的纯状态转移契约，**不是 PostgreSQL 账本，
也不是启动子 Run 的许可**。`new(parent, graph, direct_head, direct_usage)`
固定真实父准入、预算、图内生命周期子数上限和可信的直接用量观察，不会假定一个
已有 Run 尚未花费预算。恢复后通过 `validate_for` 重绑可信父准入与图；各项用量
是否完整、是否真实持久化，仍须存储适配器独立验证。

`reserve(intent, parent_graph, observed_at)` 重验节点声明，统一计算父级直接用量、
已结算子树和全部未结算预留。同逻辑归属与派生摘要的重试返回原先选定的子身份，
即使已经过期也不会重新分配；意图变化则冲突。不同归属不能复用同一子 Run ID。
已结算子项仍计入生命周期数量上限，不提供删除、循环复用或随意退款接口。

`ChildRunBudgetSettlement::new(admission, lifecycle, terminal_head)` 固定完整子身份、
准入与意图摘要、确切终态日志、状态、完整生命周期摘要及用量。只有成功、失败、
取消三种终态可结算。`settle(key, evidence)` 用真实用量替换一次预留；相同重试
不变，终态证据变化则冲突。失败和取消也照实计费。费用不明时保留未结算预留；
已确认超额或预算外币种则照实记账，后续容量检查阻止继续分配，绝不截断或抹掉
真实开销。截止时间已过不妨碍记录结算事实。

`observe_direct(head, usage)` 接受父级**直接消耗的绝对累计值**，不是增量，
也不能传入已经包含子树的总额。完全相同的重放不变；同日志头替换用量、旧日志头、
倒退时钟、其他 Run、任何计数或已知币种费用回退都被拒绝。直接消费超限或价格
不明时仍保留观察事实，但不能继续分配预算。

`accounted_usage` 只累加父直接用量和每个直属子 Run 的完整子树用量一次。
`delegated_usage` 通过 `BudgetUsage::cumulative_only` 排除子级局部深度、并发、
fan-out 峰值；子级峰值的最大值不能代表父级真实拓扑，后者仍由运行时单独观察
并强制约束。`remaining` 再加入全部未结算预留，要求时钟不早于保留的观察事实，
并检查溢出、过期、未知费用和额度。不能把投影余额当成实际消耗，也不能重复加孙级。

版本 `1` 的规范快照最多 256 个生命周期子项、8 MiB；读取数组时就检查数量，
适配器还须在解码前限制原始字节大小。账户按归属摘要排序，只用于账务完整性，
**不是 Join 归并顺序**。闭合编码重算摘要，域为
`stateknot.child-run-budget-account.v1\0`，后接将摘要字段设为 SHA-256(空字节)
的规范快照。终态摘要域为 `stateknot.child-run-budget-terminal.v1\0`，后接完整
生命周期规范编码。摘要只检测漂移，不是来源认证或授权。

数据库事务现已在父 Run 行锁下原子替换账户，并同步提交子归属、准入/结算；
父级直接调用开始时还会校验观察到的账户摘要。不能分别计算、分别保存快照。
账务结算不等于完成 Join，父 Run 仍需通过全部图完成和生命周期检查。

## 已实现的准入准备

### 固定在父图中的委派声明

```console
cargo run -p stateknot-core --example child_run_declarations --locked
```

通过 `CompiledGraph::with_child_runs(GraphChildRunPolicy)` 创建带委派声明的新图。
必须先声明，再绑定执行器、注册图和准入父 Run；修改已注册定义必须使用新的图身份/版本，
不能覆盖原有 Pin。没有声明的旧图不能委派，
但其原有规范编码和摘要保持不变。声明使用显式版本 `1`，拒绝未知版本和字段。

每个 `ChildRunDeclaration` 固定父节点、大小写敏感槽位、完整子 Agent 定义摘要、
子图以及输入/输出 Schema。`ChildAgentReference` 对完整规范化 Descriptor
使用域 `stateknot.child-agent-definition.v1\0` 计算摘要；即使 Agent 名称与版本
相同，指令、模型、工具或限制变化也会被识别。父声明只保存摘要，不复制私有指令。
摘要不是签名，也不能代替调用方授权。

每张图最多 256 个声明、每个节点最多 64 个槽位。规范顺序是 `(node_id, slot)`，
也是后续 Join 的归并顺序；传入顺序不改变图摘要。重复槽位、未知父节点、空声明、
超限和反序列化篡改均被拒绝；读取声明数组时即执行数量边界。

`ChildRunTopologyLimits` 明确限制：剩余后代深度 1–32、单 Run 生命周期内直属
子 Run 总数 1–256、同时未终结的全部后代数 1–256。叶子剩余深度为 0。
注册表在启动时解析全部目标，要求子图剩余深度严格小于父图；缺失目标或 Schema
漂移都会阻止启动。数据库现已原子检查活跃计数和每层祖先上限；已终态但尚未
结算的后代仍占用活跃容量。这些是安全边界，不是已经测得的吞吐承诺。

运行时两个准备接口都已校验父图声明；之前对未声明旧图的准备调用现在会拒绝。
需要注册带声明的新图并准入新父 Run，不能修改已经准入的旧图。底层核心调用方
必须同时执行 `validate_declaration` 和 `validate_for`；提交时的真实授权、租约、
余额与拓扑检查仍不能省略。

静态共享状态展开遇到委派声明会拒绝，不会丢失或重写归属；无调用的空展开则完整
保留原图。如需组合，先完成静态展开，再以最终节点身份声明独立子 Run。

### 不可变准备与重验

新增 `ChildRunAdmissionIntent`，保存父准入摘要、逻辑归属、候选子准入、
完整子图及私有初始状态。规范化信封最多 16 MiB，反序列化重新检查内部
作用域、图/Schema 引用、JSON 数值和摘要完整性。

`spawn_digest` 固定子 Agent 定义、图版本、输入、预算策略及解析结果、
授权证据、初始状态和就绪节点、父准入与槽位，以及 `cancel_and_join`
关闭策略。候选子 Run/thread/invocation ID 不进入重试摘要，但保留在信封
中并受子准入自身的摘要校验。仅更换这些 ID 不会被误判为另一项派生；
业务输入变化则产生不同摘要。此阶段不分配准入事件或初始 Checkpoint ID。

`ResolvedBudget::validate_narrowing` 检查全部预算维度、截止时间和币种
上限，不会默默截断。子主体必须与父主体一致，子 Scope 必须是父授予
范围的子集。这不等于所有 Scope 都可以转授：可信策略仍须授权具体
声明的槽位与子目标；首版不支持跨主体身份交换。

运行时 `DurableAgentAdmission::prepare_child` 接入冻结的可执行注册表，
`validate_child_preparation` 复核反序列化后的准备值。二者均为同步只读
方法，不创建 Run、租约、预留、日志或外部调用。方法的 Rust 文档包含
可编译用法，可通过 `cargo test -p stateknot-runtime --doc --locked` 验证。

检查包括：父快照 Active 且未隔离、当前 Checkpoint 指针一致、节点确实
就绪且激活输入由框架确定性派生、父准入完全匹配、父子可执行定义可用、
截止时间未过期，以及子输入/状态/授权证据通过本地 Schema。子状态可以
使用不同 Schema，不会隐式合并到父状态；同一 Run 的嵌套命名空间仍拒绝。

只读检查成功后仍可能发生取消或其他消费，不能当作持久化准入许可。存储
事务在锁内重验并检查活跃拓扑与全部预算预留；对已经提交的派生，
丢失响应后的证据查找必须先于新准入的截止时间和就绪检查。

新增真实 PostgreSQL 测试覆盖未创建子记录/未派发节点、候选 ID 重放、
注册表重建、Schema/部署拒绝、父取消后拒绝，以及 Graph Driver 提交真实
非初始 Checkpoint 后拒绝旧快照。这些不等于已经实现原子子 Run 执行。
固定派生测试摘要为
`sha256:64a2d833b22e3f017d502b4a1c30281ef44680c3c0a710399b1eec02c5d595b8`。

## 完整可恢复子 Run 的目标契约（尚未全部实现）

存储层子 Run 已拥有独立 Run ID、状态、Checkpoint、租约和终态证据。父子关系
单独持久化；子 Run 内仍使用自己的根命名空间，不冒充已经实现同一
Run 内的嵌套命名空间。

- 父逻辑激活和声明的子槽位共同确定唯一归属。工作进程重启、物理尝试
  变化或租约接管不能创建第二个子 Run。
- 子准入、初始 Checkpoint、归属和预算预留必须在同一事务提交。
  不采用先创建子 Run、再记录父子关系的两步流程。
- 父级等待通过持久化 Join 释放工作租约；子终态与等待注册竞态不能
  丢失唤醒。结果按照声明的槽位顺序归并，而不是完成时间顺序。
- 首版只支持“取消并等待终态”，不支持脱离父级的后台子 Run。
  父级关闭后禁止新派生；有未终结的受管子 Run 时禁止父级进入终态。
- 子权限不得扩大父级可委托权限，子截止时间不得晚于父级；并发预算
  必须先预留、后按准确用量结算，不能给每个子级重复分配同一余额。
- 无法确定的外部调用用量不能记为零；取消请求也不能被当作外部操作
  已经停止的证明。保留预算预留并暴露待恢复状态。

## 实施顺序与验收

1. 核心身份、声明、预算契约：严格反序列化、固定摘要、边界和篡改测试。
2. PostgreSQL 原子派生：归属唯一性、并发预算、响应丢失重试、过期租约
   拒绝，以及从迁移 19 升级到 20 的验证。
3. 生命周期：终态绑定、Join 唤醒、持久化取消传播、所有关闭路径的守卫，
   以及不重复结算。
4. Runtime：独立调度、挂起恢复、注册表重建和可执行示例。
5. PostgreSQL 16/17 故障恢复与完整 CI；通过后更新中英文教程和官网，
   再启用该能力。

必须覆盖派生提交前后、终态提交与通知之间、等待注册前后、结算提交后
响应丢失，以及更高租约接管等中断点。数据库层必须保护旧工作进程不能
绕过父级关闭约束；不能仅靠新的 Rust 接口维持安全性。

## 尚未冻结的决策

剩余工作是任意不确定直接副作用的恢复、完整配置验收和可测量的恢复/容量指标；直接证据已结清的失败关闭已实现。
到期取消、显式 Join 执行/发布/恢复、取消请求持久化与结算已实现。新增的
[成功 Join 进程丢失配置](child-join-process-qualification.zh-CN.md)使用 PostgreSQL-only
重建验证从 Admission 到终态重放的八个已提交边界，并验证保留旧 Worker 在更高 Epoch
恢复前被 Fence 拒绝。新增的
[Deadline Cancel-and-join 配置](deadline-join-process-qualification.zh-CN.md)验证从到期到
父取消终态重放的九个已提交边界，包括父子继承 Deadline 与首个取消原因保留。Join/
Deadline 的 [COMMIT 丢失配置](join-deadline-commit-loss-qualification.zh-CN.md)进一步验证
注册、发布、Deadline 取消三类事务的六格客户端故障矩阵。独立的
[子 Agent 准入 COMMIT 丢失配置](child-admission-commit-loss-qualification.zh-CN.md)验证子 Run
创建、归属、初始检查点、父审计与预算预留在未转发 COMMIT 时整体回滚，并在已提交响应
丢失时恢复原始身份。新增的
[子 Agent 取消投递 COMMIT 丢失配置](child-cancellation-commit-loss-qualification.zh-CN.md)
以同样两种切断验证取消传播、真实 Wait 废止、不可变 Receipt 恢复与后续结算。新增的
[子 Run 结算 COMMIT 丢失配置](child-settlement-commit-loss-qualification.zh-CN.md)
验证终态记账的原子性、原始事件恢复以及后续父级收口。独立的
[父 Run 终态收口 COMMIT 丢失配置](parent-finalization-commit-loss-qualification.zh-CN.md)
验证精确父级终态记账、原始事件恢复和唯一收口。新增的
[子 Run Join 结果消费 COMMIT 丢失验收](child-join-consumption-commit-loss-qualification.zh-CN.md)
验证结果、节点尝试与 Join 消费的原子性、原始事件恢复及非初始检查点重放。
数据库服务端故障、Provider 效果、容量和服务门禁仍未覆盖，因此不代表完整子 Run 服务可用；草案不会
作为完整已实现能力发布到官网状态页。
