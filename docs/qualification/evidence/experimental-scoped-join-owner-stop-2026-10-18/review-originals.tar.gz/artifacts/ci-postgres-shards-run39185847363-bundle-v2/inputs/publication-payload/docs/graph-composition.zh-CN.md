<!--
Copyright 2026 StateKnot contributors
SPDX-License-Identifier: Apache-2.0
-->

# 可恢复共享状态子图与有界循环

[English](graph-composition.md)

`SharedStateSubgraph`、`GraphSubgraphCall` 和 `GraphComposition` 实现静态共享状态组合。
编译结果是普通 `CompiledGraph`，通过 PostgreSQL-backed `DurableGraphDriver` /
`DurableAgentLoop` 执行。这是精确版本 `0.1.0-alpha.1` 公共预览中已实现的契约，
不代表独立子工作流或整个框架的生产资格验证已经完成。

## 运行仓库示例

```console
cargo run -p stateknot-runtime --example durable_graph_composition --locked
```

[完整示例](../crates/stateknot-runtime/examples/durable_graph_composition.rs) 构建 Schema、
Reducer、两个节点的审核子图、最多三次循环、明确的成功/耗尽出口，以及封闭的可执行注册表。
结果包含八个可执行节点，不调用数据库或模型服务。接纳运行时使用初始状态 `{"count":0}`，
示例的决策节点在计数达到二时接受。实际执行时，将注册表和可信的累计用量证据提供者接入
[可恢复 Agent Loop](durable-agent-loop.zh-CN.md)。
[PostgreSQL 测试](../crates/stateknot-runtime/tests/postgres/graph_composition.rs)
验证真实执行与恢复，没有内存执行后端作为替代。

## 定义返回契约

模板是有限无环的已编译图。其中纯 Terminal 节点是**符号返回端口**，不会执行代码。
返回端口不能同时声明 Continue、Route 或 Wait，也不能出现在入口集合中。
其他节点才是可执行节点，不能返回 Terminal Output。子图通过显式 State Update
传递结果，不会丢弃某个子节点的输出再假装返回成功。

父图的调用位置只声明 Route。默认情况下，每个子图返回端口对应一个同名父图 Route：
例如 `done` 对应 `done -> finish`，`again` 对应 `again -> exhausted`。

```rust,ignore
let subgraph = SharedStateSubgraph::new(body)?;
let call = GraphSubgraphCall::bounded_loop(
    NodeId::new("review")?,
    subgraph,
    NodeId::new("again")?,
    3,
)?;
let composition = GraphComposition::compile(parent, [call])?;
```

此片段依赖完整示例中的 `body`、`parent` 定义，不是独立程序。
`GraphSubgraphCall::once` 只实例化一次。多个调用位置复用相同模板时，父图的 Route ID
仍须全图唯一；使用 `with_return_routes` 显式映射，如 `done -> left.done`、
`again -> left.again`。映射必须完整且一一对应；重复、缺失、多余的端口或路线在接纳前拒绝。

## 循环与状态语义

- 循环采用先执行后判断的语义。每次进入该调用位置，最多执行声明的轮数。
  `again` 进入下一轮，其他返回端口立即退出。
- 最后一轮选择 `again` 时，执行对应的父图出口。这里必须放置真实的失败节点或明确的
  备用处理，耗尽不会隐式变成成功。外层循环可以重新进入调用位置，因此全图步数预算仍然必需。
- 子图的每个工作节点都有自己的持久化 Start、Result 和 Barrier。状态在每个 Barrier 后
  可见，不是等整个子图结束后才原子提交。父子图必须使用完全相同的 Input/State/Update/Output
  Schema Reference 和 Reducer Revision；没有私有子图状态，也没有隐式类型转换。
- 并行仍采用原有 BSP 语义：稳定排序的归约、去重的下一 Ready Set，不增加异步跨步 Join
  累加器。同一调用位置、同一轮内部保持模板的节点排序；跨作用域顺序由展开后节点 ID 决定。
- 子图 Wait 暂停整个所在 Run，并保留映射后的后继集合。等待解除并持久化后从该集合继续，
  不重复已完成子节点。取消作用于整个所在 Run。
- 已展开的无环图可以再次作为模板，实现静态嵌套；启动时展平，不引入递归运行时调用栈。

## 正确绑定执行身份

只注册 `composition.graph()` 作为可部署图，不注册用于编写结构的父图或符号返回节点。
对生成节点调用 `composition.node_source(node_id)`，可以得到精确模板引用、原始节点 ID、
调用位置和从零开始的轮次。构造普通 `GraphNodeExecutor` 时，绑定**组合后的图引用和节点 ID**。

Route ID 同样隔离。通过 `source.route_id(&local_route_id)` 取得生成后的 Route ID，
再返回 `NodeControl::Route`；直接返回模板中的原始 Route ID 会按未声明路线拒绝。
Reducer 收到的也是组合后节点 ID；归约逻辑应与角色名称无关，或者显式绑定不可变 Source Map
来查询源角色。

向可恢复调用代码原样传递真实 `GraphNodeContext`。不要伪造子 Checkpoint、将 Activation
替换成模板身份、或重置根 Superstep。Invocation Binding 始终指向实际 Tenant/Run/
Checkpoint/Activation，接管租约时也不改变逻辑身份。

## 资源、恢复与升级保证

完整展开最多包含 1,024 个可执行节点，每节点最多 256 条路线，规范化定义最多二 MiB。
分配前计算所有循环副本；超限直接拒绝，不退回不可持久化执行。大量且数据相关的迭代应使用
已有的普通循环图，并设置有限的全图步数预算。模板本身拒绝环，最长工作路径必须符合模板自己的
步数上限。父图并行上限不能高于任何子图模板的上限，其他同时就绪的父图节点也计入；这是无需
第二套调度器即可执行的保守限制。

生成节点 ID 格式为 `skc-<完整 SHA-256 作用域摘要>-<四位序号>`。作用域摘要基于 RFC 8785
JSON，包含域标识 `stateknot.graph-composition.v1`、完整父图及模板引用、调用位置、轮次、
最大轮数、重复端口和返回映射。序号来自模板规范节点排序，包括符号端口。
生成路线为 `skr-<完整 SHA-256>`，通过域标识 `stateknot.graph-composition.route.v1`
绑定生成节点和原始路线。

因此组合图摘要固定源版本、调用位置、循环上限及返回绑定。为在途运行保留编译器版本、所有源定义、
生成的 Source Map 和精确可执行产物。修改模板或组合方式需要新的图版本；旧版运行排空前不能移除
旧注册表条目。

本实现不修改 Checkpoint Wire，不需要新的 PostgreSQL Migration。空组合保留原始图字节。
恢复过程仍重放同一 Checkpoint Lineage，消费精确 Pending Result；只有 Start 而没有完成记录的
节点遵守原来的更高 Fence 接管规则。

Driver 在**派发新节点之前**检查 `maximum_supersteps`，重启后正好位于上限的情况也适用。
`GraphDriveBlockers::superstep_limit_reached` 进入生命周期失败处理。可信 `failure_evidence`
提供者必须恢复精确累计用量，即便当前 Checkpoint 没有失败节点记录。证据不可用就保持未完成，
不能猜测零用量。Lifecycle 记录 `runtime.graph.superstep_limit_reached` 并禁止重试；
原有事件 Schema 中的节点阻塞计数仍然只表示节点计数。保留的失败 Handoff 在响应丢失后可以
重复提交，不重新读取证据，也不替换原始终态失败。

独立的 [RFC-0022 草案](rfcs/0022-namespaced-graph-frames.md)实验已加入原始取消
或封存失败后的整栈 Store 关闭：保留根状态和 Caller 的实际旧 fence，冻结完整已定价
DIRECT 用量；除经过完整认证、仅用于取消的已注册未发布 Join owner
[处置](durable-child-runs.zh-CN.md#实验性的帧内独立子-run)外，仍拒绝未完成工作。
作用域 provider 调用验证实际帧身份；将 Root checkpoint 伪装为嵌套调用仍返回原有的
无效激活错误。整栈关闭最初加入 schema33；当前实验性源码要求完整迁移至37并使用
匹配的54表受信服务端角色配置。重试先完整认证已提交决定；不授予执行权限的清理可以在
执行截止期后完成。完成记录恢复与 Caller 锚点校验使用私有的堆上 Future 边界，使祖先
重放在普通线程栈上保留全部普通完成与关闭完成校验。实际嵌套 Driver 派发和最终完整验收
仍待完成。

[冻结实验性 whole-frame 限定验收](qualification/experimental-whole-frames-2026-10-10.zh-CN.md)
保留原 schema33 执行范围。独立的
[schema37 Store owner-stop 记录](qualification/experimental-scoped-join-owner-stop-2026-10-18.zh-CN.md)
不启用 scoped Driver Join，也不关闭完整故障/CI/R1 门禁。

私有 whole-return Wire Intent 在堆上解码，保留原始规范字节、摘要和全部认证，
避免 scoped 结果分页在多次 return 后扩大 Serde visitor 的栈占用。

实验性 claimed 读取接口现可通过 `ClaimedRunRecovery::plan_graph_frame_ready_nodes`
规划精确活动帧。有界结果分页使用完整 scoped head 与 namespace，复用已完成工作并保留
完整物理 Attempt 历史；每页固定 Run journal，规划器在最终数据库时钟与 fence 校验前
再次核对当前叶。终态叶允许没有 ready 节点。派发前仍须实际应用 schema/reducer 重放，
并通过专用的持久化 scoped start；规划结果本身不授予派发权限。
同一精确 checkpoint 下出现异 namespace 结果投影时，读取报告持久事实损坏；
claimed 恢复通过原 worker 上下文执行隔离。

[冻结 claimed 恢复限定验收](qualification/experimental-claimed-frame-recovery-2026-10-10.zh-CN.md)
记录精确 `8285f25` 源码、完整门禁、真实旧 return 只读兼容及保留失败。实际嵌套
Driver 和完整应用 replay 继续开放。

[Root disposition 恢复增量](rfcs/0022-namespaced-graph-frames.md#root-disposition-recovery-increment-in-development)
规定了正在开发的历史 Continue/Wait/Terminal 完整证明。新格式和迁移需要独立的最终源码验收；
无法证明原 disposition 的合法旧历史明确返回恢复不可用，不能通过推测或回填获得执行权限。

实验性 Store 提供 `PostgresStore::schedule_graph_frame_delayed_retry_wakeup`：
仅当精确活动叶的 ready 节点全部为 Completed 或 Deferred 时才能首次调度。
事务先锁 Run，完整认证活动栈和当前 Root/叶 head；在使用调用者 fence 重建历史前，
先验证真实活动租约。随后重读有界完整结果与物理 Attempt 历史，由 Core 按原计划的
观察时间重新推导原 SafeAfter 边界。调用者决策不一致属于无效输入，持久历史矛盾才是损坏。
最终写入再次使用数据库当前时间、精确 journal、worker Attempt、epoch 和 scoped head。

Root `schedule_delayed_retry_wakeup` 与 scoped 调度共用上述完整首次历史验证、已有延迟门和
Outcome。公开纯 Planner 不能虚构 Root 结果或替换已存 Failure 的 SafeAfter 策略来延后队列；
仅靠专用 Start 校验只能在 gate 到期后保护 launch。成功时释放租约，保留 Root 指针、叶/栈、
journal、队列年龄、不可变历史及原预算/deadline。慢 Run UPDATE 触发器导致租约过期时，
整个事务回滚；跨过 inclusive 重试边界时，通过 savepoint 撤回 gate 写入，重新核对原租约、
队列年龄、Root/叶和 journal，返回 `Due`。调用者需重新规划，并通过专用 scoped Start
获得新派发权限。远期 gate 不遮蔽独立 deadline 维护；取消清除 gate，并让清理工作进入队列。

`Idempotent` 仅在租约已释放后只读观察同一完整当前 scope、epoch、head、journal 与 gate。
它不授予 launch，也不证明已清除的原 worker Attempt 或完整原计划；不新增 wakeup Intent 表、
plan digest 或 timer。本增量仍属于 Store 实验契约，实际嵌套 Driver 与应用重放尚需独立完成。

## 验证与未覆盖边界

Core 测试覆盖确定性身份、冻结摘要、源节点排序、静态嵌套、返回转发、端口/路线/Schema/Reducer
拒绝及资源上限。真实 PostgreSQL 测试覆盖重建执行注册表后消费 Pending Result、提前退出、
显式耗尽、孤立 Attempt 接管、组合版本漂移时禁止派发、Wait/Resume，以及全图超限前停止派发，
包含证据不可用和响应丢失重试。CI 同时运行 PostgreSQL 16 与 17。

独立子状态、独立调度的子 Run、动态递归、独立子取消和异步跨步 Join 不在本 API 内。
这些能力需要单独的命名空间 Checkpoint/Lifecycle 契约，不能用静态组合冒充。

范围划分参考了 [LangGraph 子图通信](https://docs.langchain.com/oss/python/langgraph/use-subgraphs)
和 [Temporal 子工作流生命周期](https://docs.temporal.io/child-workflows)；上述编译与持久化语义
属于 StateKnot 自身的契约。

若需要判断一项能力应使用 Tool 集合、共享状态子图还是独立持久子 Run，请参考
[Skill 组合指南](skill-composition.zh-CN.md)。
