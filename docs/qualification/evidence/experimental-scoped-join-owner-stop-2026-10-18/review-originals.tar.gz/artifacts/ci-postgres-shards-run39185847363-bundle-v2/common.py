#!/usr/bin/env python3
"""Strict offline byte/JSON helpers. No subprocess or network dependencies."""
import hashlib
import json
from pathlib import Path, PurePosixPath


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def gitblob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()


def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'duplicate JSON key: ' + key)
        result[key] = value
    return result


def reject(value):
    raise ValueError('nonstandard JSON constant: ' + value)


def decode(raw):
    return json.loads(raw, object_pairs_hook=unique, parse_constant=reject)


def load(path):
    return decode(Path(path).read_bytes())


def canonical(obj):
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()


def inside(base, relative):
    require(type(relative) is str, 'relative path must be a string')
    part = PurePosixPath(relative)
    require(part.parts and not part.is_absolute() and '..' not in part.parts and '\\' not in relative and '\0' not in relative and part.as_posix() == relative, 'unsafe/noncanonical relative path: ' + repr(relative))
    base = Path(base)
    path = base.joinpath(*part.parts)
    require(base.is_dir() and not base.is_symlink(), 'missing/symlink input root')
    require(not any(p.is_symlink() for p in (path, *path.parents) if p.is_relative_to(base)), 'symlink evidence path')
    require(path.is_file() and path.resolve().is_relative_to(base.resolve()), 'missing/nonregular evidence file: ' + relative)
    return path


def rows_by_path(rows):
    require(type(rows) is list and all(type(r) is dict for r in rows), 'file rows shape')
    result = {}
    for row in rows:
        require(type(row['path']) is str and row['path'] not in result and type(row['bytes']) is int and row['bytes'] >= 0, 'duplicate/invalid file row')
        require(type(row['sha256']) is str and len(row['sha256']) == 64, 'invalid file digest')
        result[row['path']] = (row['bytes'], row['sha256'])
    return result


def verify_index(base, manifest='files.json'):
    data = load(base / manifest)
    require(data['count'] == len(data['files']), 'file index count')
    indexed = rows_by_path(data['files'])
    for relative, binding in indexed.items():
        raw = inside(base, relative).read_bytes()
        require((len(raw), sha(raw)) == binding, 'file index mismatch: ' + relative)
    require(not any(p.is_symlink() for p in base.rglob('*')), 'symlink in bundle')
    actual = {p.relative_to(base).as_posix() for p in base.rglob('*') if p.is_file()}
    require(actual == set(indexed) | {manifest}, 'unindexed/missing bundle file')
    return data


def saved_get(base, specification, expected_endpoint=None):
    """Validate a standard receipt or one command in Root's API-event journal."""
    stdout = inside(base, specification['stdout'])
    receipt_path = inside(base, specification['receipt'])
    receipt = load(receipt_path)
    if 'event_label' in specification:
        rows = receipt if type(receipt) is list else receipt['commands']
        matches = [r for r in rows if r['label'] == specification['event_label']]
        require(len(matches) == 1, 'missing/duplicate official GET event')
        receipt = matches[0]
    argv = receipt['argv']
    require(type(argv) is list and argv[:6] == ['gh', 'api', '--hostname', 'github.com', '--method', 'GET'] and (len(argv) == 7 or len(argv) == 11 and argv[6:10] == ['-H', 'Accept: application/vnd.github+json', '-H', 'X-GitHub-Api-Version: 2022-11-28']), 'official receipt must be one explicit gh api GET')
    endpoint = argv[-1]
    if expected_endpoint is not None:
        require(endpoint == expected_endpoint, 'wrong official GET endpoint: ' + endpoint)
    code = receipt['actual_exit_code'] if 'actual_exit_code' in receipt else receipt.get('actual_exit')
    require(code == 0 and receipt.get('timed_out', False) is False and receipt.get('execution_error') is None, 'failed/timed out official GET')
    require(receipt.get('read_only', True) is True, 'GET receipt not read-only')
    raw = stdout.read_bytes()
    require(sha(raw) == receipt['stdout_sha256'], 'official GET stdout digest')
    if 'stdout_bytes' in receipt:
        require(len(raw) == receipt['stdout_bytes'], 'official GET stdout length')
    if 'stderr' in specification:
        stderr = inside(base, specification['stderr']).read_bytes()
        require(sha(stderr) == receipt['stderr_sha256'] and ('stderr_bytes' not in receipt or len(stderr) == receipt['stderr_bytes']), 'official GET stderr digest')
    return decode(raw), endpoint


def complete_git_tree(value):
    """Verify every recursive entry and independently reconstruct its Git tree ID."""
    import re
    require(value['truncated'] is False and type(value['tree']) is list, 'recursive tree incomplete')
    rows = value['tree']
    require(len(rows) == len({r['path'] for r in rows}), 'duplicate full recursive tree path')
    by_path, leaves = {}, []
    for row in rows:
        relative = row['path']
        part = PurePosixPath(relative)
        require(part.parts and not part.is_absolute() and part.as_posix() == relative and '..' not in part.parts and '\\' not in relative and '\0' not in relative, 'unsafe Git tree path')
        require(re.fullmatch('[0-9a-f]{40}', row['sha']) is not None, 'invalid Git object identity')
        kind, mode = row['type'], row['mode']
        require((kind == 'tree' and mode == '040000') or (kind == 'blob' and mode in ('100644', '100755')), 'unsupported Git tree object/mode')
        normalized = {key: row[key] for key in ('path', 'mode', 'type', 'sha')}
        if kind == 'blob':
            require(type(row['size']) is int and row['size'] >= 0, 'blob size required')
            normalized['size'] = row['size']
            leaves.append(normalized)
        by_path[relative] = normalized
    nodes = {}
    for row in leaves:
        parts = row['path'].split('/')
        node = nodes
        for name in parts[:-1]:
            node = node.setdefault(name, {})
            require(type(node) is dict, 'Git blob/directory collision')
        require(parts[-1] not in node, 'Git blob/directory collision')
        node[parts[-1]] = (row['mode'], row['sha'])
    reconstructed = {}
    def visit(node, prefix):
        body = bytearray()
        for name in sorted(node, key=lambda n: n.encode() + (b'/' if type(node[n]) is dict else b'')):
            item = node[name]
            relative = prefix + name
            if type(item) is dict:
                mode, kind, ident = '040000', 'tree', visit(item, relative + '/')
            else:
                mode, ident = item
                kind = 'blob'
            body += (('40000' if mode == '040000' else mode) + ' ' + name).encode() + b'\0' + bytes.fromhex(ident)
            reconstructed[relative] = {'path': relative, 'mode': mode, 'type': kind, 'sha': ident}
        return hashlib.sha1(b'tree ' + str(len(body)).encode() + b'\0' + body).hexdigest()
    require(visit(nodes, '') == value['sha'], 'full recursive Git tree does not reconstruct official root')
    require({p: {k: row[k] for k in ('path', 'mode', 'type', 'sha')} for p, row in by_path.items()} == reconstructed, 'missing/extra/mismatched Git subtree entries')
    return by_path, {r['path']: r for r in leaves}


def publication_payloads(inputs, binding_identity):
    """Verify only actual frozen publication-plan bytes, never execute its scripts."""
    plan = inputs / 'publication-plan'
    prepared = load(plan / 'prepared.json')
    manifestraw = (plan / 'input-manifest.json').read_bytes()
    manifest = decode(manifestraw)
    require(sha(manifestraw) == prepared['input_manifest_sha256'] == '22698f1a6fe0f57fd32256369a4c38673e6a208e3636b829426e00ce44efa88f', 'immutable actual publication manifest')
    for name, digest in prepared['files'].items():
        require(sha(inside(plan, name).read_bytes()) == digest, 'immutable publication prepared bytes changed: ' + name)
    for key in ('parent', 'branch', 'tree'):
        require(prepared[key] == binding_identity[key], 'prepared/official identity differs: ' + key)
    require(prepared['commit'] == binding_identity['head_sha'], 'prepared/official commit differs')
    require(manifest['parent'] == prepared['parent'] and manifest['parent_tree'] == prepared['parent_tree'] and manifest['expected_tree'] == prepared['tree'], 'publication manifest parent/tree')
    require(manifest['pre_CI_product_source_count'] == prepared['pre_CI_product_source_count'] == 936 and manifest['pre_CI_product_source_sha256'] == prepared['pre_CI_product_source_sha256'] == '21c32c1446377a9691d63d835bb732b8d8cc6259e236c9cd0575dc13369f7a44', 'publication selected936 binding')
    require(manifest['compiled_count'] == prepared['compiled_count'] == 544 and manifest['compiled_inputs_sha256'] == prepared['compiled_inputs_sha256'] == '30d6c10fd88118297131a28c0e3b78420f51dec17206a718948a348c7424de81', 'publication compiled544 binding')
    rows = manifest['payload']
    require(manifest['payload_count'] == prepared['payload_count'] == len(rows) == 38 and len({r['path'] for r in rows}) == 38, 'exact38 publication payloads')
    request = load(plan / 'tree.request.json')
    require(request['base_tree'] == prepared['parent_tree'] and len(request['tree']) == 38 and len({r['path'] for r in request['tree']}) == 38, 'prepared38 tree request scope')
    requests = {r['path']: r for r in request['tree']}
    for row in rows:
        raw = inside(inputs / 'publication-payload', row['path']).read_bytes()
        require((len(raw), sha(raw), gitblob(raw)) == (row['bytes'], row['sha256'], row['sha']), 'actual38 payload SHA256/blob/size: ' + row['path'])
        require(row['type'] == 'blob' and row['mode'] in ('100644', '100755'), 'payload mode/type')
        require(requests[row['path']] == {'path': row['path'], 'mode': row['mode'], 'type': 'blob', 'content': raw.decode('utf-8')}, 'prepared request differs from38 exact payload bytes')
    return prepared, manifest, rows


def verify_full_publication(finaltree, parenttree, compare, payloads, expected_parent_tree):
    finalentries, finalblobs = complete_git_tree(finaltree)
    parententries, parentblobs = complete_git_tree(parenttree)
    require(parenttree['sha'] == expected_parent_tree == compare['base_commit']['commit']['tree']['sha'], 'official parent tree identity')
    require(len(finalblobs) == 4088, 'actual published complete4088 blob inventory')
    published = {r['path']: r for r in payloads}
    changed = {p for p in set(parentblobs) | set(finalblobs) if parentblobs.get(p) != finalblobs.get(p)}
    require(changed == set(published), 'full official tree delta differs from exact38 payloads (including deletion/extra/mode/size)')
    for path in set(parentblobs) | set(finalblobs):
        if path not in published:
            require(finalblobs.get(path) == parentblobs.get(path), 'extra source blob/type/mode/sha/size changed: ' + path)
            continue
        row = published[path]
        require(path in finalblobs and finalblobs[path] == {'path': path, 'mode': row['mode'], 'type': 'blob', 'sha': row['sha'], 'size': row['bytes']}, 'official changed blob differs from exact payload: ' + path)
        original = parentblobs.get(path)
        require(row['parent_sha'] == (original['sha'] if original else None), 'payload parent binding')
    files = compare['files']
    require(len(files) == len({r['filename'] for r in files}) == 38 and {r['filename'] for r in files} == changed, 'compare must contain exactly all38 actual changes')
    for row in files:
        require(row['sha'] == published[row['filename']]['sha'] and row['status'] == ('modified' if row['filename'] in parentblobs else 'added'), 'compare changed blob/status')
    return finalentries, finalblobs, parentblobs
