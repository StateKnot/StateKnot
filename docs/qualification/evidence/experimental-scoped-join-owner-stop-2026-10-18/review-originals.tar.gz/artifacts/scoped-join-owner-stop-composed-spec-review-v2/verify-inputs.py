from pathlib import Path
import datetime
import hashlib
import json
import subprocess

ROOT = Path('/Users/jiawy/Documents/RustAgentFramework')
BASE = ROOT / '.local-verification/2026-10-18'
OUT = BASE / 'scoped-join-owner-stop-composed-spec-review-v2'
Q1 = BASE / 'scoped-join-owner-stop-composed-qualification-v1'
Q2 = BASE / 'scoped-join-owner-stop-composed-qualification-v2'
S1 = BASE / 'scoped-join-owner-stop-composed-source-v1'
S2 = BASE / 'scoped-join-owner-stop-composed-source-v2'
FILE = 'crates/stateknot-runtime/tests/postgres/scoped_join_close_process_faults.rs'


def sha(data):
    return hashlib.sha256(data).hexdigest()


m1 = json.loads((Q1 / 'frozen-source-manifest.json').read_text())
m2 = json.loads((Q2 / 'frozen-source-manifest.json').read_text())
c2 = json.loads((Q2 / 'compiled-inputs.json').read_text())
assert m2['count'] == len(m2['files']) == 936
assert c2['count'] == len(c2['files']) == 544
assert m2['source_tree_sha256'] == 'e8f3b8a1c93cbbd8ad00fa3622657be032a98fc775ea9580337c27c1d8ad77db'
assert c2['sha256'] == 'acc2f7706a60201874a2dec4de5c690fcee4bf7a04409822bf409f72ca7f1c16'
paths1 = {row['path'] for row in m1['files']}
paths2 = {row['path'] for row in m2['files']}
assert paths1 == paths2
changed = []
for row in m2['files']:
    data = (S2 / row['path']).read_bytes()
    assert len(data) == row['bytes'] and sha(data) == row['sha256'], row['path']
    if data != (S1 / row['path']).read_bytes():
        changed.append(row['path'])
assert changed == [FILE], changed
for row in c2['files']:
    data = (S2 / row['path']).read_bytes()
    assert len(data) == row['bytes'] and sha(data) == row['sha256'], row['path']
assert sha((S2 / FILE).read_bytes()) == '9696ae03eb856d5adc1173adf4ee1171af77fdd3418788cf113f4ecf9b0d50ec'
assert sha((Q2 / 'v2-v1.patch').read_bytes()) == '1437231e549fcf9fff41c8db61c5c4172f95a4826d71738e69110e63bcffb7c2'

a = (S1 / FILE).read_text()
b = (S2 / FILE).read_text()
test = 'async fn registered_scoped_join_close_lost_commit_ack_survives_real_kill_and_cold_retry() {\n'
_, original_test = a.split(test)
_, extracted_test = b.split(test)
front, original_tail = original_test.split('    let pool = PgPoolOptions::new()', 1)
assert extracted_test == front + '    Box::pin(run_controller(&store, connection.as_ref().unwrap())).await;\n    store.close().await;\n}\n'
assert b.startswith(a[:a.index('#[tokio::test]\n' + test)])
controller = b.split('async fn run_controller(store: &PostgresStore, connection: &PgConnectOptions) {\n', 1)[1].split('\n}\n\n#[tokio::test]', 1)[0]
emitter = b.split('async fn emit_evidence(', 1)[1].split(') {\n', 1)[1].split('\n}\n\nasync fn run_controller', 1)[0]
emitter = emitter.replace('.fetch_one(pool)', '.fetch_one(&pool)').replace('Digest::sha256(original_bytes)', 'Digest::sha256(&original_bytes)')
reconstructed = controller.replace('prepare(store)', 'prepare(&store)').replace('owning_close(store,', 'owning_close(&store,').replace('        connection,\n', '        connection.as_ref().unwrap(),\n').replace('    emit_evidence(&pool, &original, &original_bytes, &killed).await;', emitter)
original = '    let pool = PgPoolOptions::new()' + original_tail.split('    store.close().await;', 1)[0].rstrip('\n')
assert original == reconstructed

inputs = [Q1 / 'frozen-source-manifest.json', Q2 / 'frozen-source-manifest.json', Q2 / 'compiled-inputs.json', Q2 / 'v2-v1.patch', S1 / FILE, S2 / FILE, OUT / 'report.md', Path(__file__)]
receipt = {
    'axis': 'Spec',
    'review': 'bounded immutable v1-to-v2 mechanical extraction delta',
    'actionable_findings': 0,
    'worst_issue': None,
    'verified_source_files': 936,
    'verified_compiled_files': 544,
    'unchanged_source_files': 935,
    'changed_paths': changed,
    'early_worker_mutex_loopback_test_store_order_exact': True,
    'all_preexisting_worker_helper_bytes_unchanged': True,
    'original_controller_reconstructed_byte_exact_with_only_reference_parameter_normalization': True,
    'build_lint_db_docker_network_executed': False,
    'Native_six_gates_CI_R1_not_awarded': True,
    'main_head_after': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'main_status_after': subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True),
    'timestamp_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'input_artifacts': [{'path': str(p), 'bytes': len(p.read_bytes()), 'sha256': sha(p.read_bytes())} for p in inputs],
}
(OUT / 'source-sha256-receipts.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'findings': 0, 'unchanged_source_files': 935, 'source_files': 936, 'compiled_files': 544, 'report_sha256': sha((OUT / 'report.md').read_bytes()), 'receipt_sha256': sha((OUT / 'source-sha256-receipts.json').read_bytes()), 'main_clean': receipt['main_status_after'] == ''}, indent=2))
