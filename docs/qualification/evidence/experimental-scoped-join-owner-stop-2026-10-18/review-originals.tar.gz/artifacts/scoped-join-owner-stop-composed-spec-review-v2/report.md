# Spec delta review

**Actionable findings: 0. Worst issue: none identified.**

The bounded v1→v2 change affects only
`crates/stateknot-runtime/tests/postgres/scoped_join_close_process_faults.rs`
(`9696ae03eb856d5adc1173adf4ee1171af77fdd3418788cf113f4ecf9b0d50ec`).
All other 935 frozen source files are byte-identical. The complete v1 Spec review
continues to apply to those unchanged inputs.

The selected RFC requires authentic committed-original recovery and separate
qualification of process replacement. The extraction preserves the exact early
worker-role return, database mutex, URL/loopback validation and conditional
`test_store` ordering. The previous worker/helper bytes are unchanged.

Expanding the extracted evidence emitter and normalizing only the explicit
reference parameters reconstructs the original controller byte-for-byte. All
assertions, limits, marker contents, COMMIT response cut, independent durable
read, owned live writer kill/reap, backend disconnect wait, separate cold-process
ACK recovery and tenant/closure byte comparisons therefore retain their order.
The test wrapper continues holding the Store and mutex across the controller.
The controller owns the same process/proxy handles; it stops/reaps or successfully
waits for them before returning. No process becomes unowned, and the evidence
continues to state public-Store-only with `driver_exercised=false`.

Verified v2 source tree:
`e8f3b8a1c93cbbd8ad00fa3622657be032a98fc775ea9580337c27c1d8ad77db`
(936 files); compiled inputs:
`acc2f7706a60201874a2dec4de5c690fcee4bf7a04409822bf409f72ca7f1c16`
(544 files). Delta patch:
`1437231e549fcf9fff41c8db61c5c4172f95a4826d71738e69110e63bcffb7c2`.

This is read-only static Spec delta verification, not compilation, lint, Native,
database, fault execution, six-gate, full-CI or R1 qualification. Frozen sources
and the primary working tree were not edited.
