# Independent audit of saved public-consumer evidence

All four saved executions satisfy their narrow evidence contract. This audit performed file reads/hash/JSON checks only; it ran no build, database, Docker, network or consumer command.

The consumer freeze is 938 files / 546 compiled inputs: source `5d77326d5cce4988506b7acb549cedb37eba5be62c14b857502736eeffaa806d`, compiled `625def171e1b8f43de7bff2a55115a29d7751f7c5d44dde07081a28007aa35c5`. All original 935 Green files and 543 product inputs are byte-identical; only the integration test and its two schema fixtures were added. Cargo.lock remains `fc36c3966dc2abf990fae6a01b633459d95fedae0fd7f77c429b5f04447b2e94`.

The saved Cargo metadata/build exits are both0, locked/offline. Raw compiler JSON confirms four selected product/test artifacts `fresh:false`, features `[]`, opt1, debug0, debug assertions/overflow checks enabled; no stack/compiler overrides. Binary `7c174940e83c9435e66ed7675b5faba4af3c8302c79732a648553b609350b30b` has exactly two inventory cases. The reused cache's missing TAG is recorded; no cleanup is claimed.

| PG | Saved case | Actual result | Complete snapshot |
| --- | --- | --- | --- |
|16|v2 schema/cold read|exit0;1 passed,1 filtered;0 redactions|54 tables;19 nonempty;37 rows;11 events;one closure|
|17|v2 schema/cold read|exit0;1 passed,1 filtered;0 redactions|54 tables;19 nonempty;37 rows;11 events;one closure|
|16|retained v1 migration/cold read|exit0;1 passed,1 filtered;0 redactions|54 tables;12 nonempty;18 rows;five events;one closure|
|17|retained v1 migration/cold read|exit0;1 passed,1 filtered;0 redactions|54 tables;12 nonempty;18 rows;five events;one closure|

Raw receipt/output hashes match. Each v2 before/after snapshot and ledger is exact. Each v1 upgrade has actual complete successful rows1..36→1..37, every original migration row unchanged (including checksum/installed time/execution time), new37 SHA384 matching embedded SQL37, and identical full business/closure/Root snapshots before migration, after migration and after fresh public cold reads. Recorded source seeds remain36; migration runs used disposable clones. All saved durability settings remain on and container/settings records match.

Both public getter documents match their fixture/reference/URI/version and canonical SHA256 identities: v1 `453045e2…53e520`, v2 `aec9b96d…61ea5f`. Each cold event equals its persisted closure and raw event payload/schema; Root checkpoint bytes/pointers and closure checksum, versioned intent and compound digests independently match. The passed compiled tests execute production offline-registry validation and opposite-version refusal. No missing-event or empty-snapshot success is possible in these records.

Exact per-case receipt, snapshot, Root/closure byte hashes and all relevant source/log hashes are in `facts.json`. These four cases do not confer full CI, scoped Driver, ConfirmCancellation, complete fault/negative/compatibility, production or R1 qualification, and do not qualify the separate ACK candidate.
