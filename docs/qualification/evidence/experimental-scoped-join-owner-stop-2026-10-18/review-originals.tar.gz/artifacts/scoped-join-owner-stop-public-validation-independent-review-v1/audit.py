from pathlib import Path
import hashlib
import json
import re
import subprocess

OUT = Path(__file__).resolve().parent
DAY = OUT.parent
REPO = DAY.parents[1]
NATIVE = DAY / 'scoped-join-owner-stop-public-validation-native-v1'
BUILD = NATIVE / 'build-consumer-v1'
QUAL = DAY / 'scoped-join-owner-stop-public-validation-qualification-v1'
GREEN = DAY / 'scoped-join-owner-stop-green-qualification-v1'
SOURCE = DAY / 'scoped-join-owner-stop-public-validation-source-v1'
AUTHOR = DAY / 'scoped-join-owner-stop-public-validation-authoring-v1'
SHA_ROWS = {}


def sha(path):
    path = Path(path)
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    SHA_ROWS[str(path.relative_to(REPO))] = digest
    return digest


def load(path):
    sha(path)
    return json.loads(Path(path).read_bytes())


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()


def value_sha(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def bytea(value):
    assert value.startswith('\\x')
    return bytes.fromhex(value[2:])


def source_manifest(directory, path, compiled=False):
    value = load(path)
    key = 'sha256' if compiled else 'source_tree_sha256'
    assert value['count'] == len(value['files'])
    assert value_sha(value['files']) == value[key]
    rows = {item['path']: item for item in value['files']}
    assert len(rows) == value['count']
    for name, row in rows.items():
        actual = directory / name
        assert not actual.is_symlink()
        assert actual.stat().st_size == row['bytes'] and sha(actual) == row['sha256'], name
    if not compiled:
        assert {p.relative_to(directory).as_posix() for p in directory.rglob('*') if p.is_file()} == rows.keys()
    return value, rows


def check_ledger(rows, maximum):
    assert len(rows) == maximum
    assert [row['version'] for row in rows] == list(range(1, maximum + 1))
    for row in rows:
        assert row['success'] is True
        files = list((SOURCE / 'crates/stateknot-store-postgres/migrations').glob(f'{row["version"]:04}_*.sql'))
        assert len(files) == 1
        assert bytea(row['checksum']) == hashlib.sha384(files[0].read_bytes()).digest()


manifest, rows = source_manifest(SOURCE, QUAL / 'frozen-source-manifest.json')
compiled, compiled_rows = source_manifest(SOURCE, QUAL / 'compiled-inputs.json', True)
green_manifest = load(GREEN / 'frozen-source-manifest.json')
green_compiled = load(GREEN / 'compiled-inputs.json')
assert manifest['count'] == 938 and compiled['count'] == 546
assert green_manifest['count'] == 935 and green_compiled['count'] == 543
assert all(rows[row['path']] == row for row in green_manifest['files'])
assert all(compiled_rows[row['path']] == row for row in green_compiled['files'])
assert all(rows[name] == row for name, row in compiled_rows.items())
extras = sorted(rows.keys() - {row['path'] for row in green_manifest['files']})
assert extras == sorted(item['path'] for item in load(AUTHOR / 'manifest.json')['candidate_files'])
assert all(sha(AUTHOR / 'candidate' / name) == rows[name]['sha256'] for name in extras)
scope = load(QUAL / 'scope.json')
assert scope['source_tree_sha256'] == manifest['source_tree_sha256']
assert scope['compiled_inputs_sha256'] == compiled['sha256']
assert scope['base_product_source_tree_sha256'] == green_manifest['source_tree_sha256']
assert scope['base_product_compiled_inputs_sha256'] == green_compiled['sha256']
assert scope['author_manifest_sha256'] == sha(AUTHOR / 'manifest.json')

build = load(BUILD / 'build.receipt.json')
summary = load(BUILD / 'build-summary.json')
metadata = load(BUILD / 'metadata.receipt.json')
freshness = load(BUILD / 'freshness.json')
artifacts = load(BUILD / 'compiler-artifacts.json')
assert build['exit_code'] == metadata['actual_exit_code'] == summary['inventory_exit_code'] == 0
assert summary['build_receipt_sha256'] == sha(BUILD / 'build.receipt.json')
assert summary['all_compiler_artifacts_sha256'] == sha(BUILD / 'compiler-artifacts.json')
assert build['source_manifest_sha256'] == sha(QUAL / 'frozen-source-manifest.json')
assert build['compiled_manifest_sha256'] == sha(QUAL / 'compiled-inputs.json')
assert build['stdout_sha256'] == sha(BUILD / 'build.jsonl')
assert build['stderr_sha256'] == sha(BUILD / 'build.stderr')
assert metadata['stdout_sha256'] == sha(BUILD / 'metadata.stdout')
assert metadata['stderr_sha256'] == sha(BUILD / 'metadata.stderr')
assert '--locked' in build['argv'] and '--offline' in build['argv'] and '--no-run' in build['argv']
assert not any(arg in build['argv'] for arg in ['--features', '--all-features', '--no-default-features', '--workspace'])
assert not any(build['overrides_present'].values()) and not build['DEV_OPT_LEVEL_override_present']
assert build['source_before_after_exact'] is True
assert build['freshness_sha256'] == sha(BUILD / 'freshness.json')
assert freshness['all546_bytes_unchanged'] and freshness['all546_mtimes_after_previous_compile']
assert len(freshness['files']) == 546
assert {row['path']: row['sha256'] for row in freshness['files']} == {path: row['sha256'] for path, row in compiled_rows.items()}
assert all(row['after_mtime_ns'] > freshness['previous_compile_end_unix_ns'] for row in freshness['files'])
assert sha(freshness['previous_compile_receipt']) == freshness['previous_compile_receipt_sha256']
expected_env = {
    'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_DEV_DEBUG': '0', 'CARGO_PROFILE_TEST_DEBUG': '0',
    'CARGO_PROFILE_TEST_OPT_LEVEL': '1', 'CARGO_PROFILE_TEST_DEBUG_ASSERTIONS': 'true',
    'CARGO_PROFILE_TEST_OVERFLOW_CHECKS': 'true', 'RUSTFLAGS': '-D warnings', 'RUSTDOCFLAGS': '-D warnings',
    'CARGO_TARGET_DIR': str(REPO / 'target/r1-oct15-native-opt1'),
}
assert build['environment_allowlist'] == expected_env
messages = [json.loads(line) for line in (BUILD / 'build.jsonl').read_text().splitlines()]
assert [message for message in messages if message.get('reason') == 'compiler-artifact'] == artifacts
assert [message['success'] for message in messages if message.get('reason') == 'build-finished'] == [True]
selected = [message for message in artifacts if message['target']['name'] in
            ('stateknot_core', 'stateknot_store_postgres', 'stateknot_runtime', 'join_stop_public_qualification')]
assert len(selected) == 4 and selected == summary['selected_artifacts_all_fresh_false']
for item in selected:
    assert item['fresh'] is False and item['features'] == []
    assert item['profile'] == {'opt_level':'1','debuginfo':0,'debug_assertions':True,'overflow_checks':True,'test':item['target']['kind'] == ['test']}
    assert item['manifest_path'].startswith(str(SOURCE) + '/')
binary = Path(summary['saved_executable'])
assert sha(binary) == summary['binary_sha256'] == '7c174940e83c9435e66ed7675b5faba4af3c8302c79732a648553b609350b30b'
assert binary.stat().st_size == summary['binary_bytes'] == 22532288
inventory = (BUILD / 'inventory.stdout').read_text()
names = re.findall(r'^(.+): test$', inventory, re.M)
assert len(names) == len(set(names)) == summary['inventory_count'] == 2
assert sha(BUILD / 'inventory.stdout') == summary['inventory_sha256']
assert sha(DAY / 'scoped-join-owner-stop-public-validation-native-runner-v1/build.py') == build['runner_sha256']

schema_expected = {
    'v1': {'id':'https://stknot.com/schemas/store/graph-frame-closure-event/1.0.0','version':'1.0.0','digest':'sha256:453045e205133eb10d3cd58f0242ee2ebbd26dd78051b0888cd6a95f8a53e520'},
    'v2': {'id':'https://stknot.com/schemas/store/graph-frame-closure-event/2.0.0','version':'2.0.0','digest':'sha256:aec9b96de74a4185f288e1425a59a7fb8d8eb4363378bbd5522b2500a261ea5f'},
}
case_facts = []
for major in (16, 17):
    for mode, version in [('v2-schema',2),('v1-upgrade',1)]:
        run = NATIVE / f'pg{major}-{mode}-v1'
        evidence = run / 'consumer-evidence' / mode
        receipt = load(run / 'test.receipt.json')
        observations = load(run / 'observations.json')
        assert receipt['exit_code'] == 0 and receipt['timed_out'] is False
        assert observations['test_receipt_sha256'] == sha(run / 'test.receipt.json')
        assert observations['actual_test_exit_code'] == 0 and observations['libtest_summary'] == [[1,0,0,0,1]]
        assert observations['source_and_binary_before_after_exact'] and observations['container_and_durability_settings_unchanged']
        assert receipt['source_tree'] == manifest['source_tree_sha256'] and receipt['compiled_inputs_sha256'] == compiled['sha256']
        assert receipt['binary_sha256'] == summary['binary_sha256']
        assert receipt['profile_build_receipt_sha256'] == sha(BUILD / 'build.receipt.json')
        assert receipt['environment_allowlist'] == expected_env and not any(receipt['overrides_present'].values())
        assert receipt['mandatory_database_env_present'] and receipt['full_inventory_count'] == 2 and receipt['expected_filtered'] == 1
        assert receipt['argv'][0] == str(binary) and receipt['argv'][1] in names
        assert receipt['argv'][2:] == ['--exact','--test-threads=1','--nocapture']
        assert receipt['database']['port'] == 55400 + major and receipt['database']['URL_credentials_not_logged']
        for stream, record in receipt['output_streams'].items():
            assert record['redactions'] == 0 and record['saved_is_raw']
            assert record['raw_sha256'] == record['saved_sha256'] == sha(run / stream)
        stdout = (run / 'test.stdout').read_text()
        assert stdout.count('test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 1 filtered out;') == 1
        assert f'test {receipt["argv"][1]} ... ok' in stdout
        assert (run / 'full-inventory.stdout').read_bytes() == (BUILD / 'inventory.stdout').read_bytes()
        for path in run.glob('*.receipt.json'):
            if path.name == 'test.receipt.json': continue
            command = load(path)
            assert command.get('exit_code', command.get('actual_exit_code')) == 0
            label = path.name[:-len('.receipt.json')]
            assert command['stdout_sha256'] == sha(run / (label + '.stdout'))
            assert command['stderr_sha256'] == sha(run / (label + '.stderr'))
        for prefix in ('server','database'):
            before_settings = load(run / (prefix + '-settings-before.stdout'))
            after_settings = load(run / (prefix + '-settings-after.stdout'))
            assert before_settings == after_settings
            assert int(before_settings['server_version_num']) // 10000 == major
            assert all(before_settings[key] == 'on' for key in ('fsync','synchronous_commit','full_page_writes'))
        assert (run/'container-before.stdout').read_bytes() == (run/'container-after.stdout').read_bytes()
        assert sha(DAY / 'scoped-join-owner-stop-public-validation-native-runner-v1/run-case.py') == receipt['runner_sha256']

        before = load(evidence / 'before.json')
        after = load(evidence / ('after.json' if version == 2 else 'after-migration.json'))
        final = after if version == 2 else load(evidence / 'after-cold-read.json')
        assert before['snapshot'] == after['snapshot'] == final['snapshot']
        tables = before['snapshot']['business_tables']
        assert before['snapshot']['business_table_count'] == len(tables) == 54
        assert len(before['snapshot']['business_queries']) == 54
        assert all(table['row_count'] == len(table['rows']) for table in tables.values())
        closure_rows = tables['graph_frame_closures']['rows']
        assert len(closure_rows) == len(before['snapshot']['roots']) == 1
        assert sum(table['row_count'] for table in tables.values()) > 0
        if version == 1:
            assert after['migration_succeeded'] is True
            check_ledger(before['migrations'],36)
            assert after['migrations'][:36] == before['migrations']
            assert after['migrations'] == final['migrations']
            assert (run/'seed-schema-before.stdout').read_text().strip() == '36'
            assert (run/'seed-still-schema36.stdout').read_text().strip() == '36'
            assert (run/'seed-no-connections.stdout').read_text().strip() == '0'
            assert 'joinstop37_upgrade' in receipt['database']['name']
        else:
            check_ledger(before['migrations'],37)
            assert before['migrations'] == after['migrations']
        check_ledger(after['migrations'],37)

        schemas = load(evidence/'public-schemas.json')
        for label, reference in schema_expected.items():
            assert schemas[label]['reference'] == reference
            assert schemas[label]['document']['$schema'] == 'https://json-schema.org/draft/2020-12/schema'
            assert schemas[label]['document']['$id'] == reference['id']
            assert 'sha256:' + value_sha(schemas[label]['document']) == reference['digest']
            fixture = SOURCE / f'crates/stateknot-runtime/tests/fixtures/join_stop_closure_schema_{label}.json'
            assert schemas[label]['document'] == load(fixture)
        cold_records = load(evidence/'public-cold-read.json')
        assert len(cold_records) == 1
        cold, closure, root = cold_records[0], closure_rows[0], before['snapshot']['roots'][0]
        closure_bytes = bytea(closure['closure_bytes'])
        wire = json.loads(closure_bytes)
        assert wire['version'] == wire['intent']['version'] == version
        assert set(wire['intent']['stopped_join']) == {'owner','request_digest','registration'} if version == 2 else 'stopped_join' not in wire['intent']
        assert cold['tenant_id'] == closure['tenant_id'] == root['tenant_id'] and cold['run_id'] == closure['run_id'] == root['run_id']
        assert 'sha256:' + hashlib.sha256(closure_bytes).hexdigest() == cold['closure_bytes_sha256']
        assert hashlib.sha256(closure_bytes).digest() == bytea(closure['closure_checksum'])
        intent_digest = hashlib.sha256(f'stateknot-postgres-frame-closure-intent-v{version}\0'.encode() + canonical(wire['intent'])).digest()
        assert intent_digest == bytea(closure['intent_digest'])
        digest = hashlib.sha256(f'stateknot-postgres-frame-closure-compound-v{version}\0'.encode() + intent_digest + bytes.fromhex(wire['event']['digest'][7:]) + b''.join(bytes.fromhex(c['digest'][7:]) for c in wire['completions'])).digest()
        assert digest == bytea(closure['compound_digest']) and cold['compound_digest'] == 'sha256:' + digest.hex()
        assert cold['event'] == wire['event'] and cold['event']['payload']['schema'] == schema_expected[f'v{version}']
        assert cold['validated_payload'] == cold['event']['payload']['data'] == {'version':version,'intent_digest':'sha256:'+intent_digest.hex(),'frame_count':len(wire['completions'])}
        event_rows = [event for event in tables['run_events']['rows'] if event['tenant_id'] == closure['tenant_id'] and event['run_id'] == closure['run_id'] and event['sequence'] == closure['journal_sequence']]
        assert len(event_rows) == 1
        event = event_rows[0]
        assert json.loads(bytea(event['payload_bytes'])) == cold['event']['payload']
        assert event['schema_id'] == schema_expected[f'v{version}']['id'] and event['schema_version'] == schema_expected[f'v{version}']['version']
        assert bytea(event['schema_digest']).hex() == schema_expected[f'v{version}']['digest'][7:]
        assert event['event_id'] == closure['journal_event_id'] == cold['event']['event_id']
        assert root['run_checkpoint_id'] == root['closure_root_checkpoint_id'] == closure['root_checkpoint_id'] == cold['root']['checkpoint_id']
        checkpoint_bytes = bytes.fromhex(root['root_checkpoint_bytes'])
        assert canonical(cold['root']) == checkpoint_bytes
        assert root['run_checkpoint_digest'] == cold['root']['digest'][7:]
        assert root['run_checkpoint_superstep'] == int(cold['root']['superstep'])
        assert {key:cold['root'][key] for key in wire['intent']['root']} == wire['intent']['root']
        sha(evidence/'queries.sql')
        case_facts.append({'postgres_major':major,'mode':mode,'actual_exit_code':receipt['exit_code'],'libtest':{'passed':1,'failed':0,'ignored':0,'measured':0,'filtered':1},'database':receipt['database']['name'],'source_tree_sha256':receipt['source_tree'],'compiled_inputs_sha256':receipt['compiled_inputs_sha256'],'binary_sha256':receipt['binary_sha256'],'test_receipt_sha256':sha(run/'test.receipt.json'),'observations_sha256':sha(run/'observations.json'),'raw_stdout_sha256':sha(run/'test.stdout'),'raw_stderr_sha256':sha(run/'test.stderr'),'redactions':0,'business_tables':54,'nonempty_business_tables':sum(table['row_count']>0 for table in tables.values()),'business_rows':sum(table['row_count'] for table in tables.values()),'run_events':tables['run_events']['row_count'],'closure_count':1,'cold_read_count':1,'business_snapshot_sha256':value_sha(before['snapshot']),'roots_sha256':value_sha(before['snapshot']['roots']),'closure_bytes_sha256':hashlib.sha256(closure_bytes).hexdigest(),'root_checkpoint_bytes_sha256':hashlib.sha256(checkpoint_bytes).hexdigest(),'migration_versions_before':len(before['migrations']),'migration_versions_after':len(after['migrations']),'original_migration_rows_exact':True,'schema37_checksum_sha384':bytea(after['migrations'][-1]['checksum']).hex(),'event_schema_reference':cold['event']['payload']['schema'],'before_after_and_cold_business_bytes_exact':True,'source_and_binary_before_after_exact_recorded':True,'container_and_durability_settings_unchanged':True,'fsync_synchronous_commit_full_page_writes':'on'})

audit_helper_sha256 = sha(__file__)
hash_receipt = {'auditor_script_sha256':audit_helper_sha256,'all_audited_file_sha256':dict(sorted(SHA_ROWS.items()))}
(OUT/'source-sha-receipt.json').write_text(json.dumps(hash_receipt,ensure_ascii=False,indent=2)+'\n')
important_names = {'test.receipt.json','observations.json','before.json','after.json','after-migration.json',
                   'after-cold-read.json','public-cold-read.json','public-schemas.json','queries.sql',
                   'build.receipt.json','build-summary.json','compiler-artifacts.json','freshness.json',
                   'metadata.receipt.json','inventory.stdout','scope.json','frozen-source-manifest.json','compiled-inputs.json'}
important_hashes = {name:digest for name,digest in sorted(SHA_ROWS.items())
                    if Path(name).name in important_names and not name.startswith(str(SOURCE.relative_to(REPO))+'/')}
facts = {
    'status':'INDEPENDENT_AUDIT_OF_SAVED_PUBLIC_CONSUMER_EVIDENCE',
    'auditor_new_build_DB_Docker_network_or_consumer_execution':False,
    'source':{'product_tree':green_manifest['source_tree_sha256'],'product_compiled_inputs':green_compiled['sha256'],'consumer_tree':manifest['source_tree_sha256'],'consumer_compiled_inputs':compiled['sha256'],'all_935_product_files_and_543_product_inputs_byte_exact':True,'consumer_only_additions':extras,'consumer_file_count':938,'consumer_compiled_count':546,'Cargo_lock_sha256':rows['Cargo.lock']['sha256']},
    'build':{'actual_exit_code':0,'metadata_locked_offline_exit_code':0,'build_argv':build['argv'],'binary_sha256':summary['binary_sha256'],'binary_bytes':summary['binary_bytes'],'inventory_count':2,'inventory_cases':names,'selected_artifacts':[{'target':item['target']['name'],'kind':item['target']['kind'],'fresh':item['fresh'],'features':item['features'],'profile':item['profile']} for item in selected],'environment_allowlist':expected_env,'all_forbidden_overrides_absent':True,'all546_refresh_rows_byte_exact_and_after_previous_compile':True,'cache_TAG_absent_recorded_no_cleanup':build['cache_CACHEDIR_TAG_exists'] is False and build['cache_TAG_not_fabricated_and_no_cleanup'] is True},
    'schemas':schema_expected,
    'cases':case_facts,
    'qualifies_only':'Actual saved default-feature Native public-consumer executions on PostgreSQL16/17: persisted v2 offline-schema/cold-read seam and retained source-v1 schema36→37 public SQLx migration/cold-read seam.',
    'does_not_qualify':['full combined CI','Driver scoped Join','Root ConfirmCancellation','complete negative/fault/compatibility windows','capacity or production deployment','R1','the separately authored ACK candidate'],
    'relevant_evidence_file_sha256':important_hashes,
    'all_1132_audited_file_hashes_receipt':'source-sha-receipt.json',
    'all_audited_file_hashes_receipt_sha256':hashlib.sha256((OUT/'source-sha-receipt.json').read_bytes()).hexdigest(),
}
(OUT/'facts.json').write_text(json.dumps(facts,ensure_ascii=False,indent=2)+'\n')
report='''# Independent audit of saved public-consumer evidence

All four saved executions satisfy their narrow evidence contract. This audit performed file reads/hash/JSON checks only; it ran no build, database, Docker, network or consumer command.

The consumer freeze is 938 files / 546 compiled inputs: source `5d77326d5cce4988506b7acb549cedb37eba5be62c14b857502736eeffaa806d`, compiled `625def171e1b8f43de7bff2a55115a29d7751f7c5d44dde07081a28007aa35c5`. All original 935 Green files and 543 product inputs are byte-identical; only the integration test and its two schema fixtures were added. Cargo.lock remains `fc36c3966dc2abf990fae6a01b633459d95fedae0fd7f77c429b5f04447b2e94`.

The saved Cargo metadata/build exits are both0, locked/offline. Raw compiler JSON confirms four selected product/test artifacts `fresh:false`, features `[]`, opt1, debug0, debug assertions/overflow checks enabled; no stack/compiler overrides. Binary `7c174940e83c9435e66ed7675b5faba4af3c8302c79732a648553b609350b30b` has exactly two inventory cases. The reused cache's missing TAG is recorded; no cleanup is claimed.

| PG | Saved case | Actual result | Complete snapshot |
| --- | --- | --- | --- |
|16|v2 schema/cold read|exit0;1 passed,1 filtered;0 redactions|54 tables;19 nonempty;37 rows;11 events;one closure|
|17|v2 schema/cold read|exit0;1 passed,1 filtered;0 redactions|54 tables;19 nonempty;37 rows;11 events;one closure|
|16|retained v1 migration/cold read|exit0;1 passed,1 filtered;0 redactions|54 tables;12 nonempty;18 rows;five events;one closure|
|17|retained v1 migration/cold read|exit0;1 passed,1 filtered;0 redactions|54 tables;12 nonempty;18 rows;five events;one closure|

Raw receipt/output hashes match. Each v2 before/after snapshot and ledger is exact. Each v1 upgrade has actual complete successful rows1..36→1..37, every original migration row unchanged (including checksum/installed time/execution time), new37 SHA384 matching embedded SQL37, and identical full business/closure/Root snapshots before migration, after migration and after fresh public cold reads. Recorded source seeds remain36; migration runs used disposable clones. All saved durability settings remain on and container/settings records match.

Both public getter documents match their fixture/reference/URI/version and canonical SHA256 identities: v1 `453045e2…53e520`, v2 `aec9b96d…61ea5f`. Each cold event equals its persisted closure and raw event payload/schema; Root checkpoint bytes/pointers and closure checksum, versioned intent and compound digests independently match. The passed compiled tests execute production offline-registry validation and opposite-version refusal. No missing-event or empty-snapshot success is possible in these records.

Exact per-case receipt, snapshot, Root/closure byte hashes and all relevant source/log hashes are in `facts.json`. These four cases do not confer full CI, scoped Driver, ConfirmCancellation, complete fault/negative/compatibility, production or R1 qualification, and do not qualify the separate ACK candidate.
'''
(OUT/'REPORT.md').write_text(report)
assert subprocess.check_output(['git','status','--porcelain'],cwd=REPO,text=True)==''
print(json.dumps({'facts_sha256':hashlib.sha256((OUT/'facts.json').read_bytes()).hexdigest(),'report_sha256':hashlib.sha256((OUT/'REPORT.md').read_bytes()).hexdigest(),'audited_cases':len(case_facts),'audited_hash_rows':len(SHA_ROWS),'main_clean':True},indent=2))
