# Root execution handoff: current saved Runtime194 PITR

Authoring only: this runner has not been executed by its author. It never calls
Cargo or copies/builds Rust artifacts. Root reviews and runs PostgreSQL16 and17
serially, after all four composed full Native runs and both separately mandatory
backup-restore exact runs have actual terminal receipts.

Create a prerequisite JSON file with exact current receipt hashes:

```json
{
  "source_tree_sha256": "e8f3b8a1c93cbbd8ad00fa3622657be032a98fc775ea9580337c27c1d8ad77db",
  "compiled_inputs_sha256": "acc2f7706a60201874a2dec4de5c690fcee4bf7a04409822bf409f72ca7f1c16",
  "full_native_runs": [
    {"major":16,"package":"store","test_receipt":"ABSOLUTE_PATH","receipt_sha256":"ACTUAL_SHA256"},
    {"major":17,"package":"store","test_receipt":"ABSOLUTE_PATH","receipt_sha256":"ACTUAL_SHA256"},
    {"major":16,"package":"runtime","test_receipt":"ABSOLUTE_PATH","receipt_sha256":"ACTUAL_SHA256"},
    {"major":17,"package":"runtime","test_receipt":"ABSOLUTE_PATH","receipt_sha256":"ACTUAL_SHA256"}
  ],
  "backup_restore_runs": [
    {"major":16,"test_receipt":"ABSOLUTE_PATH","receipt_sha256":"ACTUAL_SHA256"},
    {"major":17,"test_receipt":"ABSOLUTE_PATH","receipt_sha256":"ACTUAL_SHA256"}
  ]
}
```

The placeholder values above must be replaced with real existing terminal
receipt paths and hashes. A prerequisite failure remains a failure; the runner
does not invent a passing prerequisite or transfer its qualification.

```sh
python3 .local-verification/2026-10-18/scoped-join-owner-stop-composed-pitr-runner-v1/run-pitr.py \
  --major 16 --prerequisites ABSOLUTE_REAL_PREREQUISITE_JSON \
  --out .local-verification/2026-10-18/scoped-join-owner-stop-composed-pitr-native-v1/pg16
```

Then run17 with the same prerequisite file, a new `pg17` output directory, and
`--previous-pg16-receipt` pointing to16's actual `test.receipt.json`. The fixed
saved binary has SHA `6f633c5883ccdba9308d7ba408c044653ec4c3a95c9a3c27469ae15e0dda4e7e`;
the frozen source has936 files and544 compiled inputs. The helper verifies
default features, opt-level1, assertions/overflow, absent stack/compiler
overrides, complete current inventory194 and the actual successful build receipt.

All inherited `STATEKNOT_*`, PostgreSQL/SQLx and common database environment
variables are removed. Only `STATEKNOT_REQUIRE_PITR_TESTS=1` and the exact frozen
workflow image are set for this profile. Images must already exist locally;
the wrapper issues only read-only `docker image inspect` and performs no pull,
volume/container/database removal or external cleanup. The unchanged exact test
owns only its UUID-named resources and validates its own cleanup before its
15-field marker. Default stack and all original operation deadlines are retained;
the wrapper adds no new global test deadline. Root supervises the running session.

The actual process exit/raw stream digests are saved before post-run observation.
The post-run source/binary and df/cache checks execute even if the test fails.
Success also requires one exact15-field marker, verified backup manifest, archived
WAL segment, exact named restore point, excluded later write, exact durable
snapshot/noninitial replay/cross-tenant refusal, real PostgreSQL major,
UUID-resource cleanup and1 passed/193 filtered. Failure is retained; no wrapper
cleanup is attempted. This is the existing consumed-Join PITR seam, not an
owner-stop-specific restore, scoped Driver, complete recovery or R1 qualification.
