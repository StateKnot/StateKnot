#!/usr/bin/env python3
"""Freeze a new offline run bundle from Root's saved official GET responses only."""
import sys
sys.dont_write_bytecode = True
import argparse
import datetime
from pathlib import Path
import shutil
from common import canonical, gitblob, inside, load, require, saved_get, sha, verify_index, publication_payloads, verify_full_publication

HERE = Path(__file__).resolve().parent
PARENT = 'e372184fb1c80ffb9903ac0d9feb8380db51253e'
BRANCH = 'codex/ci-postgres-shards-20261019-v1'
API = 'repos/StateKnot/StateKnot'
SOURCE_HASH = '21c32c1446377a9691d63d835bb732b8d8cc6259e236c9cd0575dc13369f7a44'
COMPILED_HASH = '30d6c10fd88118297131a28c0e3b78420f51dec17206a718948a348c7424de81'


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as handle:
        import json
        json.dump(value, handle, ensure_ascii=False, indent=2)
        handle.write('\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--request', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True, help='frozen composed-source-v3 directory')
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    require(not args.out.exists(), 'output exists; use a new version, never overwrite frozen evidence')
    require(not args.out.resolve().is_relative_to(HERE.resolve()) and not args.out.resolve().is_relative_to(args.source.resolve()), 'prepare output must be outside immutable author/source inputs')
    verify_index(HERE, 'manifest.json')
    request = load(args.request)
    base = args.request.resolve().parent
    official = request['official']
    require(set(official) == {'run', 'commit', 'ref', 'compare', 'tree', 'parent_tree'}, 'all six official GETs including complete parent tree are mandatory')
    run, _ = saved_get(base, official['run'])
    head, tree = run['head_sha'], run['head_commit']['tree_id'] if 'tree_id' in run.get('head_commit', {}) else None
    import re
    require(type(run['id']) is int and re.fullmatch('[0-9a-f]{40}', head), 'invalid official run identity')
    require((run['head_branch'], run['event'], run['path'], run['run_attempt']) == (BRANCH, 'workflow_dispatch', '.github/workflows/ci.yml', 1), 'unexpected official dispatch')
    require(run['repository']['full_name'] == run['head_repository']['full_name'] == 'StateKnot/StateKnot', 'wrong/fork repository')
    saved_get(base, official['run'], API + '/actions/runs/' + str(run['id']))
    commit, _ = saved_get(base, official['commit'], API + '/git/commits/' + head)
    require(commit['sha'] == head and [r['sha'] for r in commit['parents']] == [PARENT], 'official commit parent/head')
    require(tree is None or tree == commit['tree']['sha'], 'official run and commit tree disagree')
    tree = commit['tree']['sha']
    ref, _ = saved_get(base, official['ref'], API + '/git/ref/heads/' + BRANCH)
    require(ref['ref'] == 'refs/heads/' + BRANCH and ref['object']['sha'] == head and ref['object']['type'] == 'commit', 'official branch readback binding')
    compare, _ = saved_get(base, official['compare'], API + '/compare/' + PARENT + '...' + head)
    require(compare['base_commit']['sha'] == compare['merge_base_commit']['sha'] == PARENT and compare['total_commits'] == 1 and [c['sha'] for c in compare['commits']] == [head], 'official compare commit identity')
    finaltree, _ = saved_get(base, official['tree'], API + '/git/trees/' + tree + '?recursive=1')
    require(finaltree['sha'] == tree, 'official final Git tree identity')
    identity = {'parent': PARENT, 'branch': BRANCH, 'tree': tree, 'head_sha': head}
    publication_prepared, publication_manifest, payloads = publication_payloads(HERE / 'inputs', identity)
    parenttree, _ = saved_get(base, official['parent_tree'], API + '/git/trees/' + publication_prepared['parent_tree'] + '?recursive=1')
    finalentries, blobs, parentblobs = verify_full_publication(finaltree, parenttree, compare, payloads, publication_prepared['parent_tree'])
    source = load(HERE / 'inputs/source-manifest.json')
    compiled = load(HERE / 'inputs/compiled-inputs.json')
    require(source['count'] == len(source['files']) == 936 and source['source_tree_sha256'] == sha(canonical(source['files'])) == SOURCE_HASH, 'frozen936 source manifest')
    require(compiled['count'] == len(compiled['files']) == 544 and compiled['sha256'] == sha(canonical(compiled['files'])) == COMPILED_HASH, 'frozen544 compiled manifest')
    ci = load(HERE / 'inputs/candidate-manifest.json')['candidate_files']
    require(len(ci) == 5, 'exact five CI payloads')
    overrides = {r['path']: r for r in ci}
    expected, native = [], []
    for row in source['files']:
        relative = row['path']
        original = inside(args.source, relative).read_bytes()
        require((len(original), sha(original)) == (row['bytes'], row['sha256']), 'frozen product source changed: ' + relative)
        raw = inside(HERE / 'inputs/payload', relative).read_bytes() if relative in overrides else original
        row = {'path': relative, 'bytes': len(raw), 'sha256': sha(raw), 'blob_sha1': gitblob(raw)}
        require(relative in blobs and blobs[relative]['sha'] == row['blob_sha1'] and blobs[relative]['size'] == row['bytes'], 'official Git blob differs from exact frozen source+CI: ' + relative)
        row['git_mode'] = blobs[relative]['mode']
        expected.append(row)
    #936 is a selected pre-CI product manifest, not the complete repository.
    #Four of the five CI helper paths are additions outside that selected set.
    for relative, row in overrides.items():
        if relative in {r['path'] for r in expected}:
            continue
        raw = inside(HERE / 'inputs/payload', relative).read_bytes()
        require((len(raw), sha(raw)) == (row['bytes'], row['sha256']), 'five CI payload bytes')
        actual = blobs[relative]
        require((actual['sha'], actual['size']) == (gitblob(raw), len(raw)), 'official added CI blob')
        expected.append({'path': relative, 'bytes': len(raw), 'sha256': sha(raw), 'blob_sha1': gitblob(raw), 'git_mode': actual['mode']})
    require(len(expected) == 940, '936 selected product + four added CI helpers')
    expected.sort(key=lambda row: row['path'])
    expected_by_path = {r['path']: r for r in expected}
    for row in compiled['files']:
        frozen = expected_by_path[row['path']]
        require((row['bytes'], row['sha256']) == (frozen['bytes'], frozen['sha256']), 'CI overlay changed compilation inputs')
        native.append(dict(row))
    require([r['path'] for r in native] == sorted(r['path'] for r in native), 'native source binding must follow git ls-files order')
    # All validation happens before creating the new frozen output.
    args.out.mkdir(parents=True)
    for relative in ('analyze.py', 'common.py', 'collect.py'):
        shutil.copyfile(HERE / relative, args.out / relative)
    shutil.copytree(HERE / 'inputs', args.out / 'inputs')
    copied = {}
    for label, spec in official.items():
        copied[label] = {}
        for key in ('stdout', 'receipt', 'stderr'):
            if key in spec:
                relative = 'inputs/publication/' + label + '-' + key + inside(base, spec[key]).suffix
                target = args.out / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(inside(base, spec[key]), target)
                copied[label][key] = relative
        if 'event_label' in spec:
            copied[label]['event_label'] = spec['event_label']
    write(args.out / 'inputs/official.json', {'official': copied})
    binding = {'schema': 'stateknot-ci-postgres-shards-binding-v1', 'repository': 'StateKnot/StateKnot', 'api': API,
               'run_id': run['id'], 'head_sha': head, 'tree': tree, 'parent': PARENT, 'branch': BRANCH,
               'workflow_id': run['workflow_id'], 'run_attempt': 1, 'event': 'workflow_dispatch', 'created_at': run['created_at'],
               'expected_files': expected, 'compiled_files': native, 'compiled_count': 544,
               'source_936_sha256': SOURCE_HASH, 'compiled_canonical_sha256': COMPILED_HASH,
               'native_source_manifest_sha256': sha(__import__('json').dumps(native, sort_keys=True).encode()),
               'ci_files': ci, 'parent_tree_verified': True,
               'selected_pre_CI_source_count': 936, 'selected_with_CI_byte_verified_count': len(expected),
               'complete_official_tree_entries': [finalentries[p] for p in sorted(finalentries)],
               'complete_official_blob_count': len(blobs), 'complete_official_tree_entry_count': len(finalentries),
               'publication_payload_files': payloads, 'publication_payload_count': 38,
               'publication_manifest_sha256': publication_prepared['input_manifest_sha256'],
               'official_parent_tree': parenttree['sha'],
               'all_other_official_blobs_unchanged_from_parent': True,
               'SHA256_claim_scope': 'selected936 pre-CI source plus separate5 CI and exact38 publication payload bytes only; remaining official tree entries have Git SHA1/mode/type/size but no newly computed content SHA256',
               'prepare_only': True, 'network_Cargo_DB_Docker_executed': False,
               'full_CI_success_verified': False, 'PR14_or_R1_closed': False,
               'prepared_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    write(args.out / 'binding.json', binding)
    rows = [{'path': p.relative_to(args.out).as_posix(), 'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())} for p in sorted(args.out.rglob('*')) if p.is_file()]
    write(args.out / 'manifest.json', {'schema': 'immutable-offline-shards-bundle-v1', 'count': len(rows), 'files': rows})
    print(__import__('json').dumps({'bundle': str(args.out), 'run_id': run['id'], 'head_sha': head, 'tree': tree, 'prepare_only': True, 'actual_CI_qualification': False}))


if __name__ == '__main__':
    main()
