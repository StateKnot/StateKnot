# Final composed-v3 PostgreSQL shards terminal evidence

Source-only authoring bundle. Root alone runs preparation, collection and analysis.
Authoring has performed static data extraction and Python AST parsing only. No
Cargo, database, Docker, network, CI, collector or terminal analysis was executed.
No success or qualification is awarded by this bundle's existence.

## 1. Prepare a new immutable binding from saved official responses

Copy `prepare-request.template.json` to a new file directly in the 2026-10-18 day
directory. Paths are relative to that new request's parent. Fill the actual run
GET stdout/receipt/stderr paths after the one real dispatch. Publication paths
match Root's `ci-postgres-shards-publication-authoring-v2/execution-v1/publication`
protocol. Preserve both `.intent.json` and `.actual.json` at their original Root
location; the binding consumes the successful GET `.actual.json` and saved bytes.
An `api-events.json` journal can instead be referenced using `event_label`.

```sh
python3 .local-verification/2026-10-18/ci-postgres-shards-terminal-analyzer-v4/prepare.py \
  --request .local-verification/2026-10-18/NEW-PREPARE-REQUEST.json \
  --source .local-verification/2026-10-18/scoped-join-owner-stop-composed-source-v3 \
  --out .local-verification/2026-10-18/NEW-IMMUTABLE-ANALYZER-BUNDLE
```

This is offline and prepare-only. It does not depend on a local Git commit. The
only accepted identity sources are successful explicit official `gh api --method
GET` receipts for run, commit, branch ref, compare and complete recursive final
Git tree. The headers in Root's current protocol are explicitly supported. GET
failures, timeouts, unknown outcomes, mutation responses, foreign API endpoints,
truncated trees, fork identities or a different branch/parent fail closed.
`parent_tree` is mandatory. The complete official parent and final trees are independently reconstructed into their Git tree IDs. Every leaf and directory is retained and checked; the final tree has4088 blobs and4604 recursive entries.

Every frozen936 source byte must match the composed-v3 source manifest
`21c32c1446377a9691d63d835bb732b8d8cc6259e236c9cd0575dc13369f7a44`.
The936 files form the selected pre-CI product scope, not the complete repository. The five reviewed CI files are bound separately: ci.yml overlays one selected path and four helpers are additions, making940 selected final byte bindings. All38 actual publication payloads, including the three qualification documents, are frozen from the immutable prepared plan and checked as exact bytes, mode, length, SHA256 and Git blob SHA1. Every other final blob must equal the official parent in path/type/mode/SHA1/size; no deletion or unlisted change is permitted. All4088 official final blobs and every directory entry are retained. Content SHA256 is claimed only for bytes actually read (selected source, five CI files and38 payloads), not for the remaining parent-inherited blobs. All544 compilation inputs retain canonical manifest digest
`30d6c10fd88118297131a28c0e3b78420f51dec17206a718948a348c7424de81`.
The helper's noncompact JSON source-manifest digest is frozen separately because
it is intentionally a different serialization from the canonical manifest.

The prepared output contains the exact analyzer, collector, helpers, all frozen
manifests/contracts, five CI payloads and official responses with a complete
`manifest.json`. Preparation never overwrites existing output.

## 2. Root collects official terminal bytes

```sh
python3 NEW-IMMUTABLE-ANALYZER-BUNDLE/collect.py \
  --bundle NEW-IMMUTABLE-ANALYZER-BUNDLE --out NEW-TERMINAL-RAW-VERSION
```

`collect.py` is the old official read-only collector adapted to the prepared
binding; it has no old run ID or head SHA. It checks the bundle before any GET.
It preserves run, complete jobs/artifacts pagination, all21 job logs, all check
annotation pages, every artifact ZIP, official artifact digest, all safely unpacked
files and per-file indexes. The final `files.json` covers every raw file. GET
receipts bind argv, real exit status and stdout/stderr byte lengths/digests.
Nothing is filtered by success. Collection of partial/nonterminal/failed jobs does
not qualify CI. Every retry must use a new directory.

## 3. Root runs strict offline analysis after actual terminal collection

```sh
python3 NEW-IMMUTABLE-ANALYZER-BUNDLE/analyze.py \
  --bundle NEW-IMMUTABLE-ANALYZER-BUNDLE \
  --raw NEW-TERMINAL-RAW-VERSION --out NEW-ANALYSIS-VERSION
```

The analyzer uses only Python's standard library. It executes no evidence code,
subprocess, Git, network, Cargo, database or Docker operation. It validates the
entire bundle/raw index, official GET receipts and pagination, all21 job identities
and states, every ZIP/API digest/member/unpacked byte and all artifact inventories.
It records all observed job steps and every original60-step mapping on each major,
including failed/cancelled/skipped entries; it does not select only passing steps.
All added shard steps and both strict actual aggregation guards are also retained.

Native verification requires the full Store267 and Runtime194 inventories and
raw harness summaries, cold default-feature opt1/debug0 builds, debug assertions
and overflow checks, pinned Cargo/Rustc1.88.0, original executable path/hash,
all544 source hashes and actual executable overlap. Exactly two distinct live
owners, helper true waits, suite exit0, successful group-empty retirement,
`parent-cleanup`, no forced kill/FIFO/third compile lane and final raw log digests
are required. Runner binaries are not downloaded; the analyzer cross-checks the
fixed helper's real binary execution/overlap/monitor receipts rather than claiming
to inspect a vanished runner path.

Return and Wait each require the strict typed closed two-cut marker schemas,
Linux x86_64/PostgreSQL major, real SIGKILL/reaping and recovery invariants, exact
Runtime194 full/193 filtered inventories, actual test name and saved validation
hash. Markers must also be present once in the correct official process job log.
The two original provider2/example1 protocol harnesses must actually run.

All48 marker/count requirements from the frozen workflow are checked against raw
artifact logs and the owning official job log. JSON constants and closed key sets
come from frozen Rust source; all eight plain HTTP/Worker markers are byte-exact.
Every process boundary and operation/cut matrix is retained and validated. Role
profile requires schema37; logical restore requires nonempty backup hash/size and
isolation/snapshot/replay checks; physical PITR requires base backup/WAL/named
restore/resource-cleanup evidence. Real identity requires the pinned Keycloak
image, actual source/tree, two real harnesses and all four exact TLS/rotation/
revocation/host/operations JSON markers. All host/operations/maintenance/MCP
markers, mandatory MCP15 no-skip marker and reduced host report are required.
The reduced report's canonical envelope digest, source inputs, PostgreSQL major,
durability, safety counters and evidence-valid/release-false scope are checked;
its successful frozen-source Rust test remains the authority for full report
schema/objective recomputation. No reduced report is promoted to release evidence.

`full_CI_success_verified` and `full_CI_qualification` can be true only when the
actual official run and all21 jobs succeed, all60 mapped source steps on both
majors succeed, all inserted named shard steps and both aggregate guards succeed,
and every evidence check passes. Missing, failed, cancelled, skipped, malformed or
unindexed evidence leaves them false. The old local V3 sleep failure and synthetic
32 aggregate controls cannot replace real CI. PR14, R1, milestones and release
closure always remain false; this analyzer never closes them automatically.

A new receipt is written even on errors; nonzero exit means evidence validation
failed. A complete valid cancelled run may still exit0 with fullCI=false if every
required artifact happened to exist. Use the actual booleans and preserved states,
not merely process exit0. Fixes after execution must be new versioned bundles.

Version2 preserves unexecuted version1 and prevents Python import bytecode from modifying an indexed immutable bundle. Preparation also rejects output inside immutable author/source inputs. These are static authoring fixes; no old raw collection was analyzed.

Version3 preserves version2 and its real preparation failure. It corrects the selected936 versus full4088 repository scope, binds all38 actual publication payloads and unchanged parent blobs, and expands frozen artifact upload globs (the failure-close process glob must contain exactly its qualification and environment logs). It has not executed preparation, collection, terminal analysis or CI.

Version4 preserves the prepared version3 bundle and changes only the logical-backup archive digest contract to the exact frozen Digest serialization `sha256:<64 lowercase hex>`. The physical PITR manifest remains exactly64 lowercase hex from sha256sum; its validator is unchanged. Source and both actual V3 PostgreSQL markers support these distinct forms.
