# Root handoff: composed-v3 mandatory logical restore

New version; v1 is preserved unchanged. Authoring only: the author has not run
this wrapper, its tests or resource operations. `v2-v1.patch` contains the complete
delta. `build.py` remains byte-identical (`3412…8067`) and is imported only for
source/profile checks; no build command is executed.

This version strictly pins composed-v3 source936 `21c32c…f7a44`, compiled544
`30d6c1…4de81`, Runtime194 binary `b28ccd…72354` and its actual successful
build receipt `d13083…f9a2`. The source changed only the role-profile exact current
schema assertion36→37. That fixes an observed v2 failure, but does not make either
original v2 Runtime full run successful or qualify v3 without actual execution.

Use the v1 prerequisite JSON structure, with its top-level source/input hashes
set to the exact v3 values. Its four full Native rows may reference actual v2 or
v3 terminal receipts. Each source/input pair is independently checked and
recorded alongside its actual exit, `passing` and `prior_source_failure_preserved`.
The four rows establish terminal scheduling prerequisites only;
`qualification_transferred_to_composed_v3` is always false.

```sh
python3 .local-verification/2026-10-18/scoped-join-owner-stop-composed-backup-runner-v2/run-backup.py \
  --build-dir .local-verification/2026-10-18/scoped-join-owner-stop-composed-native-v3/build-candidate-runtime-v1 \
  --major 16 --prerequisites ABSOLUTE_REAL_V3_TARGET_PREREQUISITE_JSON \
  --out .local-verification/2026-10-18/scoped-join-owner-stop-composed-backup-native-v2/pg16
```

Run17 into a fresh `pg17` directory. The new base prefix is
`stateknot_r1_joincomposedbackupv3_20261018_pg…`; no v1 base database is reused.
Exact selected case, strict13-field marker, original600-second watchdog,
default features/opt-level1/default stack, fresh database, fixed task
container/image/loopback/durability checks, actual-exit-first receipts and original
UUID-owned test cleanup remain unchanged. No earlier log, frozen source or
external resource is modified. It qualifies only the existing consumed-Join
logical backup/restore seam, not owner-stop-specific restore, Driver, CI or R1.
