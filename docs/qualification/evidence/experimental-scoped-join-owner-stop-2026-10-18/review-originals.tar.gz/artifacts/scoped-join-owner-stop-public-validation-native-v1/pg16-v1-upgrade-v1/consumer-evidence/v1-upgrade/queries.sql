-- table inventory
SELECT quote_ident(c.relname) FROM pg_catalog.pg_class c JOIN pg_catalog.pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='stateknot' AND c.relkind IN ('r','p') ORDER BY c.relname;
-- full migration rows through bound version
SELECT COALESCE(jsonb_agg(to_jsonb(m) ORDER BY version),'[]'::jsonb)::text FROM public._sqlx_migrations m WHERE version<=$1;
-- retained closure bytes at bound wire version
SELECT tenant_id,run_id::text,closure_bytes,'sha256:'||encode(intent_digest,'hex') FROM stateknot.graph_frame_closures WHERE convert_from(closure_bytes,'UTF8')::jsonb->>'version'=$1 ORDER BY tenant_id,run_id;
-- exact Root pointer and checkpoint bytes
SELECT COALESCE(jsonb_agg(jsonb_build_object('tenant_id',c.tenant_id,'run_id',c.run_id::text,'closure_root_checkpoint_id',c.root_checkpoint_id::text,'run_checkpoint_id',r.checkpoint_id::text,'run_checkpoint_superstep',r.checkpoint_superstep,'run_checkpoint_digest',encode(r.checkpoint_digest,'hex'),'root_checkpoint_bytes',encode(p.checkpoint_bytes,'hex')) ORDER BY c.tenant_id,c.run_id),'[]'::jsonb)::text FROM stateknot.graph_frame_closures c JOIN stateknot.runs r ON r.tenant_id=c.tenant_id AND r.run_id=c.run_id JOIN stateknot.run_checkpoints p ON p.tenant_id=c.tenant_id AND p.run_id=c.run_id AND p.checkpoint_id=c.root_checkpoint_id;
-- for each catalog-returned quoted table name
SELECT COALESCE(jsonb_agg(to_jsonb(t) ORDER BY to_jsonb(t)::text),'[]'::jsonb)::text FROM stateknot.<quoted_table> t;
