#!/usr/bin/env python3
"""Install the frozen guard on a cloned task fixture and measure exact catalog."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time

REPO = Path(__file__).resolve().parents[3]
DAY = Path(__file__).resolve().parent.parent
BASE = DAY / 'scoped-join-stop37-catalog-v1'
FREEZE = DAY / 'scoped-join-owner-stop-green-root-freeze-v1'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
load = lambda p: json.loads(p.read_bytes())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--major', type=int, choices=(16, 17), required=True)
    args = parser.parse_args()
    out = BASE / f'pg{args.major}-probe-v1'
    out.mkdir(exist_ok=False)
    seed = BASE / f'pg{args.major}-seed-v1'
    receipt = load(seed / 'test.receipt.json')
    assert receipt['exit_code'] == 0 and not receipt['timed_out']
    database = receipt['database']
    container = 'stateknot-r1-oct15-pg' + str(args.major)
    source = database['name']
    probe = f'stateknot_r1_stop37_catalog_20261018_pg{args.major}_v1'
    assert re.fullmatch('[a-z0-9_]{1,63}', source) and re.fullmatch('[a-z0-9_]{1,63}', probe)
    migration = (FREEZE / 'candidate/crates/stateknot-store-postgres/migrations/0037_registered_join_owner_stops.sql').read_bytes()
    assert sha(migration) == '99ba927b5a9df5580cb9d76c82433a418a2e7f8292f5ac25f1f214347d48d17d'
    disk = subprocess.check_output(['df', '-k', str(REPO)])
    (out / 'before.df').write_bytes(disk)
    assert int(disk.decode().splitlines()[-1].split()[3]) >= 50 * 1024**2

    def command(label, argv, raw=None):
        start = time.time()
        try:
            result = subprocess.run(argv, input=raw, capture_output=True, timeout=45)
            code, stdout, stderr = result.returncode, result.stdout, result.stderr
        except subprocess.TimeoutExpired as error:
            code, stdout, stderr = 124, error.stdout or b'', error.stderr or b''
        (out / (label + '.stdout')).write_bytes(stdout)
        (out / (label + '.stderr')).write_bytes(stderr)
        (out / (label + '.receipt.json')).write_text(json.dumps({
            'argv': argv, 'stdin_sha256': sha(raw) if raw is not None else None,
            'started_unix': start, 'seconds': time.time() - start, 'actual_exit_code': code,
            'stdout_sha256': sha(stdout), 'stderr_sha256': sha(stderr),
        }, indent=2) + '\n')
        assert code == 0, (label, code)
        return stdout

    def sql(label, statement, db=probe, transaction=False):
        argv = ['docker', 'exec', '-i', container, 'psql', '-X', '-v', 'ON_ERROR_STOP=1',
                '-U', 'postgres', '-d', db, '-At']
        if transaction:
            argv.append('-1')
        argv.extend(['-f', '-'])
        return command(label, argv, statement if isinstance(statement, bytes) else statement.encode())

    identity = command('container', ['docker', 'inspect', '--format', '{{.Id}} {{.Image}} {{.State.Running}}', container])
    assert identity.decode().split() == [database['container_id'], database['image_id'], 'true']
    assert sql('seed-schema', 'SELECT max(version) FROM public._sqlx_migrations;', source).strip() == b'36'
    assert sql('probe-absent', f"SELECT count(*) FROM pg_database WHERE datname='{probe}';", 'postgres').strip() == b'0'
    assert sql('seed-no-connections', f"SELECT count(*) FROM pg_stat_activity WHERE datname='{source}';", 'postgres').strip() == b'0'
    command('create-probe', ['docker', 'exec', container, 'createdb', '-U', 'postgres', '--template=' + source, probe])
    tables = json.loads(sql('tables', "SELECT json_agg(c.relname ORDER BY c.relname) FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='stateknot' AND c.relkind IN ('r','p') AND EXISTS(SELECT 1 FROM pg_attribute a WHERE a.attrelid=c.oid AND a.attname='tenant_id' AND NOT a.attisdropped);"))
    assert len(tables) >= 40 and all(re.fullmatch('[a-z_]+', t) for t in tables)
    snapshot_sql = '\nUNION ALL\n'.join(
        f"SELECT jsonb_build_object('table','{table}','rows',COALESCE(jsonb_agg(to_jsonb(t) ORDER BY to_jsonb(t)::text),'[]'::jsonb))::text FROM stateknot.{table} t"
        for table in tables) + ';'
    before_raw = sql('business-before', snapshot_sql)
    before = {row['table']: row['rows'] for row in map(json.loads, before_raw.splitlines())}
    closures = before['graph_frame_closures']
    assert closures and all(json.loads(bytes.fromhex(r['closure_bytes'][2:]))['version'] == 1 for r in closures)
    catalog_sql = (REPO / 'crates/stateknot-store-postgres/src/graph_frame_catalog.sql').read_bytes()
    old_catalog = json.loads(sql('catalog-before', catalog_sql))
    assert old_catalog == load(REPO / 'crates/stateknot-store-postgres/src/graph_frame_catalog.json')
    sql('install-frozen-guard', migration, transaction=True)
    after_raw = sql('business-after', snapshot_sql)
    after = {row['table']: row['rows'] for row in map(json.loads, after_raw.splitlines())}
    assert after == before
    catalog_raw = sql('catalog-after', catalog_sql)
    catalog = json.loads(catalog_raw)
    changed = [key for key in old_catalog if old_catalog[key] != catalog[key]]
    assert changed == ['functions']
    old_functions = {row[0]: row for row in old_catalog['functions']}
    new_functions = {row[0]: row for row in catalog['functions']}
    assert old_functions.keys() == new_functions.keys()
    assert [key for key in old_functions if old_functions[key] != new_functions[key]] == ['guard_graph_frame_closure_complete']
    normalized = json.dumps(catalog, ensure_ascii=False, sort_keys=True, indent=2).encode() + b'\n'
    (out / 'measured-graph-frame-catalog.json').write_bytes(normalized)
    # No SQLx ledger mutation is made: this is catalog measurement, not a claim
    # that the complete Migrator or the new Rust owning reader has passed.
    assert sql('seed-still-schema36', 'SELECT max(version) FROM public._sqlx_migrations;', source).strip() == b'36'
    result = {'postgres_major': args.major, 'source_database': source, 'probe_database': probe,
              'actual_guard_install_exit': 0, 'migration_sha256': sha(migration),
              'unchanged_business_tables': len(tables), 'unchanged_v1_closure_records': len(closures),
              'catalog_changed_sections': changed, 'changed_function': 'guard_graph_frame_closure_complete',
              'normalized_catalog_sha256': sha(normalized), 'source_seed_retained_at_schema36': True,
              'SQLx_ledger_or_source_seed_mutated': False, 'full_migrator_Rust_reader_or_Green_qualification': False,
              'databases_preserved': True, 'runner_sha256': sha(Path(__file__).read_bytes())}
    (out / 'receipt.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
