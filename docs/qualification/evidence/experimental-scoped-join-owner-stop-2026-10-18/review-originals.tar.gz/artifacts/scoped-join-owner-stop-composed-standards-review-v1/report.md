# Standards review: composed scoped Join owner-stop candidate

Fixed point: `e372184fb1c80ffb9903ac0d9feb8380db51253e`. Reviewed the immutable
29-path patch `cdaaf10531840b77f8947e0724717775e7625379657f2808154fe55157bc22c2`
against the complete 936-file composed source, independently of the Spec axis.

No documented-standard breach found. `CONTRIBUTING.md` requires behavioral tests,
user-facing documentation and an Unreleased entry; this candidate includes all
three. Its RFC-0022 addendum and paired adoption guides keep the implementation
experimental and preserve the separate Driver, compatibility, full CI and R1
gates, consistent with `CONTRIBUTING.md` and `docs/rfcs/README.md`. The public
schema getter and close rustdoc describe their bounded roles. The local Version
type was moved without an additional lint exemption. Formatting/lint concerns
enforced by tooling are not findings in this review.

- **[P3] Possible Duplicated Code — judgement call, not a hard violation.**
  `crates/stateknot-store-postgres/src/graph_frames/closures.rs:449` repeats the
  unfinished ordinary-work predicate already present at line 421: both select
  the latest start and exclude ordinary completions, frame entries and caller
  bindings through the same four `NOT EXISTS` clauses. One returns an existence
  flag and the other at most two IDs. Maintaining the predicates separately can
  let future eligibility edits diverge. Consider using the bounded inventory
  helper from the strict wrapper, rejecting every nonempty result while retaining
  the existing provider checks and error contract. No current behavioral defect
  is demonstrated. This is the previously noted low-priority heuristic, not a
  newly discovered qualification failure.

The three linked qualification records are explicitly pending Root delivery
before adoption; this review does not misclassify that staged delivery as an
already adopted broken link. No build, test, database, Docker or network operation
was executed, and this report confers no execution or production qualification.

Standards: **0 hard violations, 1 heuristic; worst P3**. Spec: not assessed here.
