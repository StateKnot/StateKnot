from pathlib import Path
import hashlib,json,os,subprocess,sys,time,fcntl,re
R=Path('/Users/jiawy/Documents/RustAgentFramework'); B=R/'.local-verification/2026-10-16'; O=Path(__file__).resolve().parent; S=B/'mcp-lossless-bound-state-source-v3'
GATES=[('fmt',['cargo','+1.88.0','fmt','--all','--check']),('clippy',['cargo','+1.88.0','clippy','--workspace','--all-targets','--all-features','--locked','--','-D','warnings']),('workspace',['cargo','+1.88.0','test','--workspace','--all-targets','--all-features','--locked']),('doctests',['cargo','+1.88.0','test','--workspace','--doc','--all-features','--locked']),('rustdoc',['cargo','+1.88.0','doc','--workspace','--all-features','--no-deps','--locked']),('nightly',['cargo','+nightly-2026-10-07','check','--workspace','--all-targets','--all-features','--locked'])]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
put=lambda name,value:(O/name).write_text(json.dumps(value,indent=2)+'\n')
def compiled(root):
 paths=[p for name in ['crates','.cargo'] for p in (root/name).rglob('*') if p.is_file()]+[root/n for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']]
 assert all(not p.is_symlink() for p in paths)
 return sorted([{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in paths],key=lambda x:x['path'])
expected=compiled(S); assert len(expected)==536
assert hashlib.sha256(json.dumps(expected,sort_keys=True,separators=(',',':')).encode()).hexdigest()=='cfd0f2f8b48e062567fb591be2e5c427781cb7db616ee20b942cc2174a775b2d'
if '--execute' not in sys.argv:
 print(json.dumps({'state':'draft only','source_compiled_count':len(expected),'commands':GATES,'nothing_executed':True})); sys.exit(0)
assert compiled(R)==expected,'adopt final 536 compilation inputs before execution'
assert not (O/'summary.json').exists(); lock=(O/'execution.lock').open('a+'); fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB); runner_sha=sha(Path(__file__))
def snapshot():
 raw=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=R); paths=sorted(set(p.decode() for p in raw.split(b'\0') if p)); rows=[]
 for name in paths:
  p=R/name; assert p.is_file() and not p.is_symlink(),name; rows.append({'path':name,'bytes':p.stat().st_size,'sha256':sha(p)})
 assert compiled(R)==expected
 return rows
initial=snapshot(); put('all-inputs-before.json',initial); put('compiled-inputs.json',expected); head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(); put('git-context.json',{'HEAD':head,'status':subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True),'actual_working_input_files':len(initial),'conservative_compilation_superset':536,'compiler_filesystem_read_closure_claimed':False})
def disk(label):
 raw=subprocess.check_output(['df','-k',str(R)],text=True); (O/(label+'.df')).write_text(raw); assert int(raw.splitlines()[-1].split()[3])>=50*1024**2
 rows=[]
 for p in sorted((R/'target').glob('r1-oct15*')):
  if p.is_dir(): rows.append({'path':str(p.resolve()),'logical_kib':int(subprocess.check_output(['du','-sk',str(p)],text=True).split()[0])})
 total=sum(x['logical_kib'] for x in rows); assert total<=20*1024**2; put(label+'-cache-budget.json',{'logical_kib':total,'inventory':rows,'no_cleanup':True,'logical_sizes_not_APFS_reclaimable':True})
env={k:v for k,v in os.environ.items() if not k.startswith(('STATEKNOT_','CARGO_PROFILE_')) and k not in ['CARGO_ENCODED_RUSTFLAGS','RUST_MIN_STACK','RUSTC_BOOTSTRAP']}; env.update(CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUSTFLAGS='-D warnings',RUSTDOCFLAGS='-D warnings'); receipts=[]; started=time.time()
for name,command in GATES:
 assert sha(Path(__file__))==runner_sha and snapshot()==initial; disk(name+'-before'); active=env.copy(); active['CARGO_TARGET_DIR']=str(R/('target/r1-oct15-proof-base'+('-nightly' if name=='nightly' else ''))); start=time.time()
 with (O/(name+'.log')).open('wb') as log:
  p=subprocess.Popen(command,cwd=R,env=active,stdout=log,stderr=subprocess.STDOUT); print(json.dumps({'gate':name,'pid':p.pid,'command':command}),flush=True); code=p.wait()
 exact=snapshot()==initial; row={'gate':name,'command':command,'exit_code':code,'seconds':time.time()-start,'log_sha256':sha(O/(name+'.log')),'runner_sha256':runner_sha,'actual_main_all_inputs_before_after_exact':exact,'supplied_compilation_inputs_exact_final_candidate':True,'profile':'original opt0; default stack/assertions/overflow checks; incremental0/debug0/strictwarnings','Native_database_executed':False}; put(name+'.receipt.json',row); print(json.dumps(row),flush=True); disk(name+'-after'); receipts.append(row); assert code==0 and exact,name
put('all-inputs-after.json',snapshot()); totals={}
for name in ['workspace','doctests']:
 values=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',(O/(name+'.log')).read_text()); assert all(v[0]=='ok' for v in values); totals[name]={'summaries':len(values),'passed':sum(int(v[1]) for v in values),'failed':sum(int(v[2]) for v in values),'ignored':sum(int(v[3]) for v in values)}
assert (totals['workspace']['passed'],totals['workspace']['failed'],totals['workspace']['ignored'])==(2098,0,6); assert (totals['doctests']['passed'],totals['doctests']['failed'])==(48,0)
put('summary.json',{'state':'passed','gates':6,'actual_main_input_files':len(initial),'actual_main_all_inputs_before_after_exact':True,'supplied_compilation_inputs':536,'same_supplied_inputs_as_final_69af_candidate':True,'totals':totals,'receipts':receipts,'seconds':time.time()-started,'original_profile_opt_level':0,'Native_execution_transferred_or_R1_claimed':False}); print(json.dumps({'state':'actual main six strict gates passed','totals':totals}),flush=True)
