Draft guard corrected for relative-path-string sorted536 rows; same source and checks. No product source mutation. Original draft failure retained in v2.
